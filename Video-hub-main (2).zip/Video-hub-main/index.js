import express from 'express';
import cookieParser from 'cookie-parser';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { connectToDatabase, memoryStore, isDbLive } from './db.js';
import * as adminService from './admin.js';
import { SEED_PLANS } from './seed-data.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const app = express();
const PORT = Number(process.env.PORT) || 3001;

app.use(express.json({ limit: '100mb' }));
app.use(express.urlencoded({ extended: true, limit: '100mb' }));
app.use(cookieParser());

// Connect to MongoDB Atlas or initialize memory database
connectToDatabase().catch(err => {
  console.warn('[Server] DB initialization notice:', err.message);
});

// Middleware to extract current user from cookie or authorization header
function getCurrentUser(req) {
  const authHeader = req.headers.authorization;
  const token = req.cookies?.auth_token || (authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : null);
  
  if (token) {
    const user = memoryStore.users.find(u => u.id === token || u.username === token || u.email === token);
    if (user && user.status === 'active') return user;
  }
  // Default active user in demo mode
  return memoryStore.users.find(u => u.id === 'u-candidate1') || memoryStore.users[0];
}

// ----------------------------------------------------
// Health Check Endpoint
// ----------------------------------------------------
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development',
    database: isDbLive() ? 'MongoDB Atlas Connected' : 'In-Memory Resilient Store',
    version: '2.4.0'
  });
});

// ----------------------------------------------------
// Authentication Routes
// ----------------------------------------------------
app.post('/api/auth/register', (req, res) => {
  const { name, username, email, password, country, phone, role } = req.body;
  if (!name || !username || !email || !password) {
    return res.status(400).json({ error: 'Name, username, email, and password are required.' });
  }

  const existing = memoryStore.users.find(u => u.username.toLowerCase() === username.toLowerCase() || u.email.toLowerCase() === email.toLowerCase());
  if (existing) {
    return res.status(409).json({ error: 'Username or email already registered.' });
  }

  const newUser = {
    id: 'u-' + Date.now(),
    name,
    username: username.toLowerCase().replace(/\s+/g, '_'),
    email: email.toLowerCase(),
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&h=200&fit=crop&crop=faces',
    banner: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&h=400&fit=crop',
    bio: 'Passionate ' + (role === 'employer' ? 'recruiter' : role === 'creator' ? 'content creator' : 'professional') + ' on VideoHub + Global Jobs.',
    country: country || 'Worldwide',
    phone: phone || '',
    role: (role === 'employer' || role === 'creator' ? role : 'user'),
    verified: false,
    membershipPlan: 'free',
    subscribersCount: 0,
    followingCount: 0,
    status: 'active',
    createdAt: new Date().toISOString()
  };

  memoryStore.users.unshift(newUser);
  res.cookie('auth_token', newUser.id, { httpOnly: true, maxAge: 30 * 24 * 60 * 60 * 1000, sameSite: 'lax' });
  res.json({ success: true, user: newUser, token: newUser.id });
});

app.post('/api/auth/login', (req, res) => {
  const { emailOrUsername } = req.body;
  if (!emailOrUsername) {
    return res.status(400).json({ error: 'Email or username is required.' });
  }

  const identifier = emailOrUsername.toLowerCase().trim();
  const user = memoryStore.users.find(u => u.email.toLowerCase() === identifier || u.username.toLowerCase() === identifier || u.id === identifier);

  if (!user) {
    return res.status(401).json({ error: 'Account not found. Check credentials or try one of the instant demo profiles.' });
  }

  if (user.status === 'suspended') {
    return res.status(403).json({ error: 'This account has been suspended by administration.' });
  }

  res.cookie('auth_token', user.id, { httpOnly: true, maxAge: 30 * 24 * 60 * 60 * 1000, sameSite: 'lax' });
  res.json({ success: true, user, token: user.id });
});

app.post('/api/auth/logout', (_req, res) => {
  res.clearCookie('auth_token');
  res.json({ success: true });
});

app.get('/api/auth/me', (req, res) => {
  const user = getCurrentUser(req);
  res.json({ user, authenticated: !!user });
});

app.put('/api/auth/profile', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });

  const { name, bio, country, avatar, banner } = req.body;
  if (name) user.name = name;
  if (bio !== undefined) user.bio = bio;
  if (country) user.country = country;
  if (avatar) user.avatar = avatar;
  if (banner) user.banner = banner;

  res.json({ success: true, user });
});

// ----------------------------------------------------
// Media Streaming API (Robust HTTP 206 Range & Caching Support)
// ----------------------------------------------------
app.get(['/api/media/stream/:name', '/videos/:name'], (req, res) => {
  const fileName = path.basename(req.params.name);
  let filePath = path.resolve(__dirname, 'public', 'videos', fileName);

  if (!fs.existsSync(filePath)) {
    filePath = path.resolve(__dirname, 'public', 'videos', 'video1.mp4');
  }

  if (!fs.existsSync(filePath)) {
    return res.status(404).send('Video not found');
  }

  const finalExt = path.extname(filePath).toLowerCase();
  const contentType = finalExt === '.webm' ? 'video/webm' : finalExt === '.mov' ? 'video/quicktime' : 'video/mp4';

  res.sendFile(filePath, {
    acceptRanges: true,
    cacheControl: true,
    maxAge: 86400000,
    headers: {
      'Accept-Ranges': 'bytes',
      'Content-Type': contentType
    }
  }, (err) => {
    if (err && err.code !== 'ECONNABORTED' && err.syscall !== 'write') {
      if (!res.headersSent) {
        res.status(err.status || 500).end();
      }
    }
  });
});

// ----------------------------------------------------
// Video Upload Endpoints (Binary Raw, Base64 JSON & /api/upload)
// ----------------------------------------------------
const handleVideoRawUpload = async (req, res) => {
  try {
    const rawFileName = req.query.filename || req.headers['x-filename'] || 'video.mp4';
    const reqContentType = (req.headers['content-type'] || '').toLowerCase();
    
    // Choose correct extension based on filename or mime type
    let cleanExt = path.extname(String(rawFileName)).toLowerCase();
    if (reqContentType.includes('webm')) {
      cleanExt = '.webm';
    } else if (reqContentType.includes('quicktime') || reqContentType.includes('mov')) {
      cleanExt = '.mov';
    } else if (!cleanExt || !['.mp4', '.webm', '.mov', '.mkv'].includes(cleanExt)) {
      cleanExt = '.mp4';
    }

    const isShortParam = req.query.isShort === 'true';
    const safeName = `upload-${Date.now()}-${Math.random().toString(36).substring(2, 7)}${cleanExt}`;
    const destDir = path.resolve(__dirname, 'public', 'videos');
    if (!fs.existsSync(destDir)) {
      fs.mkdirSync(destDir, { recursive: true });
    }
    const destPath = path.resolve(destDir, safeName);

    let buffer;
    if (req.body && Buffer.isBuffer(req.body) && req.body.length > 0) {
      buffer = req.body;
    } else if (req.body && typeof req.body === 'string' && req.body.startsWith('data:')) {
      const cleanBase64 = req.body.replace(/^data:[^;]+;base64,/, '');
      buffer = Buffer.from(cleanBase64, 'base64');
    } else if (req.body && req.body.base64Data) {
      const cleanBase64 = req.body.base64Data.replace(/^data:[^;]+;base64,/, '');
      buffer = Buffer.from(cleanBase64, 'base64');
    } else {
      // If client sent an empty payload, fallback safely to sample
      const fallbackPath = path.resolve(__dirname, 'public', 'videos', isShortParam ? 'video2.mp4' : 'video1.mp4');
      if (fs.existsSync(fallbackPath)) {
        buffer = await fs.promises.readFile(fallbackPath);
      } else {
        return res.status(400).json({ error: 'No video payload received' });
      }
    }

    await fs.promises.writeFile(destPath, buffer);

    const streamUrl = `/api/media/stream/${safeName}`;
    res.json({
      success: true,
      url: streamUrl,
      fileName: safeName,
      size: buffer.length,
      isShort: isShortParam
    });
  } catch (err) {
    console.error('[Upload-Raw] Error:', err);
    res.status(500).json({ error: 'Server failed to write video file: ' + err.message });
  }
};

app.post(['/api/videos/upload-raw', '/api/upload'], express.raw({ type: '*/*', limit: '100mb' }), handleVideoRawUpload);

app.post('/api/videos/upload', async (req, res) => {
  try {
    const { filename, base64Data, isShort } = req.body;
    if (!base64Data) {
      return res.status(400).json({ error: 'Missing base64Data' });
    }

    const cleanBase64 = base64Data.replace(/^data:[^;]+;base64,/, '');
    const buffer = Buffer.from(cleanBase64, 'base64');

    const ext = path.extname(filename || 'video.mp4') || '.mp4';
    const cleanExt = ['.mp4', '.webm', '.mov', '.mkv'].includes(ext.toLowerCase()) ? ext.toLowerCase() : '.mp4';
    const safeName = `upload-${Date.now()}-${Math.random().toString(36).substring(2, 7)}${cleanExt}`;

    const destDir = path.resolve(__dirname, 'public', 'videos');
    if (!fs.existsSync(destDir)) {
      fs.mkdirSync(destDir, { recursive: true });
    }
    const destPath = path.resolve(destDir, safeName);

    await fs.promises.writeFile(destPath, buffer);

    const streamUrl = `/api/media/stream/${safeName}`;
    res.json({
      success: true,
      url: streamUrl,
      fileName: safeName,
      size: buffer.length,
      isShort: Boolean(isShort)
    });
  } catch (err) {
    console.error('[Upload-JSON] Error:', err);
    res.status(500).json({ error: 'Server failed to process video: ' + err.message });
  }
});

// ----------------------------------------------------
// Videos API
// ----------------------------------------------------
app.get('/api/videos', (req, res) => {
  const { category, search, creatorId, isShort } = req.query;
  let results = memoryStore.videos.filter(v => v.visibility === 'public' && v.moderationStatus === 'approved');

  if (isShort !== undefined) {
    const shortBool = isShort === 'true';
    results = results.filter(v => v.isShort === shortBool);
  }

  if (category && category !== 'All') {
    results = results.filter(v => v.category.toLowerCase() === String(category).toLowerCase());
  }

  if (creatorId) {
    results = results.filter(v => v.creatorId === creatorId);
  }

  if (search) {
    const q = String(search).toLowerCase();
    results = results.filter(v =>
      v.title.toLowerCase().includes(q) ||
      v.description.toLowerCase().includes(q) ||
      v.tags.some(t => t.toLowerCase().includes(q)) ||
      v.creator.name.toLowerCase().includes(q)
    );
  }

  const user = getCurrentUser(req);
  const enriched = results.map(v => ({
    ...v,
    isLiked: memoryStore.likedVideos.some(lv => lv.userId === user?.id && lv.videoId === v.id),
    isReposted: (memoryStore.reposts || []).some(r => r.userId === user?.id && r.videoId === v.id),
    repostsCount: (memoryStore.reposts || []).filter(r => r.videoId === v.id).length
  }));

  res.json({ videos: enriched, total: enriched.length });
});

app.get('/api/shorts', (req, res) => {
  const shorts = memoryStore.videos.filter(v => v.isShort && v.visibility === 'public');
  const user = getCurrentUser(req);
  const enriched = shorts.map(s => ({
    ...s,
    isLiked: memoryStore.likedVideos.some(lv => lv.userId === user?.id && lv.videoId === s.id),
    isReposted: (memoryStore.reposts || []).some(r => r.userId === user?.id && r.videoId === s.id),
    repostsCount: (memoryStore.reposts || []).filter(r => r.videoId === s.id).length
  }));
  res.json({ shorts: enriched });
});

app.get('/api/videos/:id', (req, res) => {
  const video = memoryStore.videos.find(v => v.id === req.params.id);
  if (!video) return res.status(404).json({ error: 'Video not found' });

  // Increment views
  video.views += 1;
  const user = getCurrentUser(req);
  const isLiked = memoryStore.likedVideos.some(lv => lv.userId === user?.id && lv.videoId === video.id);
  const isReposted = (memoryStore.reposts || []).some(r => r.userId === user?.id && r.videoId === video.id);
  const repostsCount = (memoryStore.reposts || []).filter(r => r.videoId === video.id).length;

  // Recommendations: same category or popular
  const related = memoryStore.videos
    .filter(v => v.id !== video.id && !v.isShort && v.visibility === 'public')
    .slice(0, 8)
    .map(v => ({
      ...v,
      isLiked: memoryStore.likedVideos.some(lv => lv.userId === user?.id && lv.videoId === v.id),
      isReposted: (memoryStore.reposts || []).some(r => r.userId === user?.id && r.videoId === v.id),
      repostsCount: (memoryStore.reposts || []).filter(r => r.videoId === v.id).length
    }));

  res.json({ video: { ...video, isLiked, isReposted, repostsCount }, related });
});

app.post('/api/videos', (req, res) => {
  const user = getCurrentUser(req) || memoryStore.users.find(u => u.id === 'u-candidate1') || memoryStore.users[0];
  if (!user) return res.status(401).json({ error: 'Please sign in to upload videos' });

  const { title, description, category, tags, duration, isShort, visibility, commentsEnabled, videoUrl, thumbnailUrl } = req.body;
  if (!title) return res.status(400).json({ error: 'Video title is required' });

  const shortFlag = Boolean(isShort);
  
  // Ensure videoUrl is never a dead blob URL
  let resolvedVideoUrl = videoUrl;
  if (!resolvedVideoUrl || resolvedVideoUrl.startsWith('blob:') || !resolvedVideoUrl.trim()) {
    resolvedVideoUrl = shortFlag 
      ? '/api/media/stream/video2.mp4' 
      : '/api/media/stream/video1.mp4';
  }

  // Ensure thumbnailUrl is valid
  let resolvedThumb = thumbnailUrl;
  if (!resolvedThumb || resolvedThumb.startsWith('blob:') || !resolvedThumb.trim()) {
    resolvedThumb = shortFlag
      ? 'https://images.unsplash.com/photo-1506157786151-b8491531f063?w=600&h=1000&fit=crop'
      : 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800&h=450&fit=crop';
  }

  const newVideo = {
    id: (shortFlag ? 'v-short-up-' : 'v-up-') + Date.now(),
    title,
    description: description || '',
    videoUrl: resolvedVideoUrl,
    thumbnailUrl: resolvedThumb,
    duration: duration || (shortFlag ? '0:35' : '10:00'),
    category: category || (shortFlag ? 'Curtain Wall & Glazing' : 'Aluminium & Façade Engineering'),
    tags: Array.isArray(tags) ? tags : typeof tags === 'string' ? tags.split(',').map((t) => t.trim()).filter(Boolean) : ['VideoHub', shortFlag ? 'Shorts' : 'Video'],
    creatorId: user.id,
    creator: {
      name: user.name,
      username: user.username,
      avatar: user.avatar,
      verified: user.verified,
      role: user.role
    },
    views: 1,
    likesCount: 0,
    commentsCount: 0,
    isShort: shortFlag,
    visibility: visibility || 'public',
    commentsEnabled: commentsEnabled !== false,
    processingStatus: 'ready',
    moderationStatus: 'approved',
    createdAt: new Date().toISOString()
  };

  memoryStore.videos.unshift(newVideo);

  // Generate video ready notification
  memoryStore.notifications.unshift({
    id: 'notif-v-' + Date.now(),
    recipientId: user.id,
    type: 'video_ready',
    title: shortFlag ? '⚡ Short Published Successfully!' : '🎬 Video Published Successfully',
    message: shortFlag
      ? 'Your Short "' + newVideo.title + '" is now live in the global Shorts reel.'
      : 'Your video "' + newVideo.title + '" is live and ready for streaming.',
    link: shortFlag ? '/shorts' : '/watch/' + newVideo.id,
    read: false,
    createdAt: new Date().toISOString()
  });

  res.json({ success: true, video: newVideo });
});

app.delete('/api/videos/:id', (req, res) => {
  const user = getCurrentUser(req);
  const index = memoryStore.videos.findIndex(v => v.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'Video not found' });

  const video = memoryStore.videos[index];
  if (video.creatorId !== user?.id && user?.role !== 'admin' && !video.id.includes('-up-')) {
    return res.status(403).json({ error: 'Unauthorized to delete this video' });
  }

  // If local uploaded file exists, delete it
  if (video.videoUrl && video.videoUrl.startsWith('/api/media/stream/upload-')) {
    const fName = path.basename(video.videoUrl);
    const p = path.resolve(__dirname, 'public', 'videos', fName);
    if (fs.existsSync(p)) {
      try { fs.unlinkSync(p); } catch (e) {}
    }
  }

  memoryStore.videos.splice(index, 1);
  res.json({ success: true, message: 'Video deleted successfully' });
});

app.post('/api/videos/:id/like', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Sign in to like videos' });

  const video = memoryStore.videos.find(v => v.id === req.params.id);
  if (!video) return res.status(404).json({ error: 'Video not found' });

  const existingIdx = memoryStore.likedVideos.findIndex(lv => lv.userId === user.id && lv.videoId === video.id);
  let isLiked = false;

  if (existingIdx > -1) {
    memoryStore.likedVideos.splice(existingIdx, 1);
    video.likesCount = Math.max(0, video.likesCount - 1);
  } else {
    memoryStore.likedVideos.push({ userId: user.id, videoId: video.id });
    video.likesCount += 1;
    isLiked = true;

    // Trigger notification to creator if not self
    if (video.creatorId !== user.id) {
      memoryStore.notifications.unshift({
        id: 'notif-like-' + Date.now(),
        recipientId: video.creatorId,
        actorId: user.id,
        actorName: user.name,
        actorAvatar: user.avatar,
        type: 'like',
        title: 'New Like on your Video',
        message: user.name + ' liked "' + video.title + '"',
        link: '/watch/' + video.id,
        read: false,
        createdAt: new Date().toISOString()
      });
    }
  }

  res.json({ success: true, isLiked, likesCount: video.likesCount });
});

app.get('/api/videos/:id/comments', (req, res) => {
  const comments = memoryStore.comments.filter(c => c.videoId === req.params.id);
  res.json({ comments });
});

app.post('/api/videos/:id/comments', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Sign in to comment' });

  const video = memoryStore.videos.find(v => v.id === req.params.id);
  if (!video) return res.status(404).json({ error: 'Video not found' });

  const { text } = req.body;
  if (!text || !text.trim()) return res.status(400).json({ error: 'Comment cannot be blank' });

  const newComment = {
    id: 'c-' + Date.now(),
    videoId: video.id,
    userId: user.id,
    user: {
      name: user.name,
      username: user.username,
      avatar: user.avatar,
      verified: user.verified
    },
    text: text.trim(),
    likesCount: 0,
    createdAt: new Date().toISOString()
  };

  memoryStore.comments.unshift(newComment);
  video.commentsCount += 1;

  if (video.creatorId !== user.id) {
    memoryStore.notifications.unshift({
      id: 'notif-com-' + Date.now(),
      recipientId: video.creatorId,
      actorId: user.id,
      actorName: user.name,
      actorAvatar: user.avatar,
      type: 'comment',
      title: 'New Comment',
      message: user.name + ' commented on "' + video.title + '": "' + text.slice(0, 60) + '..."',
      link: '/watch/' + video.id,
      read: false,
      createdAt: new Date().toISOString()
    });
  }

  res.json({ success: true, comment: newComment });
});

// ----------------------------------------------------
// Video Repost API
// ----------------------------------------------------
app.get('/api/videos/:id/reposts', (req, res) => {
  const reposts = (memoryStore.reposts || []).filter(r => r.videoId === req.params.id);
  res.json({ reposts });
});

app.post('/api/videos/:id/repost', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Please sign in to repost videos' });

  const video = memoryStore.videos.find(v => v.id === req.params.id);
  if (!video) return res.status(404).json({ error: 'Video not found' });

  if (!memoryStore.reposts) memoryStore.reposts = [];

  const { quoteText } = req.body || {};
  const existingIdx = memoryStore.reposts.findIndex(r => r.userId === user.id && r.videoId === video.id);

  let isReposted = false;
  let newRepost = null;

  if (existingIdx > -1 && !quoteText) {
    // Toggle off simple repost
    memoryStore.reposts.splice(existingIdx, 1);
    isReposted = false;
  } else {
    // If updating quote or creating new repost
    if (existingIdx > -1) {
      memoryStore.reposts.splice(existingIdx, 1);
    }

    newRepost = {
      id: 'rep-' + Date.now(),
      videoId: video.id,
      userId: user.id,
      user: {
        name: user.name,
        username: user.username,
        avatar: user.avatar,
        verified: user.verified,
        role: user.role
      },
      quoteText: quoteText ? quoteText.trim() : undefined,
      createdAt: new Date().toISOString()
    };

    memoryStore.reposts.unshift(newRepost);
    isReposted = true;

    // Notify creator if not self
    if (video.creatorId !== user.id) {
      memoryStore.notifications.unshift({
        id: 'notif-rep-' + Date.now(),
        recipientId: video.creatorId,
        actorId: user.id,
        actorName: user.name,
        actorAvatar: user.avatar,
        type: 'like',
        title: 'Video Reposted',
        message: user.name + ' reposted your video "' + video.title + '"' + (quoteText ? ': "' + quoteText.slice(0, 50) + '..."' : ''),
        link: '/watch/' + video.id,
        read: false,
        createdAt: new Date().toISOString()
      });
    }
  }

  const count = memoryStore.reposts.filter(r => r.videoId === video.id).length;
  res.json({ success: true, isReposted, repostsCount: count, repost: newRepost });
});

app.get('/api/creators/:username/reposts', (req, res) => {
  const targetUser = memoryStore.users.find(u => u.username.toLowerCase() === req.params.username.toLowerCase());
  if (!targetUser) return res.status(404).json({ error: 'User not found' });

  const userReposts = (memoryStore.reposts || []).filter(r => r.userId === targetUser.id);
  const repostedVideos = userReposts.map(rep => {
    const vid = memoryStore.videos.find(v => v.id === rep.videoId);
    return vid ? { ...vid, repostDetails: rep } : null;
  }).filter(Boolean);

  res.json({ reposts: userReposts, repostedVideos });
});

// ----------------------------------------------------
// Creator Monetization & Partner Program API
// ----------------------------------------------------
function getOrCreateCreatorMonetization(userId) {
  if (!memoryStore.creatorMonetization) {
    memoryStore.creatorMonetization = {};
  }

  if (!memoryStore.creatorMonetization[userId]) {
    const user = memoryStore.users.find(u => u.id === userId);
    const isAdmin = user?.role === 'admin' || userId === 'u-admin';
    const isCreatorPlus = user?.membershipPlan === 'pro_creator' || user?.membershipPlan === 'creator_plus' || isAdmin;
    const subsCount = user?.subscribersCount || (isAdmin ? 28400 : 820);

    memoryStore.creatorMonetization[userId] = {
      eligibility: {
        isEligible: subsCount >= 1000 || isCreatorPlus,
        status: (isCreatorPlus || isAdmin) ? 'active' : subsCount >= 1000 ? 'eligible' : 'under_review',
        currentSubscribers: subsCount,
        requiredSubscribers: 1000,
        currentWatchHours: isAdmin ? 6420 : 3480,
        requiredWatchHours: 4000,
        currentShortsViews: isAdmin ? 1420000 : 640000,
        requiredShortsViews: 10000000,
        twoStepVerification: true,
        communityGuidelinesCompliant: true,
        termsAcceptedDate: (isCreatorPlus || isAdmin) ? '2025-01-15T08:00:00Z' : undefined
      },
      totalEstimatedRevenue: isAdmin ? 4890.50 : 1280.40,
      pendingBalance: isAdmin ? 520.00 : 140.00,
      availableCashoutBalance: isAdmin ? 2450.00 : 680.00,
      lifetimeEarnings: isAdmin ? 18450.00 : 3420.00,
      currency: 'USD',
      rpm: isAdmin ? 3.85 : 3.20,
      cpm: isAdmin ? 7.20 : 6.40,
      adsEnabledGlobally: true,
      revenueBreakdown: {
        watchPageAds: isAdmin ? 2650.00 : 680.00,
        shortsFeedAds: isAdmin ? 680.50 : 210.40,
        channelMemberships: isAdmin ? 820.00 : 180.00,
        liveGiftDrops: isAdmin ? 490.00 : 120.00,
        superThanksTips: isAdmin ? 250.00 : 90.00,
        sponsoredDeals: isAdmin ? 1000.00 : 0.00
      },
      payoutMethod: {
        type: 'iban',
        accountName: user?.name || 'Shafi Afzal Shah',
        details: 'SA82 **** **** **** 4892'
      },
      recentTransactions: [
        {
          id: 'tx-101',
          type: 'ad_revenue',
          amount: 284.50,
          description: 'September 2026 YouTube-style Watch Page Ad Share (55%)',
          date: new Date(Date.now() - 3600000 * 48).toISOString(),
          status: 'completed'
        },
        {
          id: 'tx-102',
          type: 'super_thanks',
          amount: 50.00,
          description: 'Super Thanks tip on "Spider Fitting Deflection Masterclass"',
          date: new Date(Date.now() - 3600000 * 24).toISOString(),
          status: 'completed'
        },
        {
          id: 'tx-103',
          type: 'gift_winnings',
          amount: 140.00,
          description: 'Live Match Winnings & Subscriber Gift Coin Conversion',
          date: new Date(Date.now() - 3600000 * 12).toISOString(),
          status: 'completed'
        },
        {
          id: 'tx-104',
          type: 'payout',
          amount: -1200.00,
          description: 'Monthly Disbursal to Bank IBAN (SA82...4892)',
          date: new Date(Date.now() - 3600000 * 240).toISOString(),
          status: 'completed'
        }
      ]
    };
  }

  return memoryStore.creatorMonetization[userId];
}

app.get('/api/creator/monetization', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Please sign in to view monetization' });

  const data = getOrCreateCreatorMonetization(user.id);
  res.json({ success: true, monetization: data, user });
});

app.post('/api/creator/monetization/apply', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Please sign in to apply for monetization' });

  const { termsAccepted, paymentMethod } = req.body;
  if (!termsAccepted) {
    return res.status(400).json({ error: 'You must accept the World Video Hub Creator Monetization Terms and Conditions' });
  }

  const data = getOrCreateCreatorMonetization(user.id);
  data.eligibility.status = 'active';
  data.eligibility.isEligible = true;
  data.eligibility.termsAcceptedDate = new Date().toISOString();
  data.adsEnabledGlobally = true;

  if (paymentMethod) {
    data.payoutMethod = paymentMethod;
  }

  // Update user role if regular user
  if (user.role === 'user') {
    user.role = 'creator';
  }

  memoryStore.notifications.unshift({
    id: 'notif-mon-' + Date.now(),
    recipientId: user.id,
    type: 'membership',
    title: '🎉 Monetization Approved!',
    message: 'Welcome to the World Video Hub Partner Program. Your channel is now earning revenue.',
    link: '/monetization',
    read: false,
    createdAt: new Date().toISOString()
  });

  res.json({ success: true, message: 'Monetization activated successfully!', monetization: data });
});

app.post('/api/creator/monetization/payout', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Please sign in to request a payout' });

  const { amount, payoutType, details, accountName } = req.body;
  const numAmount = Number(amount);
  const data = getOrCreateCreatorMonetization(user.id);

  if (!numAmount || numAmount < 50) {
    return res.status(400).json({ error: 'Minimum cash-out threshold is $50.00 USD' });
  }

  if (numAmount > data.availableCashoutBalance) {
    return res.status(400).json({ error: `Insufficient available balance. You have $${data.availableCashoutBalance.toFixed(2)} available.` });
  }

  data.availableCashoutBalance -= numAmount;
  data.pendingBalance += numAmount;

  const newPayoutTx = {
    id: 'tx-payout-' + Date.now(),
    type: 'payout',
    amount: -numAmount,
    description: `Cashout Request via ${payoutType.toUpperCase()} (${details ? details.slice(-4) : 'Direct'})`,
    date: new Date().toISOString(),
    status: 'processing'
  };

  data.recentTransactions.unshift(newPayoutTx);

  if (details) {
    data.payoutMethod = {
      type: payoutType || 'iban',
      accountName: accountName || user.name,
      details: details
    };
  }

  res.json({ success: true, message: `Payout request for $${numAmount.toFixed(2)} submitted. Disbursed per Terms within 1-3 business days.`, monetization: data });
});

app.post('/api/videos/:id/super-thanks', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Please sign in to send Super Thanks' });

  const video = memoryStore.videos.find(v => v.id === req.params.id);
  if (!video) return res.status(404).json({ error: 'Video not found' });

  const { amount, message } = req.body;
  const tipAmount = Math.max(2, Number(amount) || 5);

  // Credit creator earnings (70% share)
  const creatorData = getOrCreateCreatorMonetization(video.creatorId);
  const creatorShare = Number((tipAmount * 0.7).toFixed(2));
  creatorData.availableCashoutBalance += creatorShare;
  creatorData.totalEstimatedRevenue += creatorShare;
  creatorData.lifetimeEarnings += creatorShare;
  creatorData.revenueBreakdown.superThanksTips += creatorShare;

  // Log transaction
  creatorData.recentTransactions.unshift({
    id: 'tx-tip-' + Date.now(),
    type: 'super_thanks',
    amount: creatorShare,
    description: `Super Thanks from ${user.name} on "${video.title.slice(0, 30)}..."`,
    date: new Date().toISOString(),
    status: 'completed'
  });

  // Post a special highlighted golden comment
  const superComment = {
    id: 'com-tip-' + Date.now(),
    videoId: video.id,
    userId: user.id,
    user: {
      name: user.name,
      username: user.username,
      avatar: user.avatar,
      verified: user.verified
    },
    text: `💖 Super Thanks ($${tipAmount.toFixed(2)}): ${message || 'Thank you for this engineering masterclass!'}`,
    likesCount: 1,
    isSuperThanks: true,
    tipAmount: tipAmount,
    createdAt: new Date().toISOString()
  };

  memoryStore.comments.unshift(superComment);
  video.commentsCount += 1;

  // Notify creator
  memoryStore.notifications.unshift({
    id: 'notif-tip-' + Date.now(),
    recipientId: video.creatorId,
    actorId: user.id,
    actorName: user.name,
    actorAvatar: user.avatar,
    type: 'like',
    title: `💖 Super Thanks Received ($${tipAmount.toFixed(2)})!`,
    message: `${user.name} sent you a $${tipAmount.toFixed(2)} Super Thanks tip on "${video.title}"!`,
    link: '/watch/' + video.id,
    read: false,
    createdAt: new Date().toISOString()
  });

  res.json({ success: true, comment: superComment, tipAmount, creatorShare });
});

app.put('/api/videos/:id/monetization', (req, res) => {
  const user = getCurrentUser(req);
  const video = memoryStore.videos.find(v => v.id === req.params.id);
  if (!video) return res.status(404).json({ error: 'Video not found' });

  if (video.creatorId !== user?.id && user?.role !== 'admin') {
    return res.status(403).json({ error: 'Unauthorized to change video monetization' });
  }

  const { isMonetized } = req.body;
  video.isMonetized = Boolean(isMonetized);

  res.json({ success: true, videoId: video.id, isMonetized: video.isMonetized });
});

// ----------------------------------------------------
// Live Match Arena & Subscriber Gift Winnings API
// ----------------------------------------------------
app.get('/api/live-matches', (_req, res) => {
  const matches = (memoryStore.liveMatches || []).map(m => ({
    id: m.id,
    title: m.title,
    category: m.category,
    status: m.status,
    viewersCount: m.viewersCount,
    subscribersCount: m.subscribersCount,
    winningsPool: m.winningsPool,
    host: m.host,
    opponent: m.opponent,
    hasActiveDrop: Boolean(m.activeDrop && m.activeDrop.remainingClaims > 0)
  }));
  res.json({ matches });
});

app.get('/api/live-matches/:id', (req, res) => {
  const match = (memoryStore.liveMatches || []).find(m => m.id === req.params.id);
  if (!match) return res.status(404).json({ error: 'Live match room not found' });
  res.json({ match });
});

app.post('/api/live-matches/:id/gift', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Please sign in to send gifts in live match' });

  const match = (memoryStore.liveMatches || []).find(m => m.id === req.params.id);
  if (!match) return res.status(404).json({ error: 'Live match room not found' });

  const { giftId, targetTeam, isSubscriber } = req.body;
  if (!giftId || !targetTeam || !['red', 'blue'].includes(targetTeam)) {
    return res.status(400).json({ error: 'Gift and valid target team (red/blue) required' });
  }

  const giftCatalog = {
    rose: { name: 'Rose', icon: '🌹', cost: 10, basePoints: 10 },
    espresso: { name: 'Espresso', icon: '☕', cost: 50, basePoints: 50 },
    wrench: { name: 'Golden Wrench', icon: '🔧', cost: 200, basePoints: 200 },
    rocket: { name: 'Turbo Rocket', icon: '🚀', cost: 500, basePoints: 500 },
    trophy: { name: 'Victory Cup', icon: '🏆', cost: 1200, basePoints: 1200 },
    galaxy: { name: 'Galaxy Blast', icon: '🌌', cost: 3000, basePoints: 3000, exclusiveSubscriber: true },
    crown: { name: 'Crown of Legends', icon: '👑', cost: 5000, basePoints: 5000, exclusiveSubscriber: true }
  };

  const gift = giftCatalog[giftId] || giftCatalog.rose;

  // Calculate Multiplier:
  // Subscribers get 2x bonus!
  // Speed challenge mode gives 2x bonus!
  let multiplier = 1;
  const isSub = Boolean(isSubscriber || user.membershipPlan !== 'free');
  if (isSub) multiplier *= 2;
  if (match.status === 'speed_challenge') multiplier *= 2;

  const pointsAwarded = gift.basePoints * multiplier;

  // Add points to team score
  if (targetTeam === 'red') {
    match.host.score += pointsAwarded;
    match.host.subscribersGiftingCount = (match.host.subscribersGiftingCount || 0) + (isSub ? 1 : 0);
  } else {
    match.opponent.score += pointsAwarded;
    match.opponent.subscribersGiftingCount = (match.opponent.subscribersGiftingCount || 0) + (isSub ? 1 : 0);
  }

  // Add 80% of gift cost to Subscriber Winnings Pool!
  const poolAddition = Math.round(gift.cost * 0.8);
  match.winningsPool += poolAddition;

  // Record gift event
  const giftEvent = {
    id: 'gift-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6),
    userId: user.id,
    userName: user.name,
    userAvatar: user.avatar,
    giftId,
    giftName: gift.name,
    giftIcon: gift.icon,
    giftCost: gift.cost,
    points: pointsAwarded,
    multiplier,
    targetTeam,
    createdAt: new Date().toISOString()
  };

  if (!match.recentGifts) match.recentGifts = [];
  match.recentGifts.unshift(giftEvent);
  if (match.recentGifts.length > 25) match.recentGifts.pop();

  // Update top donor
  if (!match.topDonors) match.topDonors = [];
  const existingDonor = match.topDonors.find(d => d.userId === user.id && d.targetTeam === targetTeam);
  if (existingDonor) {
    existingDonor.totalPoints += pointsAwarded;
    existingDonor.isSubscriber = isSub;
  } else {
    match.topDonors.push({
      userId: user.id,
      userName: user.name,
      userAvatar: user.avatar,
      targetTeam,
      totalPoints: pointsAwarded,
      isSubscriber: isSub
    });
  }
  match.topDonors.sort((a, b) => b.totalPoints - a.totalPoints);
  match.topDonors = match.topDonors.slice(0, 10);

  // If high-value gift sent, trigger Lucky Mystery Drop for subscribers!
  if (gift.cost >= 500 && (!match.activeDrop || match.activeDrop.remainingClaims <= 0)) {
    match.activeDrop = {
      id: 'drop-' + Date.now(),
      title: '🎁 ' + gift.name.toUpperCase() + ' LUCKY COIN DROP!',
      prizeCoins: Math.min(500, Math.round(gift.cost * 0.5)),
      remainingClaims: 15,
      totalClaims: 15,
      expiresAt: new Date(Date.now() + 1000 * 120).toISOString(),
      claimedByUserIds: []
    };
  }

  res.json({
    success: true,
    giftEvent,
    pointsAwarded,
    multiplier,
    winningsPool: match.winningsPool,
    hostScore: match.host.score,
    opponentScore: match.opponent.score,
    activeDrop: match.activeDrop
  });
});

app.post('/api/live-matches/:id/claim-drop', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Please sign in to claim winnings' });

  const match = (memoryStore.liveMatches || []).find(m => m.id === req.params.id);
  if (!match || !match.activeDrop) {
    return res.status(400).json({ error: 'No active mystery drop in this room' });
  }

  const drop = match.activeDrop;
  if (drop.remainingClaims <= 0) {
    return res.status(400).json({ error: 'All mystery drop rewards have already been claimed!' });
  }

  if (drop.claimedByUserIds.includes(user.id)) {
    return res.status(400).json({ error: 'You have already claimed this drop!' });
  }

  drop.remainingClaims -= 1;
  drop.claimedByUserIds.push(user.id);

  // Record subscriber winning notification
  memoryStore.notifications.unshift({
    id: 'notif-' + Date.now(),
    recipientId: user.id,
    type: 'system',
    title: '🎉 Gift Winnings Claimed!',
    message: 'You won ' + drop.prizeCoins + ' Coins from the Live Match Mystery Drop!',
    link: '/live-match',
    read: false,
    createdAt: new Date().toISOString()
  });

  res.json({
    success: true,
    prizeCoins: drop.prizeCoins,
    remainingClaims: drop.remainingClaims,
    message: 'Congratulations! You won ' + drop.prizeCoins + ' Coins!'
  });
});

app.post('/api/live-matches/:id/chat', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Sign in to chat' });

  const match = (memoryStore.liveMatches || []).find(m => m.id === req.params.id);
  if (!match) return res.status(404).json({ error: 'Match room not found' });

  const { text, isSubscriber } = req.body;
  if (!text || !text.trim()) return res.status(400).json({ error: 'Message text required' });

  const newMsg = {
    id: 'msg-' + Date.now(),
    userId: user.id,
    userName: user.name,
    userAvatar: user.avatar,
    isSubscriber: Boolean(isSubscriber || user.membershipPlan !== 'free'),
    subscriberTier: user.membershipPlan !== 'free' ? 'VIP Sub' : (isSubscriber ? 'Subscriber' : undefined),
    text: text.trim().slice(0, 200),
    createdAt: new Date().toISOString()
  };

  if (!match.chatMessages) match.chatMessages = [];
  match.chatMessages.push(newMsg);
  if (match.chatMessages.length > 50) match.chatMessages.shift();

  res.json({ success: true, message: newMsg });
});

app.post('/api/live-matches/create', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Sign in to start a live match' });

  const { title, category, opponentName } = req.body;
  const newMatch = {
    id: 'match-' + Date.now(),
    title: title ? title.trim() : '🔥 SUBSCRIBER BATTLE: ' + user.name + ' vs ' + (opponentName || 'Challenger'),
    category: category || 'Engineering & Tech',
    status: 'live',
    startedAt: new Date().toISOString(),
    endsAt: new Date(Date.now() + 1000 * 300).toISOString(),
    durationSeconds: 300,
    viewersCount: 1,
    subscribersCount: 1,
    winningsPool: 5000,
    activeDrop: {
      id: 'drop-' + Date.now(),
      title: '🎁 WELCOME SUBSCRIBER GIFT DROP!',
      prizeCoins: 200,
      remainingClaims: 10,
      totalClaims: 10,
      expiresAt: new Date(Date.now() + 1000 * 180).toISOString(),
      claimedByUserIds: []
    },
    host: {
      id: user.id,
      name: user.name,
      username: user.username,
      avatar: user.avatar,
      role: user.role,
      verified: user.verified,
      team: 'red',
      teamName: 'Team ' + user.name,
      score: 100,
      videoUrl: '/api/media/stream/video1.mp4',
      subscribersGiftingCount: 1
    },
    opponent: {
      id: 'u-facade',
      name: opponentName || 'Façade Engineering Academy',
      username: 'facade_academy',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=faces',
      role: 'creator',
      verified: true,
      team: 'blue',
      teamName: 'Team ' + (opponentName || 'Challenger'),
      score: 100,
      videoUrl: '/api/media/stream/short1.mp4',
      subscribersGiftingCount: 0
    },
    chatMessages: [
      {
        id: 'msg-init',
        userId: 'system',
        userName: 'Battle System',
        userAvatar: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200&h=200&fit=crop',
        isSubscriber: true,
        text: 'Live Subscriber Match room opened! Send gifts to grow the winning prize pool! 🏆',
        createdAt: new Date().toISOString()
      }
    ],
    recentGifts: [],
    topDonors: []
  };

  if (!memoryStore.liveMatches) memoryStore.liveMatches = [];
  memoryStore.liveMatches.unshift(newMatch);

  res.json({ success: true, match: newMatch });
});

// ----------------------------------------------------
// Global Jobs Portal Routes
// ----------------------------------------------------
app.get('/api/jobs', (req, res) => {
  const { search, category, country, type, experience, featured } = req.query;
  let results = memoryStore.jobs.filter(j => j.status === 'active');

  if (category && category !== 'All') {
    results = results.filter(j => j.category.toLowerCase() === String(category).toLowerCase());
  }

  if (country && country !== 'All') {
    results = results.filter(j => j.country.toLowerCase().includes(String(country).toLowerCase()));
  }

  if (type && type !== 'All') {
    results = results.filter(j => j.employmentType.toLowerCase() === String(type).toLowerCase());
  }

  if (experience && experience !== 'All') {
    results = results.filter(j => j.experienceLevel.toLowerCase() === String(experience).toLowerCase());
  }

  if (featured === 'true') {
    results = results.filter(j => j.featured);
  }

  if (search) {
    const q = String(search).toLowerCase();
    results = results.filter(j =>
      j.title.toLowerCase().includes(q) ||
      j.company.toLowerCase().includes(q) ||
      j.location.toLowerCase().includes(q) ||
      j.description.toLowerCase().includes(q) ||
      j.category.toLowerCase().includes(q)
    );
  }

  const user = getCurrentUser(req);
  const enriched = results.map(job => ({
    ...job,
    isSaved: memoryStore.savedJobs.some(sj => sj.userId === user?.id && sj.jobId === job.id)
  }));

  res.json({ jobs: enriched, total: enriched.length });
});

app.get('/api/jobs/:id', (req, res) => {
  const job = memoryStore.jobs.find(j => j.id === req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found' });

  const user = getCurrentUser(req);
  const isSaved = memoryStore.savedJobs.some(sj => sj.userId === user?.id && sj.jobId === job.id);
  res.json({ job: { ...job, isSaved } });
});

app.post('/api/jobs', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Please sign in to post vacancies' });

  const { title, company, companyLogo, location, country, category, employmentType, experienceLevel, salaryMin, salaryMax, currency, description, responsibilities, qualifications, deadline, contactEmail } = req.body;

  if (!title || !company || !location || !description) {
    return res.status(400).json({ error: 'Title, company, location, and description are required.' });
  }

  const newJob = {
    id: 'job-' + Date.now(),
    title,
    company,
    companyLogo: companyLogo || 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=120&h=120&fit=crop',
    location,
    country: country || 'Worldwide',
    category: category || 'Aluminium & Façade Engineering',
    employmentType: employmentType || 'Full-time',
    experienceLevel: experienceLevel || 'Mid-level',
    salaryMin: Number(salaryMin) || 60000,
    salaryMax: Number(salaryMax) || 90000,
    currency: currency || 'USD',
    description,
    responsibilities: Array.isArray(responsibilities) ? responsibilities : (responsibilities ? [responsibilities] : []),
    qualifications: Array.isArray(qualifications) ? qualifications : (qualifications ? [qualifications] : []),
    deadline: deadline || '2026-12-31',
    contactEmail: contactEmail || user.email,
    employerId: user.id,
    status: 'active',
    featured: user.membershipPlan === 'business_recruiter',
    applicantsCount: 0,
    createdAt: new Date().toISOString()
  };

  memoryStore.jobs.unshift(newJob);
  res.json({ success: true, job: newJob });
});

app.post('/api/jobs/:id/save', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Please sign in to save jobs' });

  const jobId = req.params.id;
  const idx = memoryStore.savedJobs.findIndex(sj => sj.userId === user.id && sj.jobId === jobId);
  let isSaved = false;

  if (idx > -1) {
    memoryStore.savedJobs.splice(idx, 1);
  } else {
    memoryStore.savedJobs.push({ userId: user.id, jobId });
    isSaved = true;
  }

  res.json({ success: true, isSaved });
});

app.get('/api/jobs/saved', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.json({ savedJobs: [] });

  const savedJobIds = memoryStore.savedJobs.filter(sj => sj.userId === user.id).map(sj => sj.jobId);
  const jobs = memoryStore.jobs.filter(j => savedJobIds.includes(j.id)).map(j => ({ ...j, isSaved: true }));
  res.json({ savedJobs: jobs });
});

// ----------------------------------------------------
// Job Applications Routes
// ----------------------------------------------------
app.post('/api/jobs/:id/apply', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Sign in to apply' });

  const job = memoryStore.jobs.find(j => j.id === req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found' });

  const { applicantName, applicantEmail, applicantPhone, resumeFileName, portfolioUrl, coverNote, videoPitchUrl, videoPitchTitle, videoPitchDuration } = req.body;

  const newApp = {
    id: 'app-' + Date.now(),
    jobId: job.id,
    jobTitle: job.title,
    company: job.company,
    applicantId: user.id,
    applicantName: applicantName || user.name,
    applicantEmail: applicantEmail || user.email,
    applicantPhone: applicantPhone || '+1-555-0199',
    resumeFileName: resumeFileName || (user.name.replace(/\s+/g, '_') + '_Resume.pdf'),
    portfolioUrl: portfolioUrl || '',
    coverNote: coverNote || 'Excited to apply for this opportunity.',
    videoPitchUrl: videoPitchUrl || undefined,
    videoPitchTitle: videoPitchTitle || undefined,
    videoPitchDuration: videoPitchDuration || undefined,
    status: 'Submitted',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  memoryStore.applications.unshift(newApp);
  job.applicantsCount += 1;

  // Notify recruiter
  if (job.employerId) {
    memoryStore.notifications.unshift({
      id: 'notif-app-' + Date.now(),
      recipientId: job.employerId,
      actorId: user.id,
      actorName: user.name,
      actorAvatar: user.avatar,
      type: 'job_alert',
      title: 'New Candidate Application',
      message: user.name + ' applied for "' + job.title + '"',
      link: '/applications',
      read: false,
      createdAt: new Date().toISOString()
    });
  }

  res.json({ success: true, application: newApp });
});

app.get('/api/applications/my', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.json({ applications: [] });

  const userApps = memoryStore.applications.filter(a => a.applicantId === user.id);
  res.json({ applications: userApps });
});

app.get('/api/applications/employer', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });

  // Employer can see applications for their jobs (or all if admin)
  if (user.role === 'admin') {
    return res.json({ applications: memoryStore.applications });
  }

  const employerJobIds = memoryStore.jobs.filter(j => j.employerId === user.id).map(j => j.id);
  const apps = memoryStore.applications.filter(a => employerJobIds.includes(a.jobId));
  res.json({ applications: apps });
});

app.put('/api/applications/:id/status', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });

  const appItem = memoryStore.applications.find(a => a.id === req.params.id);
  if (!appItem) return res.status(404).json({ error: 'Application not found' });

  const { status } = req.body;
  const allowed = ['Submitted', 'Under Review', 'Shortlisted', 'Interview', 'Rejected', 'Hired'];
  if (!allowed.includes(status)) {
    return res.status(400).json({ error: 'Invalid application status' });
  }

  appItem.status = status;
  appItem.updatedAt = new Date().toISOString();

  // Notify applicant of status update!
  memoryStore.notifications.unshift({
    id: 'notif-st-' + Date.now(),
    recipientId: appItem.applicantId,
    actorId: user.id,
    actorName: appItem.company,
    type: 'job_status',
    title: 'Application Status: ' + status,
    message: 'Your application for "' + appItem.jobTitle + '" at ' + appItem.company + ' has been updated to "' + status + '".',
    link: '/applications',
    read: false,
    createdAt: new Date().toISOString()
  });

  res.json({ success: true, application: appItem });
});

// ----------------------------------------------------
// Notifications Routes
// ----------------------------------------------------
app.get('/api/notifications', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.json({ notifications: [] });

  const userNotifs = memoryStore.notifications.filter(n => n.recipientId === user.id || n.recipientId === 'all');
  res.json({ notifications: userNotifs });
});

app.get('/api/notifications/unread-count', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.json({ unreadCount: 0 });

  const count = memoryStore.notifications.filter(n => (n.recipientId === user.id || n.recipientId === 'all') && !n.read).length;
  res.json({ unreadCount: count });
});

app.put('/api/notifications/:id/read', (req, res) => {
  const notif = memoryStore.notifications.find(n => n.id === req.params.id);
  if (notif) notif.read = true;
  res.json({ success: true });
});

app.put('/api/notifications/read-all', (req, res) => {
  const user = getCurrentUser(req);
  if (user) {
    memoryStore.notifications.forEach(n => {
      if (n.recipientId === user.id || n.recipientId === 'all') n.read = true;
    });
  }
  res.json({ success: true });
});

// ----------------------------------------------------
// Subscriptions & Creators
// ----------------------------------------------------
app.get('/api/subscriptions/plans', (_req, res) => {
  res.json({ plans: SEED_PLANS });
});

app.post('/api/subscriptions/checkout', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Please sign in to subscribe' });

  const { tier } = req.body;
  const plan = SEED_PLANS.find(p => p.id === tier);
  if (!plan) return res.status(400).json({ error: 'Invalid membership plan tier' });

  user.membershipPlan = plan.id;

  memoryStore.notifications.unshift({
    id: 'notif-sub-' + Date.now(),
    recipientId: user.id,
    type: 'membership',
    title: 'Welcome to ' + plan.name + '!',
    message: 'Your membership has been activated with tier perks unlocked.',
    read: false,
    createdAt: new Date().toISOString()
  });

  res.json({
    success: true,
    message: 'Successfully upgraded to ' + plan.name + ' (Demo Mode).',
    user
  });
});

app.post('/api/creators/:id/follow', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Sign in to follow creators' });

  const targetCreator = memoryStore.users.find(u => u.id === req.params.id || u.username === req.params.id);
  if (!targetCreator) return res.status(404).json({ error: 'Creator not found' });

  const idx = memoryStore.follows.findIndex(f => f.followerId === user.id && f.targetId === targetCreator.id);
  let isFollowing = false;

  if (idx > -1) {
    memoryStore.follows.splice(idx, 1);
    targetCreator.subscribersCount = Math.max(0, targetCreator.subscribersCount - 1);
    user.followingCount = Math.max(0, user.followingCount - 1);
  } else {
    memoryStore.follows.push({ followerId: user.id, targetId: targetCreator.id });
    targetCreator.subscribersCount += 1;
    user.followingCount += 1;
    isFollowing = true;

    memoryStore.notifications.unshift({
      id: 'notif-fol-' + Date.now(),
      recipientId: targetCreator.id,
      actorId: user.id,
      actorName: user.name,
      actorAvatar: user.avatar,
      type: 'follow',
      title: 'New Subscriber',
      message: user.name + ' followed your channel.',
      link: '/profile/' + user.username,
      read: false,
      createdAt: new Date().toISOString()
    });
  }

  res.json({ success: true, isFollowing, subscribersCount: targetCreator.subscribersCount });
});

app.get('/api/creators/:username', (req, res) => {
  const creator = memoryStore.users.find(u => u.username.toLowerCase() === req.params.username.toLowerCase());
  if (!creator) return res.status(404).json({ error: 'Creator not found' });

  const user = getCurrentUser(req);
  const isFollowing = memoryStore.follows.some(f => f.followerId === user?.id && f.targetId === creator.id);
  const videos = memoryStore.videos.filter(v => v.creatorId === creator.id && v.visibility === 'public');

  res.json({ creator, isFollowing, videos });
});

// ----------------------------------------------------
// Direct Messages API
// ----------------------------------------------------
app.get('/api/messages/conversations', (_req, res) => {
  res.json({ conversations: memoryStore.conversations });
});

app.get('/api/messages/:convId', (req, res) => {
  const messages = memoryStore.messages.filter(m => m.conversationId === req.params.convId);
  res.json({ messages });
});

app.post('/api/messages', (req, res) => {
  const user = getCurrentUser(req);
  const { conversationId, text } = req.body;
  if (!text || !text.trim()) return res.status(400).json({ error: 'Message cannot be empty' });

  const newMsg = {
    id: 'm-' + Date.now(),
    conversationId: conversationId || 'conv-1',
    senderId: user.id,
    senderName: user.name,
    senderAvatar: user.avatar,
    text: text.trim(),
    createdAt: new Date().toISOString()
  };

  memoryStore.messages.push(newMsg);

  const conv = memoryStore.conversations.find(c => c.id === newMsg.conversationId);
  if (conv) {
    conv.lastMessage = newMsg.text;
    conv.lastMessageAt = newMsg.createdAt;
  }

  res.json({ success: true, message: newMsg });
});

// ----------------------------------------------------
// Reports & Moderation Submissions
// ----------------------------------------------------
app.post('/api/reports', (req, res) => {
  const user = getCurrentUser(req);
  const { targetType, targetId, targetTitle, reason, details } = req.body;

  const newReport = {
    id: 'rep-' + Date.now(),
    reporterId: user.id,
    reporterName: user.name,
    targetType: targetType || 'video',
    targetId: targetId || 'unknown',
    targetTitle: targetTitle || 'Reported item',
    reason: reason || 'Inappropriate content',
    details: details || '',
    status: 'pending',
    createdAt: new Date().toISOString()
  };

  memoryStore.reports.unshift(newReport);
  res.json({ success: true, message: 'Report submitted for review.' });
});

// ----------------------------------------------------
// Protected Administrative Routes (Backed by admin.js)
// ----------------------------------------------------
function requireAdmin(req, res, next) {
  const user = getCurrentUser(req);
  if (user?.role !== 'admin') {
    return res.status(403).json({ error: 'Access forbidden: Administrative credentials required.' });
  }
  next();
}

app.get('/api/admin/metrics', requireAdmin, async (_req, res) => {
  try {
    const metrics = await adminService.getPlatformMetrics();
    res.json(metrics);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/admin/users', requireAdmin, async (req, res) => {
  try {
    const { search, role, status, page } = req.query;
    const result = await adminService.listUsers({
      search: String(search || ''),
      role: String(role || ''),
      status: String(status || ''),
      page: Number(page) || 1
    });
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/admin/users/:id/status', requireAdmin, async (req, res) => {
  try {
    const adminUser = getCurrentUser(req);
    const { status } = req.body;
    const result = await adminService.updateUserStatus(req.params.id, status, adminUser);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/admin/users/:id/role', requireAdmin, async (req, res) => {
  try {
    const adminUser = getCurrentUser(req);
    const { role, verified } = req.body;
    const result = await adminService.updateUserRole(req.params.id, { role, verified }, adminUser);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/admin/videos/:id/moderation', requireAdmin, async (req, res) => {
  try {
    const adminUser = getCurrentUser(req);
    const { moderationStatus } = req.body;
    const result = await adminService.moderateVideo(req.params.id, moderationStatus, adminUser);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/admin/jobs/:id/moderation', requireAdmin, async (req, res) => {
  try {
    const adminUser = getCurrentUser(req);
    const { status, featured } = req.body;
    const result = await adminService.moderateJob(req.params.id, { status, featured }, adminUser);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/admin/reports', requireAdmin, (_req, res) => {
  res.json({ reports: memoryStore.reports });
});

app.put('/api/admin/reports/:id/resolve', requireAdmin, async (req, res) => {
  try {
    const adminUser = getCurrentUser(req);
    const { status } = req.body;
    const result = await adminService.resolveReport(req.params.id, status, adminUser);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/admin/announcements', requireAdmin, async (req, res) => {
  try {
    const adminUser = getCurrentUser(req);
    const { title, message, target } = req.body;
    const result = await adminService.sendAdminAnnouncement(title, message, target, adminUser);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/admin/audit-logs', requireAdmin, async (_req, res) => {
  try {
    const logs = await adminService.getAuditLogs();
    res.json({ auditLogs: logs });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ----------------------------------------------------
// Online Shopping Store & Listings API
// ----------------------------------------------------
app.get('/api/store/products', (req, res) => {
  try {
    let list = [...(memoryStore.storeProducts || [])];
    const { category, search, sellerId, sort, featured } = req.query;

    if (category && category !== 'all') {
      list = list.filter(p => p.category === category);
    }

    if (sellerId) {
      list = list.filter(p => p.sellerId === sellerId);
    }

    if (featured === 'true') {
      list = list.filter(p => p.isFeatured);
    }

    if (search && search.trim()) {
      const q = search.toLowerCase().trim();
      list = list.filter(p =>
        p.title.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q) ||
        (p.tags && p.tags.some(t => t.toLowerCase().includes(q)))
      );
    }

    if (sort === 'price_asc') {
      list.sort((a, b) => a.price - b.price);
    } else if (sort === 'price_desc') {
      list.sort((a, b) => b.price - a.price);
    } else if (sort === 'rating') {
      list.sort((a, b) => b.rating - a.rating);
    } else {
      // Default: newest first or featured
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }

    res.json({ products: list, total: list.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/store/products/:id', (req, res) => {
  const product = (memoryStore.storeProducts || []).find(p => p.id === req.params.id);
  if (!product) {
    return res.status(404).json({ error: 'Product not found' });
  }
  res.json({ product });
});

app.post('/api/store/products', (req, res) => {
  try {
    const currentUser = getCurrentUser(req);
    const {
      title,
      description,
      category,
      categoryName,
      price,
      compareAtPrice,
      condition,
      stock,
      images,
      thumbnailUrl,
      features,
      specifications,
      brand,
      shippingInfo,
      tags
    } = req.body;

    if (!title || !price) {
      return res.status(400).json({ error: 'Title and price are required to list a product.' });
    }

    const categoryLabels = {
      electronics: 'Electronics & Tech Gadgets',
      fashion: 'Fashion & Apparel',
      home_living: 'Home, Kitchen & Living',
      tools_diy: 'Tools, Hardware & DIY',
      sports_fitness: 'Sports, Fitness & Outdoor',
      digital_assets: 'Digital Assets, Software & Templates',
      creator_merch: 'Creator Merch & Swag',
      industrial_facade: 'Industrial, Architectural & Façade',
      facade_hardware: 'Façade Hardware & Glass Lifters',
      fabrication_tools: 'Fabrication & Site Tools',
      safety_gear: 'Safety Gear & Site PPE',
      machinery: 'Heavy Machinery & Fabrication Plant',
      bim_templates: 'BIM & Digital Engineering Assets'
    };

    const newProduct = {
      id: 'prod-' + Date.now(),
      title: title.trim(),
      description: description ? description.trim() : 'Quality product listed on World Video Hub Store.',
      category: category || 'electronics',
      categoryName: categoryName || categoryLabels[category] || 'Electronics & Tech Gadgets',
      price: Number(price),
      compareAtPrice: compareAtPrice ? Number(compareAtPrice) : undefined,
      currency: 'USD',
      condition: condition || 'new',
      rating: 5.0,
      reviewsCount: 1,
      stock: stock ? Number(stock) : 10,
      images: Array.isArray(images) && images.length > 0 ? images : [
        thumbnailUrl || 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=800&h=600&fit=crop'
      ],
      thumbnailUrl: thumbnailUrl || (Array.isArray(images) && images[0]) || 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=600&h=450&fit=crop',
      features: Array.isArray(features) && features.length > 0 ? features : [
        'Certified engineering specification',
        'Direct creator / manufacturer backed warranty',
        'Express dispatch & verified tracking'
      ],
      specifications: specifications && typeof specifications === 'object' ? specifications : {
        'Quality Standard': 'Architectural Grade 6063-T6 / EN Standard',
        'Inspection': '100% Pre-Shipment Tested'
      },
      brand: brand ? brand.trim() : (currentUser.displayName || currentUser.name || 'World Video Hub Store'),
      sellerId: currentUser.id,
      sellerName: currentUser.displayName || currentUser.name,
      sellerAvatar: currentUser.avatar,
      sellerVerified: Boolean(currentUser.verified),
      shippingInfo: shippingInfo || {
        freeShipping: true,
        estimatedDelivery: '2–4 Business Days (Express)',
        shipsFrom: currentUser.country || 'Saudi Arabia'
      },
      tags: Array.isArray(tags) ? tags : ['Store', 'EngineeringTools'],
      isFeatured: false,
      isCreatorProduct: true,
      createdAt: new Date().toISOString()
    };

    if (!memoryStore.storeProducts) memoryStore.storeProducts = [];
    memoryStore.storeProducts.unshift(newProduct);

    res.status(201).json({
      success: true,
      product: newProduct,
      message: 'Product listed successfully in the online store!'
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/store/products/:id', (req, res) => {
  try {
    const currentUser = getCurrentUser(req);
    const index = (memoryStore.storeProducts || []).findIndex(p => p.id === req.params.id);
    if (index === -1) {
      return res.status(404).json({ error: 'Product not found' });
    }

    const prod = memoryStore.storeProducts[index];
    if (prod.sellerId !== currentUser.id && currentUser.role !== 'admin') {
      return res.status(403).json({ error: 'You are not authorized to delete this store listing.' });
    }

    memoryStore.storeProducts.splice(index, 1);
    res.json({ success: true, message: 'Product listing removed from store.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/store/orders', (req, res) => {
  try {
    const currentUser = getCurrentUser(req);
    const { items, shippingAddress, paymentMethod, couponCode } = req.body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'Cart is empty. Please add items to checkout.' });
    }

    let subtotal = 0;
    const orderItems = items.map(item => {
      const price = Number(item.price || item.product?.price || 0);
      const qty = Number(item.quantity || 1);
      subtotal += price * qty;

      // Decrement inventory stock
      const prodId = item.productId || item.product?.id;
      const foundProduct = (memoryStore.storeProducts || []).find(p => p.id === prodId);
      if (foundProduct && foundProduct.stock > 0) {
        foundProduct.stock = Math.max(0, foundProduct.stock - qty);
      }

      return {
        productId: prodId,
        title: item.title || item.product?.title,
        price,
        quantity: qty,
        thumbnailUrl: item.thumbnailUrl || item.product?.thumbnailUrl
      };
    });

    let discount = 0;
    if (couponCode) {
      const code = couponCode.toUpperCase().trim();
      if (code === 'STORE20') {
        discount = subtotal * 0.20;
      } else if (code === 'ALUM2026' || code === 'SHAFI15' || code === 'GLOBAL15') {
        discount = subtotal * 0.15;
      } else if (code === 'WELCOME10') {
        discount = subtotal * 0.10;
      }
    }

    const shippingFee = subtotal > 150 ? 0 : 15.00;
    const total = Math.max(0, subtotal - discount + shippingFee);

    const newOrder = {
      id: 'ORD-' + Math.floor(100000 + Math.random() * 900000),
      userId: currentUser.id,
      userName: currentUser.displayName || currentUser.name,
      userEmail: currentUser.email,
      items: orderItems,
      subtotal,
      shippingFee,
      discount,
      total,
      currency: 'USD',
      shippingAddress: shippingAddress || {
        fullName: currentUser.displayName || currentUser.name,
        street: 'King Fahd Road, Al Olaya District',
        city: 'Riyadh',
        country: 'Saudi Arabia',
        postalCode: '12214',
        phone: currentUser.phone || '+966 50 123 4567'
      },
      paymentMethod: paymentMethod || 'mada',
      status: 'processing',
      trackingNumber: 'SA-EXP-' + Math.floor(10000000 + Math.random() * 90000000),
      createdAt: new Date().toISOString()
    };

    if (!memoryStore.storeOrders) memoryStore.storeOrders = [];
    memoryStore.storeOrders.unshift(newOrder);

    res.status(201).json({
      success: true,
      order: newOrder,
      message: 'Order placed successfully! Confirmation email and tracking details dispatched.'
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/store/orders', (req, res) => {
  try {
    const currentUser = getCurrentUser(req);
    const userOrders = (memoryStore.storeOrders || []).filter(o => o.userId === currentUser.id || currentUser.role === 'admin');
    res.json({ orders: userOrders });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log('[VideoHub + Global Jobs] Server active at http://localhost:' + PORT);
  });
}

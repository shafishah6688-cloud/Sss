// ========================================================
// Automated Test Suite for VideoHub + Global Jobs
// Validates:
// 1. User registration & login
// 2. Role permissions & security
// 3. Video metadata & upload validation
// 4. Follow and like actions
// 5. Notification creation and read states
// 6. Job search & filtering logic
// 7. Job applications & ATS state transitions
// 8. Admin authorization & admin.js operations
// 9. Subscription tiers & checkout verification
// ========================================================

import assert from 'assert';
// @ts-ignore
import { memoryStore } from '../db.js';
// @ts-ignore
import * as adminService from '../admin.js';
// @ts-ignore
import { SEED_USERS, SEED_VIDEOS, SEED_JOBS, SEED_PLANS } from '../seed-data.js';

let passedTests = 0;
let failedTests = 0;

async function test(name: string, fn: () => Promise<void> | void) {
  try {
    await fn();
    console.log(`  ✓ [PASS] ${name}`);
    passedTests++;
  } catch (error: any) {
    console.error(`  ✗ [FAIL] ${name}`);
    console.error(`    -> ${error.message}`);
    failedTests++;
  }
}

async function runAllTests() {
  console.log('\n========================================================');
  console.log('🧪 RUNNING VIDEOHUB + GLOBAL JOBS TEST SUITE');
  console.log('========================================================\n');

  // Test 1: User Registration & Login
  await test('Registration & Login creates valid user structure', () => {
    const candidate = memoryStore.users.find((u: any) => u.id === 'u-candidate1');
    assert.ok(candidate, 'Candidate user must exist');
    assert.strictEqual(candidate.role, 'user');
    assert.ok(candidate.email.includes('@'), 'Valid email format required');
  });

  // Test 2: User Permissions & Roles
  await test('Admin permissions verification', () => {
    const admin = memoryStore.users.find((u: any) => u.role === 'admin');
    assert.ok(admin, 'Admin account must exist in registry');
    assert.strictEqual(admin.verified, true, 'Admin should be verified');
  });

  // Test 3: Video metadata creation & validation
  await test('Video metadata and categories validation', () => {
    const facadeVideo = memoryStore.videos.find((v: any) => v.id === 'v-1');
    assert.ok(facadeVideo, 'Video v-1 must exist');
    assert.strictEqual(facadeVideo.category, 'Aluminium & Façade Engineering');
    assert.ok(facadeVideo.duration, 'Duration must be populated');
    assert.ok(facadeVideo.tags.length > 0, 'Tags array must not be empty');
  });

  // Test 4: Follow and Like operations
  await test('Like action and follow action integrity', () => {
    const initialLikes = memoryStore.videos[0].likesCount;
    // Simulate like
    memoryStore.likedVideos.push({ userId: 'u-user2', videoId: memoryStore.videos[0].id });
    memoryStore.videos[0].likesCount += 1;
    assert.strictEqual(memoryStore.videos[0].likesCount, initialLikes + 1);
  });

  // Test 5: Notification creation and read state
  await test('Notification generation and read status update', () => {
    const notif = memoryStore.notifications[0];
    assert.ok(notif, 'At least one notification should be seeded');
    const wasRead = notif.read;
    notif.read = true;
    assert.strictEqual(notif.read, true);
  });

  // Test 6: Job search and category filtering
  await test('Job search filtering by Façade Engineering industry', () => {
    const facadeJobs = memoryStore.jobs.filter((j: any) => j.category === 'Aluminium & Façade Engineering');
    assert.ok(facadeJobs.length >= 2, 'Should find at least 2 aluminium & façade jobs');
    assert.ok(facadeJobs[0].salaryMin > 0, 'Salary must be greater than zero');
  });

  // Test 7: Job applications & candidate submission
  await test('Job application creation and status lifecycle', () => {
    const app = memoryStore.applications[0];
    assert.ok(app, 'Sample job application must exist');
    assert.ok(['Submitted', 'Under Review', 'Shortlisted', 'Interview', 'Hired', 'Rejected'].includes(app.status));
    assert.ok(app.resumeFileName.endsWith('.pdf'), 'Resume must be a document file');
  });

  // Test 8: Admin authorization and admin.js operations
  await test('admin.js service functions for user management and audit logging', async () => {
    const adminUser = memoryStore.users.find((u: any) => u.role === 'admin');
    const metrics = await adminService.getPlatformMetrics();
    assert.ok(metrics.totalUsers > 0, 'Total users metric must be positive');
    assert.ok(metrics.totalJobs > 0, 'Total jobs metric must be positive');

    // Test logAdminAction
    const log = await adminService.logAdminAction(adminUser, 'TEST_EXECUTION', 'Automated test verification');
    assert.strictEqual(log.action, 'TEST_EXECUTION');
  });

  // Test 9: Creator Membership Plans & Checkout validation
  await test('Membership plans hierarchy and pricing validation', () => {
    assert.strictEqual(SEED_PLANS.length, 4, 'Must have 4 defined membership plans');
    const freePlan = SEED_PLANS.find((p: any) => p.id === 'free');
    const proPlan = SEED_PLANS.find((p: any) => p.id === 'pro_creator');
    const recruiterPlan = SEED_PLANS.find((p: any) => p.id === 'business_recruiter');

    assert.strictEqual(freePlan?.priceMonthly, 0);
    assert.strictEqual(proPlan?.priceMonthly, 9.99);
    assert.strictEqual(recruiterPlan?.priceMonthly, 19.99);
  });

  console.log('\n--------------------------------------------------------');
  console.log(`TOTAL TESTS: ${passedTests + failedTests} | PASSED: ${passedTests} | FAILED: ${failedTests}`);
  console.log('--------------------------------------------------------\n');

  if (failedTests > 0) {
    process.exit(1);
  }
}

runAllTests().catch((err) => {
  console.error('Fatal test runner error:', err);
  process.exit(1);
});

export const SEED_PLANS = [
  {
    id: 'free',
    name: 'Free Explorer',
    priceMonthly: 0,
    tagline: 'Stream videos, follow creators, and discover global opportunities.',
    badge: 'Explorer',
    badgeColor: 'bg-slate-100 text-slate-700',
    perks: [
      'Watch unlimited 4K & short videos',
      'Follow your favorite creators',
      'Search worldwide engineering & tech jobs',
      'Apply for up to 3 jobs per month',
      'Community comments and discussions'
    ]
  },
  {
    id: 'creator_plus',
    name: 'Creator Plus',
    priceMonthly: 4.99,
    tagline: 'Ideal for emerging creators and dedicated followers.',
    badge: 'Creator+',
    badgeColor: 'bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300',
    recommended: true,
    perks: [
      'Custom subscriber badge in comments & chats',
      'Early access to creator long-form videos',
      'Full HD & 4K video uploads up to 60 min',
      'Unlimited job applications',
      'Ad-free video playback experience'
    ]
  },
  {
    id: 'pro_creator',
    name: 'Pro Creator',
    priceMonthly: 9.99,
    tagline: 'Advanced publishing and detailed audience analytics.',
    badge: 'PRO',
    badgeColor: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300',
    perks: [
      'Verified channel checkmark eligibility',
      'Deep audience & video retention analytics',
      'Direct messaging with verified employers',
      'Custom channel banner & featured playlists',
      'Priority video encoding queue'
    ]
  },
  {
    id: 'business_recruiter',
    name: 'Business Recruiter',
    priceMonthly: 19.99,
    tagline: 'Comprehensive recruitment and talent sourcing portal.',
    badge: 'Recruiter',
    badgeColor: 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300',
    perks: [
      'Post unlimited job vacancies worldwide',
      'Applicant tracking & status management dashboard',
      'Direct candidate messaging & resume downloads',
      'Featured job listing boost on home feed',
      'Dedicated company profile badge'
    ]
  }
];

export const SEED_USERS = [
  {
    id: 'u-admin',
    name: 'Shafi Afzal Shah',
    username: 'shafi_shah',
    email: 'shafi@dometech.sa',
    avatar: '/assets/aistudio/Screenshot_20240115_120152_DWG_FastView_e3b92bfb.jpg',
    banner: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&h=400&fit=crop',
    bio: 'Platform Lead & Chief Administrator at VideoHub + Global Jobs.',
    country: 'Saudi Arabia',
    role: 'admin',
    verified: true,
    membershipPlan: 'pro_creator',
    subscribersCount: 28400,
    followingCount: 42,
    status: 'active',
    createdAt: '2025-01-15T08:00:00Z'
  },
  {
    id: 'u-facade',
    name: 'Façade Engineering Academy',
    username: 'facade_academy',
    email: 'info@facadeacademy.example.com',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=faces',
    banner: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=1200&h=400&fit=crop',
    bio: 'Mastering modern curtain walls, unitized façades, structural glazing, and thermal barrier engineering.',
    country: 'Germany',
    role: 'creator',
    verified: true,
    membershipPlan: 'pro_creator',
    subscribersCount: 89300,
    followingCount: 15,
    status: 'active',
    createdAt: '2025-02-10T10:30:00Z'
  },
  {
    id: 'u-construction',
    name: 'Construction Skills Hub',
    username: 'constructionskills',
    email: 'skills@construct.example.com',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=faces',
    banner: 'https://images.unsplash.com/photo-1541888946425-d0fbb186c5f9?w=1200&h=400&fit=crop',
    bio: 'Practical tutorials on civil engineering, site execution, BIM workflow, and crane safety standards.',
    country: 'United States',
    role: 'creator',
    verified: true,
    membershipPlan: 'creator_plus',
    subscribersCount: 124500,
    followingCount: 38,
    status: 'active',
    createdAt: '2025-01-20T12:00:00Z'
  },
  {
    id: 'u-tech',
    name: 'Tech Explorer Lab',
    username: 'techexplorer',
    email: 'contact@techexplorer.example.com',
    avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=200&h=200&fit=crop&crop=faces',
    banner: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=1200&h=400&fit=crop',
    bio: 'Hands-on architectural software reviews, full-stack dev architectures, and high-performance computing.',
    country: 'Canada',
    role: 'creator',
    verified: true,
    membershipPlan: 'pro_creator',
    subscribersCount: 210000,
    followingCount: 64,
    status: 'active',
    createdAt: '2025-01-05T09:00:00Z'
  },
  {
    id: 'u-recruiter1',
    name: 'Apex Façade Systems Talent',
    username: 'apex_recruiter',
    email: 'talent@apexfacade.example.com',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&h=200&fit=crop&crop=faces',
    banner: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=1200&h=400&fit=crop',
    bio: 'Global talent acquisition for premier architectural glazing and unitized curtain wall installations worldwide.',
    country: 'United Arab Emirates',
    role: 'employer',
    verified: true,
    membershipPlan: 'business_recruiter',
    subscribersCount: 15400,
    followingCount: 120,
    status: 'active',
    createdAt: '2025-02-01T14:00:00Z'
  },
  {
    id: 'u-candidate1',
    name: 'Tariq Mansoor',
    username: 'tariq_eng',
    email: 'tariq@engineer.example.com',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&h=200&fit=crop&crop=faces',
    banner: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?w=1200&h=400&fit=crop',
    bio: 'Façade Design Engineer specializing in AutoCAD, Revit BIM, and thermal deflection calculations.',
    country: 'Saudi Arabia',
    role: 'user',
    verified: false,
    membershipPlan: 'creator_plus',
    subscribersCount: 820,
    followingCount: 75,
    status: 'active',
    createdAt: '2025-03-01T11:00:00Z'
  },
  {
    id: 'u-travel',
    name: 'Global Travel Stories',
    username: 'globaltravel',
    email: 'stories@travel.example.com',
    avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&h=200&fit=crop&crop=faces',
    banner: 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=1200&h=400&fit=crop',
    bio: 'Cinematic travelogues exploring the world’s most iconic architectural wonders and futuristic skylines.',
    country: 'Japan',
    role: 'creator',
    verified: true,
    membershipPlan: 'creator_plus',
    subscribersCount: 345000,
    followingCount: 88,
    status: 'active',
    createdAt: '2025-01-12T16:00:00Z'
  },
  {
    id: 'u-creative',
    name: 'Creative World Studio',
    username: 'creativeworld',
    email: 'hello@creativeworld.example.com',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&h=200&fit=crop&crop=faces',
    banner: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=1200&h=400&fit=crop',
    bio: 'Motion graphics, 3D visualization, claymorphic UI/UX design, and creative storytelling.',
    country: 'France',
    role: 'creator',
    verified: true,
    membershipPlan: 'pro_creator',
    subscribersCount: 178000,
    followingCount: 92,
    status: 'active',
    createdAt: '2025-02-14T09:30:00Z'
  },
  {
    id: 'u-future',
    name: 'Future Makers & Robotics',
    username: 'futuremakers',
    email: 'makers@future.example.com',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=200&h=200&fit=crop&crop=faces',
    banner: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=1200&h=400&fit=crop',
    bio: 'Automated façade fabrication, robotic CNC cutting, glass tempering robotics, and next-gen construction tech.',
    country: 'South Korea',
    role: 'creator',
    verified: true,
    membershipPlan: 'creator_plus',
    subscribersCount: 95000,
    followingCount: 41,
    status: 'active',
    createdAt: '2025-01-28T15:20:00Z'
  },
  {
    id: 'u-recruiter2',
    name: 'Metro Civils & Building Group',
    username: 'metrocivils',
    email: 'careers@metrocivils.example.com',
    avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=200&h=200&fit=crop&crop=faces',
    banner: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=1200&h=400&fit=crop',
    bio: 'International infrastructure contractor hiring project managers, structural engineers, and BIM specialists.',
    country: 'Singapore',
    role: 'employer',
    verified: true,
    membershipPlan: 'business_recruiter',
    subscribersCount: 22100,
    followingCount: 110,
    status: 'active',
    createdAt: '2025-02-05T10:15:00Z'
  },
  {
    id: 'u-bim',
    name: 'Revit & BIM Masterclass',
    username: 'bim_mastery',
    email: 'tutorials@bim.example.com',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop&crop=faces',
    banner: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=1200&h=400&fit=crop',
    bio: 'End-to-end building information modeling, parametric family creation, clash detection, and Dynamo scripting.',
    country: 'Australia',
    role: 'creator',
    verified: true,
    membershipPlan: 'creator_plus',
    subscribersCount: 71200,
    followingCount: 29,
    status: 'active',
    createdAt: '2025-02-22T08:45:00Z'
  },
  {
    id: 'u-user2',
    name: 'Elena Rostova',
    username: 'elena_design',
    email: 'elena@arch.example.com',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&h=200&fit=crop&crop=faces',
    banner: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?w=1200&h=400&fit=crop',
    bio: 'Architectural graduate and curtain wall enthusiast seeking international opportunities.',
    country: 'Italy',
    role: 'user',
    verified: false,
    membershipPlan: 'free',
    subscribersCount: 420,
    followingCount: 154,
    status: 'active',
    createdAt: '2025-03-05T13:10:00Z'
  }
];

export const SEED_VIDEOS = [
  {
    id: 'v-1',
    title: 'Modern Unitized Curtain Wall Installation: Structural Testing & On-Site Assembly',
    description: 'A comprehensive visual walkthrough of unitized curtain wall installation on a 52-story commercial tower. Learn how female-male profile interlocking handles seismic displacement and water infiltration under hurricane-force wind loads.',
    videoUrl: '/api/media/stream/video1.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800&h=450&fit=crop',
    duration: '14:28',
    category: 'Aluminium & Façade Engineering',
    tags: ['FaçadeEngineering', 'CurtainWall', 'Aluminium', 'Construction', 'Architecture'],
    creatorId: 'u-facade',
    creator: {
      name: 'Façade Engineering Academy',
      username: 'facade_academy',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=faces',
      verified: true
    },
    views: 48920,
    likesCount: 3120,
    commentsCount: 142,
    isLiked: false,
    isShort: false,
    visibility: 'public',
    commentsEnabled: true,
    processingStatus: 'ready',
    moderationStatus: 'approved',
    chapters: [
      { timestamp: 0, title: 'Introduction & Structural Overview' },
      { timestamp: 42, title: 'Female-Male Profile Interlocking' },
      { timestamp: 95, title: 'Seismic & Hurricane Wind Testing' },
      { timestamp: 160, title: 'On-Site Crane Hoisting & Glazing' },
      { timestamp: 240, title: 'Quality Assurance & Air/Water Seal Inspection' }
    ],
    createdAt: '2025-03-10T14:20:00Z'
  },
  {
    id: 'v-2',
    title: 'Top 7 Aluminium Extrusion Dies & Thermal Break Systems Explained',
    description: 'Polyamide thermal breaks vs resin pour-and-debridge systems. In this deep dive, we examine cross-sections, structural load bearing, and thermal conductance coefficients (U-values) for modern high-performance fenestration.',
    videoUrl: '/api/media/stream/video2.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=800&h=450&fit=crop',
    duration: '18:45',
    category: 'Aluminium & Façade Engineering',
    tags: ['Aluminium', 'ThermalBreak', 'Extrusions', 'FaçadeEngineering', 'Glazing'],
    creatorId: 'u-facade',
    creator: {
      name: 'Façade Engineering Academy',
      username: 'facade_academy',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=faces',
      verified: true
    },
    views: 32400,
    likesCount: 2450,
    commentsCount: 98,
    isLiked: false,
    isShort: false,
    visibility: 'public',
    commentsEnabled: true,
    processingStatus: 'ready',
    moderationStatus: 'approved',
    chapters: [
      { timestamp: 0, title: 'Overview of Extrusion Profiles' },
      { timestamp: 35, title: 'Polyamide 6.6 vs Cast Resin Bars' },
      { timestamp: 90, title: 'Thermal Transmittance (U-Value) Calculations' },
      { timestamp: 155, title: 'Structural Deflection Under Positive Wind' },
      { timestamp: 220, title: 'Anodizing & Powder Coating Thicknesses' }
    ],
    createdAt: '2025-03-02T10:00:00Z'
  },
  {
    id: 'v-short-1',
    title: 'How Spider Glass Fittings Hold Up 10-Meter Glass Panels! 🏢💥',
    description: 'Stainless steel point-fixed articulation under tension test! Watch the deflection recovery.',
    videoUrl: '/api/media/stream/video1.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1506157786151-b8491531f063?w=600&h=1000&fit=crop',
    duration: '0:42',
    category: 'Curtain Wall & Glazing',
    tags: ['SpiderGlazing', 'Shorts', 'Engineering', 'Architecture'],
    creatorId: 'u-facade',
    creator: {
      name: 'Façade Engineering Academy',
      username: 'facade_academy',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=faces',
      verified: true
    },
    views: 184500,
    likesCount: 16700,
    commentsCount: 420,
    isLiked: false,
    isShort: true,
    visibility: 'public',
    commentsEnabled: true,
    processingStatus: 'ready',
    moderationStatus: 'approved',
    createdAt: '2025-03-12T08:15:00Z'
  },
  {
    id: 'v-3',
    title: 'Revit 2026 Curtain Wall Parametric Mullion Masterclass',
    description: 'Step by step tutorial modeling complex double-curved curtain wall panels in Revit with customized mullion profiles, corner joints, and adaptive components exported directly to IFC format.',
    videoUrl: '/api/media/stream/video3.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=800&h=450&fit=crop',
    duration: '22:10',
    category: 'Revit & BIM',
    tags: ['Revit', 'BIM', 'AutoCAD', 'CurtainWall', 'Drafting'],
    creatorId: 'u-bim',
    creator: {
      name: 'Revit & BIM Masterclass',
      username: 'bim_mastery',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop&crop=faces',
      verified: true
    },
    views: 64100,
    likesCount: 4890,
    commentsCount: 230,
    isLiked: false,
    isShort: false,
    visibility: 'public',
    commentsEnabled: true,
    processingStatus: 'ready',
    moderationStatus: 'approved',
    createdAt: '2025-03-08T16:45:00Z'
  },
  {
    id: 'v-short-2',
    title: 'Massive CNC Aluminium Milling Machine in Action! ⚙️⚡',
    description: 'Precision 5-axis profile machining for high-rise unitized transoms. Look at the chip evacuation!',
    videoUrl: '/api/media/stream/video2.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=600&h=1000&fit=crop',
    duration: '0:35',
    category: 'Manufacturing & Fabrication',
    tags: ['CNC', 'Aluminium', 'Shorts', 'Engineering', 'Fabrication'],
    creatorId: 'u-future',
    creator: {
      name: 'Future Makers & Robotics',
      username: 'futuremakers',
      avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=200&h=200&fit=crop&crop=faces',
      verified: true
    },
    views: 295000,
    likesCount: 28400,
    commentsCount: 610,
    isLiked: false,
    isShort: true,
    visibility: 'public',
    commentsEnabled: true,
    processingStatus: 'ready',
    moderationStatus: 'approved',
    createdAt: '2025-03-14T11:20:00Z'
  },
  {
    id: 'v-4',
    title: 'Futuristic Megaprojects: The Architecture of Sustainable Supertalls',
    description: 'Exploring the aerodynamic façades, vortex-shedding openings, and solar photovoltaic glazing embedded into the next generation of 600m+ megatall structures.',
    videoUrl: '/api/media/stream/video4.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&h=450&fit=crop',
    duration: '28:15',
    category: 'Architectural Engineering',
    tags: ['Architecture', 'Megaprojects', 'Skyscrapers', 'GreenBuilding', 'Engineering'],
    creatorId: 'u-travel',
    creator: {
      name: 'Global Travel Stories',
      username: 'globaltravel',
      avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&h=200&fit=crop&crop=faces',
      verified: true
    },
    views: 112000,
    likesCount: 8900,
    commentsCount: 450,
    isLiked: false,
    isShort: false,
    visibility: 'public',
    commentsEnabled: true,
    processingStatus: 'ready',
    moderationStatus: 'approved',
    createdAt: '2025-02-25T17:30:00Z'
  },
  {
    id: 'v-short-3',
    title: 'Cracking the AutoCAD Façade Detail in 30 Seconds! 📐✏️',
    description: 'Fast thermal insulator snap tricks in AutoCAD 2026. Bookmark this for your drafting exam.',
    videoUrl: '/api/media/stream/video3.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=600&h=1000&fit=crop',
    duration: '0:29',
    category: 'AutoCAD Drafting',
    tags: ['AutoCAD', 'Shorts', 'Drafting', 'CurtainWall'],
    creatorId: 'u-construction',
    creator: {
      name: 'Construction Skills Hub',
      username: 'constructionskills',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=faces',
      verified: true
    },
    views: 89400,
    likesCount: 7200,
    commentsCount: 154,
    isLiked: false,
    isShort: true,
    visibility: 'public',
    commentsEnabled: true,
    processingStatus: 'ready',
    moderationStatus: 'approved',
    createdAt: '2025-03-15T09:10:00Z'
  },
  {
    id: 'v-5',
    title: 'Building a Full-Stack Video & Job Platform with Claymorphic UI in 2026',
    description: 'Watch the entire architecture unfold: Node.js 24 runtime, Express serverless routing, MongoDB schemas, and vibrant claymorphic soft 3D design components.',
    videoUrl: '/api/media/stream/video5.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&h=450&fit=crop',
    duration: '34:00',
    category: 'Software & IT',
    tags: ['WebDev', 'React', 'FullStack', 'TailwindCSS', 'Claymorphism'],
    creatorId: 'u-tech',
    creator: {
      name: 'Tech Explorer Lab',
      username: 'techexplorer',
      avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=200&h=200&fit=crop&crop=faces',
      verified: true
    },
    views: 82300,
    likesCount: 6540,
    commentsCount: 312,
    isLiked: false,
    isShort: false,
    visibility: 'public',
    commentsEnabled: true,
    processingStatus: 'ready',
    moderationStatus: 'approved',
    createdAt: '2025-03-01T12:00:00Z'
  },
  {
    id: 'v-short-4',
    title: 'Claymorphic Button 3D Inset Shadows: Pure CSS Magic! 🎨✨',
    description: 'How to craft soft clay buttons that feel irresistible to click!',
    videoUrl: '/api/media/stream/video4.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&h=1000&fit=crop',
    duration: '0:38',
    category: 'Creative Media',
    tags: ['UIUX', 'Claymorphism', 'Design', 'CSS', 'Shorts'],
    creatorId: 'u-creative',
    creator: {
      name: 'Creative World Studio',
      username: 'creativeworld',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&h=200&fit=crop&crop=faces',
      verified: true
    },
    views: 142000,
    likesCount: 19800,
    commentsCount: 388,
    isLiked: false,
    isShort: true,
    visibility: 'public',
    commentsEnabled: true,
    processingStatus: 'ready',
    moderationStatus: 'approved',
    createdAt: '2025-03-16T14:40:00Z'
  },
  {
    id: 'v-6',
    title: 'Site Safety & Tower Crane Rigging for High-Rise Curtain Wall Panels',
    description: 'Crucial health & safety protocols when hoisting 800kg glazed unitized panels in windy high-rise conditions. Tag line management, suction cup testing, and rigging inspection.',
    videoUrl: '/api/media/stream/video1.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1541888946425-d0fbb186c5f9?w=800&h=450&fit=crop',
    duration: '16:50',
    category: 'Construction Management',
    tags: ['SiteSafety', 'Rigging', 'CurtainWall', 'ConstructionManagement'],
    creatorId: 'u-construction',
    creator: {
      name: 'Construction Skills Hub',
      username: 'constructionskills',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=faces',
      verified: true
    },
    views: 39100,
    likesCount: 2900,
    commentsCount: 110,
    isLiked: false,
    isShort: false,
    visibility: 'public',
    commentsEnabled: true,
    processingStatus: 'ready',
    moderationStatus: 'approved',
    createdAt: '2025-02-18T15:10:00Z'
  },
  {
    id: 'v-7',
    title: 'Glass Coating Tech: Low-E, Solar Control, and Ceramic Fritting Comparison',
    description: 'How to select the right spectrally selective glass coating. We analyze solar heat gain coefficients (SHGC), visible light transmission (VLT), and external reflection values.',
    videoUrl: '/api/media/stream/video2.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&h=450&fit=crop',
    duration: '21:12',
    category: 'Curtain Wall & Glazing',
    tags: ['GlassCoating', 'LowE', 'FaçadeEngineering', 'Sustainability'],
    creatorId: 'u-facade',
    creator: {
      name: 'Façade Engineering Academy',
      username: 'facade_academy',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=faces',
      verified: true
    },
    views: 45200,
    likesCount: 3410,
    commentsCount: 168,
    isLiked: false,
    isShort: false,
    visibility: 'public',
    commentsEnabled: true,
    processingStatus: 'ready',
    moderationStatus: 'approved',
    createdAt: '2025-02-10T11:30:00Z'
  },
  {
    id: 'v-short-5',
    title: 'Water Infiltration Chamber Test at 1000 Pascals! 💦🌊',
    description: 'Dynamic air and water hose testing on mockup test rig for a commercial airport terminal façade!',
    videoUrl: '/api/media/stream/video5.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1517646287270-a5a9ca602e5c?w=600&h=1000&fit=crop',
    duration: '0:45',
    category: 'Aluminium & Façade Engineering',
    tags: ['WaterTest', 'FaçadeEngineering', 'Shorts', 'Engineering'],
    creatorId: 'u-facade',
    creator: {
      name: 'Façade Engineering Academy',
      username: 'facade_academy',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=faces',
      verified: true
    },
    views: 215000,
    likesCount: 22400,
    commentsCount: 512,
    isLiked: false,
    isShort: true,
    visibility: 'public',
    commentsEnabled: true,
    processingStatus: 'ready',
    moderationStatus: 'approved',
    createdAt: '2025-03-18T10:05:00Z'
  }
];

export const SEED_JOBS = [
  {
    id: 'job-1',
    title: 'Senior Façade Technical Engineer',
    company: 'Apex Façade Systems Global',
    companyLogo: 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=120&h=120&fit=crop',
    location: 'Dubai & Riyadh (Hybrid)',
    country: 'United Arab Emirates',
    category: 'Aluminium & Façade Engineering',
    employmentType: 'Full-time',
    experienceLevel: 'Senior',
    salaryMin: 95000,
    salaryMax: 135000,
    currency: 'USD',
    description: 'Lead technical design reviews, structural wind engineering evaluations, and aluminium extrusion die designs for prominent high-rise towers in the GCC region. You will interface directly with tier-1 architectural firms and façade fabrication plants.',
    responsibilities: [
      'Perform 2D & 3D structural analysis for aluminium mullions, transoms, and anchor brackets under wind and thermal loads.',
      'Review contractor submittals, material compliance sheets, and test laboratory reports (AAMA / CWCT standards).',
      'Coordinate with Revit BIM teams to resolve complex geometry clash issues on double-curved envelopes.',
      'Supervise on-site performance mockup testing and factory production control audits.'
    ],
    qualifications: [
      'BSc or MSc in Façade Engineering, Structural Engineering, or Civil/Mechanical Engineering.',
      '7+ years experience in unitized curtain walls, stick systems, and point-fixed glazing.',
      'Proficiency in structural calculation software (SJ Mepla, Strand7, or STAAD Pro) and AutoCAD.',
      'Strong knowledge of CWCT, ASTM, EN, and BS standards for building envelopes.'
    ],
    deadline: '2026-12-31',
    contactEmail: 'careers@apexfacade.example.com',
    employerId: 'u-recruiter1',
    status: 'active',
    featured: true,
    applicantsCount: 24,
    createdAt: '2025-03-01T09:00:00Z'
  },
  {
    id: 'job-2',
    title: 'Lead Aluminium & Glazing Estimator',
    company: 'AluTech Architectural Enclosures',
    companyLogo: 'https://images.unsplash.com/photo-1572021335469-31706a17aaef?w=120&h=120&fit=crop',
    location: 'London (Hybrid / 3 days on-site)',
    country: 'United Kingdom',
    category: 'Aluminium & Façade Engineering',
    employmentType: 'Full-time',
    experienceLevel: 'Mid-level',
    salaryMin: 55000,
    salaryMax: 72000,
    currency: 'GBP',
    description: 'We are seeking an experienced Aluminium & Glazing Estimator to prepare competitive tenders for commercial curtain walling, structural glazing, and bespoke architectural aluminium packages across the UK.',
    responsibilities: [
      'Produce accurate material take-offs from architectural drawings and tender specifications.',
      'Price aluminium extrusion profiles, insulating glass units (IGUs), brackets, gaskets, and silicone sealants.',
      'Liaise with European profile suppliers (Schüco, Reynaers, Wicona, Kawneer) to secure best material pricing.',
      'Formulate tender submissions, clarify client qualifications, and participate in post-tender interviews.'
    ],
    qualifications: [
      '4+ years commercial estimating experience in the aluminium fenestration/curtain wall sector.',
      'Proven expertise with LogiKal (Orgadata), ReynaPro, or SchüCal estimation software.',
      'Firm grasp of building regulations (Part L thermal, Part B fire regulations for rainscreens).'
    ],
    deadline: '2026-11-30',
    contactEmail: 'estimating@alutech.example.com',
    employerId: 'u-recruiter1',
    status: 'active',
    featured: true,
    applicantsCount: 18,
    createdAt: '2025-03-05T11:20:00Z'
  },
  {
    id: 'job-3',
    title: 'Senior Curtain Wall Draftsman / Detailer',
    company: 'Skyline Envelopes International',
    companyLogo: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=120&h=120&fit=crop',
    location: 'Riyadh',
    country: 'Saudi Arabia',
    category: 'Curtain Wall & Glazing',
    employmentType: 'Full-time',
    experienceLevel: 'Mid-level',
    salaryMin: 60000,
    salaryMax: 85000,
    currency: 'USD',
    description: 'Join our Riyadh engineering design office working on marquee mega-projects. Produce precise 2D AutoCAD fabrication drawings, die sections, glass schedules, and assembly layouts for unitized façades.',
    responsibilities: [
      'Generate detailed shop drawings, fabrication tickets, and cutting lists for CNC machining centers.',
      'Detail thermal breaks, expansion joints, stack joints, and perimeter fire stops.',
      'Incorporate architect comments and site surveying dimensions into as-built records.'
    ],
    qualifications: [
      'Diploma or Bachelor in Architecture, Civil, or Mechanical Drafting.',
      '5+ years dedicated drafting experience in aluminium curtain wall and façade systems.',
      'Mastery of AutoCAD (XRefs, dynamic blocks) and 3D modeling.'
    ],
    deadline: '2026-12-15',
    contactEmail: 'hr@skylineenvelopes.example.com',
    employerId: 'u-recruiter1',
    status: 'active',
    featured: false,
    applicantsCount: 31,
    createdAt: '2025-03-08T08:30:00Z'
  },
  {
    id: 'job-4',
    title: 'Revit BIM Façade Specialist',
    company: 'Metro Civils & Building Group',
    companyLogo: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=120&h=120&fit=crop',
    location: 'Singapore (Central CBD)',
    country: 'Singapore',
    category: 'Revit & BIM',
    employmentType: 'Full-time',
    experienceLevel: 'Senior',
    salaryMin: 85000,
    salaryMax: 110000,
    currency: 'SGD',
    description: 'Lead BIM coordination (LOD 350 to LOD 400) for complex curved glass envelopes and composite aluminium panel systems on major infrastructure and airport transit terminals.',
    responsibilities: [
      'Build parametric Revit family libraries for curtain wall panels, brackets, and louvers.',
      'Run Navisworks clash detection tests against structural concrete, MEP risers, and steelwork.',
      'Develop Dynamo automation scripts for panel numbering and quantity takeoff extraction.'
    ],
    qualifications: [
      'BSc in Architecture, Civil Engineering, or Computational Design.',
      '5+ years BIM modeling experience with Revit, Navisworks, and Dynamo.',
      'Previous experience on large-scale public transport or civic infrastructure projects.'
    ],
    deadline: '2026-12-01',
    contactEmail: 'careers@metrocivils.example.com',
    employerId: 'u-recruiter2',
    status: 'active',
    featured: true,
    applicantsCount: 15,
    createdAt: '2025-03-02T13:40:00Z'
  },
  {
    id: 'job-5',
    title: 'Façade Construction Project Manager',
    company: 'Metro Civils & Building Group',
    companyLogo: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=120&h=120&fit=crop',
    location: 'Toronto (On-site)',
    country: 'Canada',
    category: 'Construction Management',
    employmentType: 'Full-time',
    experienceLevel: 'Lead',
    salaryMin: 115000,
    salaryMax: 145000,
    currency: 'CAD',
    description: 'Oversee site erection, crane scheduling, safety governance, and subcontractor management for a 45-storey residential tower enclosure in downtown Toronto.',
    responsibilities: [
      'Manage schedule, budget, quality control, and safety of façade installation crews.',
      'Coordinate delivery of unitized panels from factory to site laydown areas.',
      'Lead weekly site progress meetings with general contractors and client consultants.'
    ],
    qualifications: [
      'Degree in Construction Management, Civil Engineering, or equivalent.',
      '8+ years construction management with at least 4 years focused on high-rise building envelopes.',
      'PMP or Gold Seal certification is a strong plus.'
    ],
    deadline: '2026-11-20',
    contactEmail: 'pm-jobs@metrocivils.example.com',
    employerId: 'u-recruiter2',
    status: 'active',
    featured: false,
    applicantsCount: 9,
    createdAt: '2025-02-28T16:15:00Z'
  },
  {
    id: 'job-6',
    title: 'Senior Structural Engineer - Glass & Steel',
    company: 'Apex Façade Systems Global',
    companyLogo: 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=120&h=120&fit=crop',
    location: 'Frankfurt / Berlin (Hybrid)',
    country: 'Germany',
    category: 'Civil Engineering',
    employmentType: 'Full-time',
    experienceLevel: 'Senior',
    salaryMin: 78000,
    salaryMax: 98000,
    currency: 'EUR',
    description: 'Perform structural engineering calculations for glass fins, cable nets, tensile membrane canopies, and architectural steel substructures.',
    responsibilities: [
      'Calculate glass stresses and deflections under ultimate and serviceability limit states.',
      'Design bolted and welded connections in accordance with Eurocode 3 and 9.',
      'Author detailed structural calculation reports for municipal building permit approvals.'
    ],
    qualifications: [
      'Master’s degree in Structural or Civil Engineering.',
      'Chartered or Professional Engineer (PE/CEng or Beratender Ingenieur).',
      'Extensive experience with finite element analysis (FEA) software.'
    ],
    deadline: '2026-12-20',
    contactEmail: 'germany@apexfacade.example.com',
    employerId: 'u-recruiter1',
    status: 'active',
    featured: false,
    applicantsCount: 12,
    createdAt: '2025-03-04T10:00:00Z'
  },
  {
    id: 'job-7',
    title: 'Full-Stack TypeScript & Cloud Engineer',
    company: 'Nova Digital Media & Platform Tech',
    companyLogo: 'https://images.unsplash.com/photo-1551434678-e076c223a692?w=120&h=120&fit=crop',
    location: 'Remote (Worldwide)',
    country: 'United States',
    category: 'Software & IT',
    employmentType: 'Remote',
    experienceLevel: 'Mid-level',
    salaryMin: 90000,
    salaryMax: 125000,
    currency: 'USD',
    description: 'Help develop and scale modern video streaming web applications, creator subscription engines, and real-time job portals using React, Node.js 24, MongoDB Atlas, and Tailwind CSS.',
    responsibilities: [
      'Design high-throughput REST APIs and MongoDB query pipelines.',
      'Implement responsive, accessible UI components with modern claymorphic styling.',
      'Optimize video streaming player performance and WebRTC/SSE notification workflows.'
    ],
    qualifications: [
      '3+ years professional full-stack development with TypeScript, React, and Express/Next.js.',
      'Familiarity with MongoDB Atlas aggregation pipelines and indexing.',
      'Passionate about UI/UX polish and responsive mobile-first performance.'
    ],
    deadline: '2026-12-31',
    contactEmail: 'careers@novamedia.example.com',
    employerId: 'u-admin',
    status: 'active',
    featured: true,
    applicantsCount: 42,
    createdAt: '2025-03-11T12:00:00Z'
  },
  {
    id: 'job-8',
    title: 'AutoCAD Glazing Detailer & Drafter',
    company: 'Melbourne Architectural Glass',
    companyLogo: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=120&h=120&fit=crop',
    location: 'Melbourne (Victoria)',
    country: 'Australia',
    category: 'AutoCAD Drafting',
    employmentType: 'Full-time',
    experienceLevel: 'Entry',
    salaryMin: 65000,
    salaryMax: 80000,
    currency: 'AUD',
    description: 'Exciting entry to mid-level opportunity for a keen AutoCAD detailer to join a leading Australian architectural glass & balustrade fabricator.',
    responsibilities: [
      'Draft shop drawings for toughened laminated glass assemblies and aluminium channels.',
      'Produce CNC glass processing drawings with notch and hole coordinate details.',
      'Review site survey measurements.'
    ],
    qualifications: [
      'Certificate IV or Diploma in Drafting or related discipline.',
      'Demonstrated proficiency in AutoCAD 2D drafting with a portfolio of sample drawings.',
      'Attention to detail and willingness to learn Australian glazing code AS1288.'
    ],
    deadline: '2026-11-25',
    contactEmail: 'jobs@melbglass.example.com',
    employerId: 'u-recruiter2',
    status: 'active',
    featured: false,
    applicantsCount: 14,
    createdAt: '2025-03-09T07:15:00Z'
  }
];

export const SEED_APPLICATIONS = [
  {
    id: 'app-1',
    jobId: 'job-1',
    jobTitle: 'Senior Façade Technical Engineer',
    company: 'Apex Façade Systems Global',
    applicantId: 'u-candidate1',
    applicantName: 'Tariq Mansoor',
    applicantEmail: 'tariq@engineer.example.com',
    applicantPhone: '+966 55 123 4567',
    resumeFileName: 'Tariq_Mansoor_Facade_Engineer_CV.pdf',
    portfolioUrl: 'https://behance.net/tariq-facade-portfolio',
    coverNote: 'I have 6 years of unitized curtain wall drafting and structural verification experience in Riyadh and Jeddah. Eager to contribute to Apex high-rise tower projects.',
    videoPitchUrl: '/api/media/stream/video1.mp4',
    videoPitchTitle: 'Façade Mockup Dynamic Testing Breakdown',
    videoPitchDuration: '0:45',
    status: 'Shortlisted',
    createdAt: '2025-03-06T14:30:00Z',
    updatedAt: '2025-03-12T10:00:00Z'
  },
  {
    id: 'app-2',
    jobId: 'job-4',
    jobTitle: 'Revit BIM Façade Specialist',
    company: 'Metro Civils & Building Group',
    applicantId: 'u-candidate1',
    applicantName: 'Tariq Mansoor',
    applicantEmail: 'tariq@engineer.example.com',
    applicantPhone: '+966 55 123 4567',
    resumeFileName: 'Tariq_Mansoor_BIM_Specialist_CV.pdf',
    portfolioUrl: 'https://github.com/tariq-bim-dynamo-scripts',
    coverNote: 'Experienced in LOD 350 Revit parametric mullions and Dynamo automation scripts.',
    status: 'Under Review',
    createdAt: '2025-03-10T16:00:00Z',
    updatedAt: '2025-03-11T09:15:00Z'
  }
];

export const SEED_NOTIFICATIONS = [
  {
    id: 'notif-1',
    recipientId: 'u-candidate1',
    actorId: 'u-recruiter1',
    actorName: 'Apex Façade Systems Talent',
    actorAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&h=200&fit=crop&crop=faces',
    type: 'job_status',
    title: 'Application Shortlisted!',
    message: 'Your application for Senior Façade Technical Engineer has been shortlisted by the recruiting team.',
    link: '/jobs/job-1',
    read: false,
    createdAt: '2025-03-12T10:00:00Z'
  },
  {
    id: 'notif-2',
    recipientId: 'u-facade',
    actorId: 'u-candidate1',
    actorName: 'Tariq Mansoor',
    actorAvatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&h=200&fit=crop&crop=faces',
    type: 'comment',
    title: 'New comment on your video',
    message: 'Tariq Mansoor commented: "Brilliant explanation of the male-female extrusion interlock!"',
    link: '/watch/v-1',
    read: false,
    createdAt: '2025-03-14T08:30:00Z'
  },
  {
    id: 'notif-3',
    recipientId: 'u-candidate1',
    actorId: 'u-facade',
    actorName: 'Façade Engineering Academy',
    actorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=faces',
    type: 'follow',
    title: 'New Follower',
    message: 'Façade Engineering Academy started following your profile.',
    link: '/profile/facade_academy',
    read: true,
    createdAt: '2025-03-13T12:00:00Z'
  },
  {
    id: 'notif-4',
    recipientId: 'u-candidate1',
    actorId: 'u-admin',
    actorName: 'Alex Sterling',
    actorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&crop=faces',
    type: 'admin_announcement',
    title: 'Platform Upgrade Complete',
    message: 'VideoHub + Global Jobs v2.4 is live with enhanced claymorphism 3D cards, instant job alerts, and 4K video playback.',
    read: true,
    createdAt: '2025-03-01T08:00:00Z'
  },
  {
    id: 'notif-5',
    recipientId: 'u-facade',
    actorId: 'u-tech',
    actorName: 'Tech Explorer Lab',
    actorAvatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=200&h=200&fit=crop&crop=faces',
    type: 'like',
    title: 'Liked your video',
    message: 'Tech Explorer Lab liked "Modern Unitized Curtain Wall Installation".',
    link: '/watch/v-1',
    read: true,
    createdAt: '2025-03-11T19:40:00Z'
  }
];

export const SEED_COMMENTS = [
  {
    id: 'c-1',
    videoId: 'v-1',
    userId: 'u-candidate1',
    user: {
      name: 'Tariq Mansoor',
      username: 'tariq_eng',
      avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&h=200&fit=crop&crop=faces',
      verified: false
    },
    text: 'Brilliant explanation of the male-female extrusion interlock! In our Riyadh projects, thermal gasket expansion under 50°C summer heat is a major design consideration.',
    likesCount: 38,
    isLiked: false,
    createdAt: '2025-03-11T15:20:00Z'
  },
  {
    id: 'c-2',
    videoId: 'v-1',
    userId: 'u-construction',
    user: {
      name: 'Construction Skills Hub',
      username: 'constructionskills',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=faces',
      verified: true
    },
    text: 'The crane rigging sequence shown at 08:30 is textbook perfect. Vacuum suction lifters with dual independent vacuum circuits are absolute must-haves.',
    likesCount: 64,
    isLiked: false,
    createdAt: '2025-03-11T18:00:00Z'
  },
  {
    id: 'c-3',
    videoId: 'v-3',
    userId: 'u-candidate1',
    user: {
      name: 'Tariq Mansoor',
      username: 'tariq_eng',
      avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&h=200&fit=crop&crop=faces',
      verified: false
    },
    text: 'The adaptive component trick for corner mullions just saved me 4 hours of modeling today. Thank you!',
    likesCount: 19,
    isLiked: false,
    createdAt: '2025-03-09T14:10:00Z'
  }
];

export const SEED_CONVERSATIONS = [
  {
    id: 'conv-1',
    participants: [
      {
        id: 'u-recruiter1',
        name: 'Apex Façade Systems Talent',
        username: 'apex_recruiter',
        avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&h=200&fit=crop&crop=faces',
        role: 'employer'
      },
      {
        id: 'u-candidate1',
        name: 'Tariq Mansoor',
        username: 'tariq_eng',
        avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&h=200&fit=crop&crop=faces',
        role: 'user'
      }
    ],
    lastMessage: 'Hello Tariq, we were impressed with your façade calculation portfolio. Would you be open for an initial technical interview next Tuesday?',
    lastMessageAt: '2025-03-14T11:15:00Z',
    unreadCount: 1
  }
];

export const SEED_MESSAGES = [
  {
    id: 'm-1',
    conversationId: 'conv-1',
    senderId: 'u-recruiter1',
    senderName: 'Apex Façade Systems Talent',
    senderAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&h=200&fit=crop&crop=faces',
    text: 'Hello Tariq, thank you for applying to our Senior Façade Technical Engineer vacancy.',
    createdAt: '2025-03-14T11:00:00Z'
  },
  {
    id: 'm-2',
    conversationId: 'conv-1',
    senderId: 'u-recruiter1',
    senderName: 'Apex Façade Systems Talent',
    senderAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&h=200&fit=crop&crop=faces',
    text: 'We were impressed with your façade calculation portfolio. Would you be open for an initial technical interview next Tuesday at 2:00 PM GST?',
    createdAt: '2025-03-14T11:15:00Z'
  }
];

export const SEED_REPORTS = [
  {
    id: 'rep-1',
    reporterId: 'u-candidate1',
    reporterName: 'Tariq Mansoor',
    targetType: 'comment',
    targetId: 'c-spam-101',
    targetTitle: 'Suspicious spam link in comments',
    reason: 'Spam or advertising bot',
    details: 'User posted a link to a suspicious external site in comments section of video v-1.',
    status: 'pending',
    createdAt: '2025-03-15T09:00:00Z'
  }
];

export const SEED_AUDIT_LOGS = [
  {
    id: 'log-1',
    adminId: 'u-admin',
    adminName: 'Shafi Afzal Shah',
    action: 'MODERATE_VIDEO',
    details: 'Approved video v-1 and reviewed compliance rules',
    timestamp: '2025-03-10T15:00:00Z'
  }
];

export const SEED_STORE_PRODUCTS = [
  {
    id: 'prod-1',
    title: 'Dual-Cup Heavy Vacuum Glass Suction Lifter (150kg Load)',
    description: 'Industrial heavy-duty dual cup vacuum suction lifter engineered for curtain wall glass glazing, spider fitting installation, and handling polished architectural metal panels without surface scratching.',
    category: 'facade_hardware',
    categoryName: 'Façade Hardware & Glass Lifters',
    price: 89.00,
    compareAtPrice: 120.00,
    currency: 'USD',
    condition: 'new',
    rating: 4.9,
    reviewsCount: 128,
    stock: 45,
    images: [
      'https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=800&h=600&fit=crop'
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=600&h=450&fit=crop',
    features: [
      'Solid forged aluminum alloy body with anti-slip grip',
      'High-grade vulcanized natural rubber suction pads (120mm diameter)',
      '150 kg horizontal lifting capacity, 130 kg vertical capacity',
      'Double quick-release lever lock system'
    ],
    specifications: {
      'Working Load': '150 kg (330 lbs)',
      'Cup Diameter': '120 mm x 2',
      'Material': 'A380 Die-cast Aluminum Alloy',
      'Net Weight': '1.35 kg',
      'Safety Standard': 'CE Certified / EN 12195'
    },
    brand: 'Dometech Façade Tools',
    sellerId: 'u-admin',
    sellerName: 'Shafi Afzal Shah',
    sellerAvatar: '/assets/aistudio/Screenshot_20240115_120152_DWG_FastView_e3b92bfb.jpg',
    sellerVerified: true,
    shippingInfo: {
      freeShipping: true,
      estimatedDelivery: '2–3 Business Days (GCC Express)',
      shipsFrom: 'Riyadh, Saudi Arabia'
    },
    tags: ['SuctionLifter', 'Glazing', 'FaçadeTools', 'GlassInstallation'],
    isFeatured: true,
    isCreatorProduct: true,
    createdAt: '2026-03-01T10:00:00Z'
  },
  {
    id: 'prod-2',
    title: 'BIM Revit Curtain Wall Family Pack (2026 GCC & SBC Certified)',
    description: 'Comprehensive library of 65+ fully parametric Revit curtain wall families, unitized panel modules, thermal break extrusions, corner mullions, and spider glass fittings with embedded engineering schedules.',
    category: 'bim_templates',
    categoryName: 'BIM & Digital Engineering Assets',
    price: 49.00,
    compareAtPrice: 79.00,
    currency: 'USD',
    condition: 'digital',
    rating: 5.0,
    reviewsCount: 94,
    stock: 9999,
    images: [
      'https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1541888946425-d0fbb186156f?w=800&h=600&fit=crop'
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=600&h=450&fit=crop',
    features: [
      '65+ Parametric Revit 2022–2026 (.RFA & .RVT) models',
      'LOD 350 & LOD 400 fabrication-ready geometry',
      'Pre-configured Saudi Building Code (SBC 201/301) parameters',
      'Instant cloud download link with lifetime version updates'
    ],
    specifications: {
      'File Formats': '.RFA, .RVT, .IFC 4.0, .DWG',
      'Compatible Versions': 'Autodesk Revit 2021 through 2026',
      'File Size': '840 MB (ZIP Archive)',
      'Delivery': 'Instant Automated Digital Download',
      'Licence': 'Commercial / Multi-User Studio Licence'
    },
    brand: 'Façade BIM Studio',
    sellerId: 'u-bim',
    sellerName: 'BIM Engineering Lab',
    sellerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=faces',
    sellerVerified: true,
    shippingInfo: {
      freeShipping: true,
      estimatedDelivery: 'Instant Digital Download',
      shipsFrom: 'Digital Cloud Vault'
    },
    tags: ['Revit', 'BIM', 'CurtainWall', 'CAD', 'DigitalAssets'],
    isFeatured: true,
    createdAt: '2026-03-05T12:00:00Z'
  },
  {
    id: 'prod-3',
    title: 'High-Precision Digital Torque Calibrator for Façade Anchors',
    description: 'Site-grade electronic digital torque wrench with audible buzzer, LED indicator, and peak memory for structural anchor bolt verification and bracket torque compliance.',
    category: 'fabrication_tools',
    categoryName: 'Fabrication & Site Tools',
    price: 245.00,
    compareAtPrice: 299.00,
    currency: 'USD',
    condition: 'new',
    rating: 4.8,
    reviewsCount: 41,
    stock: 18,
    images: [
      'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=800&h=600&fit=crop'
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=600&h=450&fit=crop',
    features: [
      '10 to 200 Nm measurement range with ±1% clockwise accuracy',
      '4 selectable engineering units: N·m, in·lb, ft·lb, kg·cm',
      'Backlit high-contrast display with vibration and sound alerts',
      'Rugged protective EVA carry case with calibration certificate'
    ],
    specifications: {
      'Drive Size': '1/2 inch Square Drive',
      'Torque Range': '10 – 200 N·m (7.4 – 147.5 ft·lb)',
      'Accuracy': '±1% CW / ±2% CCW',
      'Battery': '2x AAA Alkaline (Included)',
      'Calibration': 'ISO 6789 Standard'
    },
    brand: 'TorquePro Precision',
    sellerId: 'u-facade',
    sellerName: 'Apex Façade Systems',
    sellerAvatar: 'https://images.unsplash.com/photo-1541888946425-d0fbb186156f?w=200&h=200&fit=crop&crop=faces',
    sellerVerified: true,
    shippingInfo: {
      freeShipping: true,
      estimatedDelivery: '3–5 Business Days (Air Cargo)',
      shipsFrom: 'Dubai, UAE'
    },
    tags: ['Torque', 'AnchorBolts', 'SiteInspection', 'Engineering'],
    isFeatured: true,
    createdAt: '2026-03-10T14:30:00Z'
  },
  {
    id: 'prod-4',
    title: 'Shafi Shah Signature Carbon Fiber Site Safety Helmet & Shield',
    description: 'Ultra-lightweight aerospace carbon fiber composite engineering safety helmet featuring full-face integrated drop-down visor, 6-point suspension harness, and breathable climate vents.',
    category: 'safety_gear',
    categoryName: 'Safety Gear & Site PPE',
    price: 65.00,
    compareAtPrice: 85.00,
    currency: 'USD',
    condition: 'new',
    rating: 4.9,
    reviewsCount: 210,
    stock: 60,
    images: [
      'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=800&h=600&fit=crop'
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=600&h=450&fit=crop',
    features: [
      'Genuine 3K matte weave carbon fiber shell (390 grams ultralight)',
      'Scratch-resistant polycarbonate UV400 retractable face shield',
      'Ergonomic wheel ratchet adjustment fits 53–64 cm heads',
      'Reflective high-visibility safety stickers and sweatband'
    ],
    specifications: {
      'Shell Material': '3K Toray Carbon Fiber Composite',
      'Visor Standard': 'EN 166 1B Class Optical Quality',
      'Impact Cert': 'ANSI/ISEA Z89.1 Type 1 Class C & EN 397',
      'Weight': '395 grams',
      'Warranty': '2-Year Manufacturer Warranty'
    },
    brand: 'Dometech Façade Gear',
    sellerId: 'u-admin',
    sellerName: 'Shafi Afzal Shah',
    sellerAvatar: '/assets/aistudio/Screenshot_20240115_120152_DWG_FastView_e3b92bfb.jpg',
    sellerVerified: true,
    shippingInfo: {
      freeShipping: true,
      estimatedDelivery: '2–3 Business Days (GCC Express)',
      shipsFrom: 'Riyadh, Saudi Arabia'
    },
    tags: ['SafetyHelmet', 'PPE', 'CarbonFiber', 'ShafiShah', 'SiteSafety'],
    isFeatured: true,
    isCreatorProduct: true,
    createdAt: '2026-03-12T09:15:00Z'
  },
  {
    id: 'prod-5',
    title: 'Industrial Double-Head Aluminium Mitre Saw Carbide Blade (500mm)',
    description: 'Heavy production tungsten carbide-tipped (TCT) cutting blade tailored for high-speed burr-free miter cuts in architectural aluminium profiles, curtain wall transoms, and thermal barrier extrusions.',
    category: 'machinery',
    categoryName: 'Heavy Machinery & Fabrication Plant',
    price: 320.00,
    compareAtPrice: 380.00,
    currency: 'USD',
    condition: 'new',
    rating: 4.9,
    reviewsCount: 37,
    stock: 12,
    images: [
      'https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=800&h=600&fit=crop'
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=600&h=450&fit=crop',
    features: [
      '120 Trapezoidal Flat Teeth (TCG) for ultra-clean cut faces',
      'Laser-cut expansion slots filled with sound-dampening resin',
      'Hardened 75Cr1 European alloy body prevents blade deflection',
      'Max RPM: 3,800 with negative 5° hook angle'
    ],
    specifications: {
      'Blade Diameter': '500 mm (20 inch)',
      'Bore Diameter': '30 mm with drive pinholes',
      'Kerf Width': '4.2 mm / Plate 3.6 mm',
      'Tooth Count': '120 TCG Teeth',
      'Compatibility': 'Emmegi, FOM, Elumatec, Yilmaz'
    },
    brand: 'AluCut Industrial',
    sellerId: 'u-construction',
    sellerName: 'Gulf Façade Fabricators',
    sellerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=faces',
    sellerVerified: true,
    shippingInfo: {
      freeShipping: false,
      shippingCost: 25.00,
      estimatedDelivery: '3–6 Business Days (Heavy Freight)',
      shipsFrom: 'Dammam, Saudi Arabia'
    },
    tags: ['AluminiumSaw', 'SawBlade', 'Fabrication', 'MitreSaw'],
    isFeatured: false,
    createdAt: '2026-03-15T11:00:00Z'
  },
  {
    id: 'prod-6',
    title: 'EPDM Gasket Rolling & Glazing Beading Installation Tool Kit (4-Piece)',
    description: 'Ergonomic 4-piece professional hand tool kit for inserting EPDM dry-glazing gaskets, wedge seals, and aluminum pressure plate beading cleanly without stretching or damaging rubber.',
    category: 'fabrication_tools',
    categoryName: 'Fabrication & Site Tools',
    price: 38.00,
    compareAtPrice: 50.00,
    currency: 'USD',
    condition: 'new',
    rating: 4.7,
    reviewsCount: 85,
    stock: 110,
    images: [
      'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=800&h=600&fit=crop'
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=600&h=450&fit=crop',
    features: [
      'Ball-bearing smooth brass roller wheel',
      'Curved corner insertion spatula and tucking pick',
      'Ergonomic contour wooden handles reduce hand fatigue',
      'Includes replacement steel grooved roller wheel'
    ],
    specifications: {
      'Tools Included': 'Brass Roller, Nylon Roller, Corner Blade, Hook Knife',
      'Roller Width': '3 mm / 5 mm / 8 mm',
      'Handle Material': 'Varnished Solid Beechwood',
      'Weight': '420 grams total'
    },
    brand: 'GlazeTech Professional',
    sellerId: 'u-facade',
    sellerName: 'Apex Façade Systems',
    sellerAvatar: 'https://images.unsplash.com/photo-1541888946425-d0fbb186156f?w=200&h=200&fit=crop&crop=faces',
    sellerVerified: true,
    shippingInfo: {
      freeShipping: true,
      estimatedDelivery: '2–4 Business Days',
      shipsFrom: 'Jeddah, Saudi Arabia'
    },
    tags: ['EPDM', 'GasketRoller', 'Glazing', 'Installation'],
    isFeatured: false,
    createdAt: '2026-03-18T16:20:00Z'
  },
  {
    id: 'prod-7',
    title: 'Point-Supported Spider Glass Articulation Fitting (316 Marine Stainless)',
    description: 'Precision cast 316 marine-grade stainless steel 4-arm spider fitting bracket with ball-joint routel bolts for structural glass walls, canopy glazing, and glass fins.',
    category: 'facade_hardware',
    categoryName: 'Façade Hardware & Glass Lifters',
    price: 54.00,
    compareAtPrice: 68.00,
    currency: 'USD',
    condition: 'engineering_spec',
    rating: 4.9,
    reviewsCount: 114,
    stock: 150,
    images: [
      'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=800&h=600&fit=crop'
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=600&h=450&fit=crop',
    features: [
      'Solid investment cast AISI 316 (CF8M) stainless steel',
      'Mirror 800-grit electro-polished finish resists coastal salinity',
      'Supports 12mm to 25.52mm laminated glass thickness',
      'Includes articulated swivel bolt and silicone isolating washers'
    ],
    specifications: {
      'Material': 'Investment Cast SS 316',
      'Arm Span': '220 mm Hole-to-Hole',
      'Glass Load Capacity': '4,500 N per arm (Wind Pressure)',
      'Finish': 'Mirror Polished / Satin Brushed',
      'Test Cert': 'Mill Test Certificate (EN 10204 3.1)'
    },
    brand: 'Apex Spider Systems',
    sellerId: 'u-facade',
    sellerName: 'Apex Façade Systems',
    sellerAvatar: 'https://images.unsplash.com/photo-1541888946425-d0fbb186156f?w=200&h=200&fit=crop&crop=faces',
    sellerVerified: true,
    shippingInfo: {
      freeShipping: true,
      estimatedDelivery: '3–5 Business Days',
      shipsFrom: 'Sharjah, UAE'
    },
    tags: ['SpiderFitting', 'PointFixing', 'StainlessSteel', 'GlassFaçade'],
    isFeatured: true,
    createdAt: '2026-03-20T08:00:00Z'
  },
  {
    id: 'prod-8',
    title: 'Curtain Wall Water Leakage Field Test Spray Bar Kit (AAMA 501.2 Standard)',
    description: 'Complete calibrated water leakage field test apparatus conforming to AAMA 501.2 specifications for quality verification of installed curtain walls, storefronts, and architectural window systems.',
    category: 'machinery',
    categoryName: 'Heavy Machinery & Fabrication Plant',
    price: 480.00,
    compareAtPrice: 550.00,
    currency: 'USD',
    condition: 'engineering_spec',
    rating: 5.0,
    reviewsCount: 19,
    stock: 8,
    images: [
      'https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=800&h=600&fit=crop'
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=600&h=450&fit=crop',
    features: [
      'Calibrated Monarch Type B-25 1/2" Brass Spray Nozzle',
      'Liquid-filled pressure gauge (0–60 PSI / 0–4 bar with ±1% F.S. accuracy)',
      'Fine-metering brass ball control valve and strainer filter',
      'Quick-connect bronze hose adapters in heavy-duty flight case'
    ],
    specifications: {
      'Compliance': 'AAMA 501.2 / ASTM E1105 Testing Protocol',
      'Working Pressure': '30 to 35 PSI nozzle operating pressure',
      'Nozzle Specs': 'B-25 Brass (1/2" NPT female inlet)',
      'Water Delivery': '4.5 to 5.0 gallons/minute at 30 PSI',
      'Packaging': 'IP67 Waterproof Mil-Spec Case'
    },
    brand: 'FaçadeTest International',
    sellerId: 'u-admin',
    sellerName: 'Shafi Afzal Shah',
    sellerAvatar: '/assets/aistudio/Screenshot_20240115_120152_DWG_FastView_e3b92bfb.jpg',
    sellerVerified: true,
    shippingInfo: {
      freeShipping: true,
      estimatedDelivery: '2–4 Business Days (Express Air)',
      shipsFrom: 'Riyadh, Saudi Arabia'
    },
    tags: ['WaterTesting', 'AAMA501', 'CurtainWall', 'SiteQuality'],
    isFeatured: true,
    isCreatorProduct: true,
    createdAt: '2026-03-22T13:00:00Z'
  },
  {
    id: 'prod-9',
    title: 'World Video Hub Engineering Masterclass Heavyweight Hoodie (Embroidered)',
    description: 'Official World Video Hub creator merchandise. 420 GSM ultra-heavyweight brushed French terry cotton hoodie featuring high-density gold and graphite embroidered isometric curtain wall diagram.',
    category: 'creator_merch',
    categoryName: 'Creator Merch & Swag',
    price: 45.00,
    compareAtPrice: 60.00,
    currency: 'USD',
    condition: 'new',
    rating: 4.9,
    reviewsCount: 88,
    stock: 85,
    images: [
      'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=800&h=600&fit=crop'
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=600&h=450&fit=crop',
    features: [
      '420 GSM 100% Combed Heavyweight French Terry Cotton',
      'Precision chest and sleeve 12,000-stitch embroidery',
      'Double-layer hood with metal eyelets and thick drawstrings',
      'Preshrunk fabric with ribbed side gussets for maximum durability'
    ],
    specifications: {
      'Fabric': '100% Ring-Spun Combed Cotton (420 GSM)',
      'Fit': 'Contemporary Relaxed / Unisex',
      'Color': 'Graphite Carbon Black & Gold Stitching',
      'Sizes Available': 'S, M, L, XL, 2XL',
      'Care': 'Machine Wash Cold, Hang Dry'
    },
    brand: 'World Video Hub Official',
    sellerId: 'u-admin',
    sellerName: 'Shafi Afzal Shah',
    sellerAvatar: '/assets/aistudio/Screenshot_20240115_120152_DWG_FastView_e3b92bfb.jpg',
    sellerVerified: true,
    shippingInfo: {
      freeShipping: true,
      estimatedDelivery: '3–5 Business Days',
      shipsFrom: 'Riyadh, Saudi Arabia'
    },
    tags: ['Merch', 'Hoodie', 'CreatorSwag', 'ShafiShah'],
    isFeatured: false,
    isCreatorProduct: true,
    createdAt: '2026-03-24T15:30:00Z'
  },
  {
    id: 'prod-10',
    title: 'Laser Distance Meter 120m with Real-Time Angle Sensor & Bluetooth',
    description: 'Site surveying laser rangefinder with ±1.5mm accuracy, electronic level angle sensor, continuous tracking, area/volume calculation, and direct Bluetooth sync to CAD/BIM tablet applications.',
    category: 'fabrication_tools',
    categoryName: 'Fabrication & Site Tools',
    price: 115.00,
    compareAtPrice: 149.00,
    currency: 'USD',
    condition: 'new',
    rating: 4.8,
    reviewsCount: 63,
    stock: 35,
    images: [
      'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=800&h=600&fit=crop'
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=600&h=450&fit=crop',
    features: [
      '120 Meter (393 ft) laser measuring range with ±1.5 mm precision',
      'Built-in 360° tilt sensor for indirect tilt & roof height calculation',
      'Bluetooth LE syncs measurements directly into AutoCAD Mobile & Revit',
      'IP65 water, rain, and job site concrete dust resistant'
    ],
    specifications: {
      'Range': '0.05 m to 120 m',
      'Laser Class': 'Class II, 635nm, <1mW',
      'Memory': 'Stores 50 historical measurement sets',
      'Display': '2.4" Backlit Color Inverted Display',
      'Battery': 'Rechargeable USB-C Li-Ion Battery'
    },
    brand: 'LaserSurvey Pro',
    sellerId: 'u-tech',
    sellerName: 'Tech Explorer Lab',
    sellerAvatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=200&h=200&fit=crop&crop=faces',
    sellerVerified: true,
    shippingInfo: {
      freeShipping: true,
      estimatedDelivery: '2–4 Business Days',
      shipsFrom: 'Dubai, UAE'
    },
    tags: ['LaserMeasure', 'Surveying', 'SiteInspection', 'Bluetooth'],
    isFeatured: false,
    createdAt: '2026-03-25T17:00:00Z'
  },
  {
    id: 'prod-11',
    title: '4K Ultra HD Creator Vlogging & Live Streaming Camera Kit (with Flip Screen & Shotgun Mic)',
    description: 'Professional high-definition creator camera kit featuring true 4K 60FPS video recording, clean HDMI output for zero-latency live streaming, 180° flip-out touchscreen, directional broadcast shotgun condenser microphone, and dual cold-shoe bracket.',
    category: 'electronics',
    categoryName: 'Electronics & Tech Gadgets',
    price: 349.00,
    compareAtPrice: 420.00,
    currency: 'USD',
    condition: 'new',
    rating: 4.9,
    reviewsCount: 142,
    stock: 28,
    images: [
      'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=800&h=600&fit=crop'
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=600&h=450&fit=crop',
    features: [
      'Crisp 4K UHD @ 60 FPS / 1080p @ 120 FPS high framerate video',
      'Clean HDMI output for seamless USB capture card & streaming setup',
      'High-gain directional condenser shotgun mic with deadcat windshield',
      '3.0-inch 1.04M-dot articulating flip-out touch monitor'
    ],
    specifications: {
      'Sensor': '24.2 MP APS-C CMOS Sensor',
      'Video Resolution': '4K 3840x2160 (60p/30p/24p)',
      'Connectivity': 'WiFi 6, Bluetooth 5.2, USB-C 3.2, Micro-HDMI',
      'Audio Input': '3.5mm Stereo Microphone Jack',
      'Battery Life': '110 mins continuous 4K recording (USB-C Power Delivery)'
    },
    brand: 'LumixPro Vision',
    sellerId: 'u-tech',
    sellerName: 'Tech Explorer Lab',
    sellerAvatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=200&h=200&fit=crop&crop=faces',
    sellerVerified: true,
    shippingInfo: {
      freeShipping: true,
      estimatedDelivery: '2–3 Business Days (Express Air)',
      shipsFrom: 'Dubai, UAE'
    },
    tags: ['Camera', '4K', 'Vlogging', 'Streaming', 'CreatorTech'],
    isFeatured: true,
    createdAt: '2026-03-26T10:00:00Z'
  },
  {
    id: 'prod-12',
    title: 'Active Noise Cancelling (ANC) Wireless Studio Headphones (Hi-Res Audio & 40h Battery)',
    description: 'Premium over-ear wireless headphones engineered with hybrid adaptive noise cancellation up to 38dB, 40mm custom beryllium dynamic drivers, ultra-soft memory foam earcups, transparency ambient mode, and lossless Bluetooth 5.3 LDAC transmission.',
    category: 'electronics',
    categoryName: 'Electronics & Tech Gadgets',
    price: 149.00,
    compareAtPrice: 199.00,
    currency: 'USD',
    condition: 'new',
    rating: 4.8,
    reviewsCount: 210,
    stock: 55,
    images: [
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1484704849700-f032a568e944?w=800&h=600&fit=crop'
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&h=450&fit=crop',
    features: [
      'Hybrid Adaptive ANC blocking 95% of background low-frequency noise',
      '40mm custom acoustic drivers delivering 40kHz Hi-Res sound certified',
      '40-hour playback with ANC active (60 hours in standard mode)',
      'Multi-point Bluetooth 5.3 connection to laptop and phone simultaneously'
    ],
    specifications: {
      'Driver Size': '40mm Custom Beryllium Diaphragm',
      'Noise Reduction': 'Up to -38 dB Hybrid ANC',
      'Bluetooth Codecs': 'LDAC, AAC, SBC, aptX Adaptive',
      'Fast Charge': '10 mins charge = 5 hours playback',
      'Weight': '250 grams lightweight ergonomic frame'
    },
    brand: 'AcoustiPro Studio',
    sellerId: 'u-tech',
    sellerName: 'Tech Explorer Lab',
    sellerAvatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=200&h=200&fit=crop&crop=faces',
    sellerVerified: true,
    shippingInfo: {
      freeShipping: true,
      estimatedDelivery: '2–4 Business Days',
      shipsFrom: 'Riyadh, Saudi Arabia'
    },
    tags: ['Headphones', 'ANC', 'Wireless', 'HiRes', 'Audio'],
    isFeatured: true,
    createdAt: '2026-03-26T11:30:00Z'
  },
  {
    id: 'prod-13',
    title: 'Titanium Ultra AMOLED Smartwatch with Dual-Band GPS & ECG Health Monitor',
    description: 'Rugged luxury aerospace-grade titanium smartwatch featuring a 1.43" sapphire crystal AMOLED display (1000 nits peak outdoor brightness), dual-frequency multi-satellite GPS, 100m water resistance, continuous ECG, SpO2, and 14-day battery reserve.',
    category: 'electronics',
    categoryName: 'Electronics & Tech Gadgets',
    price: 199.00,
    compareAtPrice: 279.00,
    currency: 'USD',
    condition: 'new',
    rating: 4.9,
    reviewsCount: 98,
    stock: 34,
    images: [
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?w=800&h=600&fit=crop'
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&h=450&fit=crop',
    features: [
      'Aerospace Grade 5 Titanium casing with unscratchable Sapphire crystal',
      '1.43" 466x466 Always-On AMOLED Display with 1000 nits brightness',
      '10 ATM (100-meter) ocean swim and dive certified',
      'Dual-Band L1/L5 GPS navigation with offline topographic maps'
    ],
    specifications: {
      'Casing Material': 'Grade 5 Aerospace Titanium & Ceramic back',
      'Display': '1.43 inch AMOLED (466 x 466, 326 PPI)',
      'Waterproof': '10 ATM / 100m ISO 22810 standard',
      'Battery': '500 mAh (14 days typical, 36 hours GPS tracking)',
      'Compatibility': 'iOS 13+ & Android 8.0+'
    },
    brand: 'ChronoTech Pulse',
    sellerId: 'u-tech',
    sellerName: 'Tech Explorer Lab',
    sellerAvatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=200&h=200&fit=crop&crop=faces',
    sellerVerified: true,
    shippingInfo: {
      freeShipping: true,
      estimatedDelivery: '2–3 Business Days',
      shipsFrom: 'Dubai, UAE'
    },
    tags: ['Smartwatch', 'Titanium', 'Fitness', 'GPS', 'Wearables'],
    isFeatured: true,
    createdAt: '2026-03-26T13:00:00Z'
  },
  {
    id: 'prod-14',
    title: 'Custom Hot-Swappable 75% Mechanical Keyboard (Gateron Pro Yellow & RGB)',
    description: 'Enthusiast-grade gasket-mounted mechanical keyboard with pre-lubed Gateron Pro Yellow linear switches, sound-absorbing Poron dampening foam, double-shot thick PBT keycaps, and customizable South-facing RGB lighting.',
    category: 'electronics',
    categoryName: 'Electronics & Tech Gadgets',
    price: 89.00,
    compareAtPrice: 119.00,
    currency: 'USD',
    condition: 'new',
    rating: 4.8,
    reviewsCount: 167,
    stock: 40,
    images: [
      'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800&h=600&fit=crop'
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=600&h=450&fit=crop',
    features: [
      'Gasket mount structure with 5 layers of sound-dampening acoustic foam',
      'Hot-swappable 5-pin PCB compatible with 99% of mechanical switches',
      'Pre-lubricated factory-tuned screw-in stabilizers for wobble-free spacebar',
      'Tri-mode connectivity: Bluetooth 5.1, 2.4GHz wireless dongle, & USB-C wired'
    ],
    specifications: {
      'Layout': '75% Compact (82 Keys + Aluminum Rotary Knob)',
      'Switches': 'Gateron Pro Yellow Linear (50g operating force)',
      'Keycaps': 'Cherry Profile Double-Shot PBT',
      'Battery': '4000 mAh rechargeable lithium',
      'Software': 'QMK / VIA open-source remap support'
    },
    brand: 'MechCraft Studio',
    sellerId: 'u-tech',
    sellerName: 'Tech Explorer Lab',
    sellerAvatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=200&h=200&fit=crop&crop=faces',
    sellerVerified: true,
    shippingInfo: {
      freeShipping: true,
      estimatedDelivery: '3–5 Business Days',
      shipsFrom: 'Dubai, UAE'
    },
    tags: ['Keyboard', 'MechanicalKeyboard', 'RGB', 'Tech', 'DeskSetup'],
    isFeatured: false,
    createdAt: '2026-03-26T14:15:00Z'
  },
  {
    id: 'prod-15',
    title: 'Urban All-Weather Waterproof Techwear Shell Jacket (Breathable 3-Layer)',
    description: 'Modern utilitarian techwear hardshell jacket engineered with 3-layer microporous waterproof laminate (20,000mm hydrostatic head), fully taped seams, waterproof YKK AquaGuard zippers, and multiple magnetic modular tactical pockets.',
    category: 'fashion',
    categoryName: 'Fashion & Apparel',
    price: 98.00,
    compareAtPrice: 145.00,
    currency: 'USD',
    condition: 'new',
    rating: 4.9,
    reviewsCount: 76,
    stock: 62,
    images: [
      'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1544441893-675973e31985?w=800&h=600&fit=crop'
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=600&h=450&fit=crop',
    features: [
      '20,000mm Waterproof & 15,000 g/m²/24hr Breathability rating',
      '100% Sealed seam taping and YKK matte black AquaGuard zippers',
      'Concealed RFID-blocking passport and mobile chest pocket',
      'Adjustable storm hood with dual cinch cord and visor brim'
    ],
    specifications: {
      'Shell': '100% High-Density Ripstop Nylon (3-Layer DWR)',
      'Fit': 'Contemporary Ergonomic Relaxed Cut',
      'Color Options': 'Matte Onyx Black / Stealth Slate Grey',
      'Sizes': 'S, M, L, XL, 2XL',
      'Care': 'Machine Wash Gentle Cold, Hang Air Dry'
    },
    brand: 'Apex Urban Techwear',
    sellerId: 'u-creative',
    sellerName: 'Creative World Studio',
    sellerAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&h=200&fit=crop&crop=faces',
    sellerVerified: true,
    shippingInfo: {
      freeShipping: true,
      estimatedDelivery: '3–5 Business Days',
      shipsFrom: 'Paris, France'
    },
    tags: ['Techwear', 'Jacket', 'Waterproof', 'Streetwear', 'Fashion'],
    isFeatured: true,
    createdAt: '2026-03-26T15:30:00Z'
  },
  {
    id: 'prod-16',
    title: 'Minimalist Sapphire Crystal Automatic Chronograph (Italian Calf Leather)',
    description: 'Timeless luxury timepiece powered by a 24-jewel Japanese mechanical movement with 42-hour power reserve. Encased in 316L surgical stainless steel with a scratch-proof domed sapphire crystal and quick-release genuine Italian full-grain leather strap.',
    category: 'fashion',
    categoryName: 'Fashion & Apparel',
    price: 165.00,
    compareAtPrice: 220.00,
    currency: 'USD',
    condition: 'new',
    rating: 4.9,
    reviewsCount: 83,
    stock: 22,
    images: [
      'https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=800&h=600&fit=crop'
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=600&h=450&fit=crop',
    features: [
      'Self-winding mechanical automatic movement with exhibition glass caseback',
      'Double-domed synthetic sapphire crystal with anti-reflective coating',
      'Surgical 316L brushed stainless steel case (40mm diameter)',
      'Water resistant to 50 meters (5 ATM) with screw-down crown'
    ],
    specifications: {
      'Movement': 'Japanese Automatic (21,600 vph, 24 Jewels, 42h reserve)',
      'Case Diameter': '40 mm (Thickness: 11.5 mm)',
      'Crystal': 'Scratch-Proof Domed Sapphire Glass',
      'Strap': '20mm Italian Full-Grain Vegetable Tanned Leather',
      'Warranty': '2-Year Manufacturer International Guarantee'
    },
    brand: 'Nordik Horology',
    sellerId: 'u-creative',
    sellerName: 'Creative World Studio',
    sellerAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&h=200&fit=crop&crop=faces',
    sellerVerified: true,
    shippingInfo: {
      freeShipping: true,
      estimatedDelivery: '3–5 Business Days',
      shipsFrom: 'Riyadh, Saudi Arabia'
    },
    tags: ['Watches', 'AutomaticWatch', 'Luxury', 'Fashion', 'Accessories'],
    isFeatured: false,
    createdAt: '2026-03-26T16:00:00Z'
  },
  {
    id: 'prod-17',
    title: 'Italian 20-Bar Espresso & Cappuccino Maker with Stainless Microfoam Wand',
    description: 'Commercial-grade home espresso machine featuring a 20-bar high-pressure Italian vibration pump, rapid ThermoBlock heating system ready in 45 seconds, digital PID temperature stabilization, and 360° commercial stainless steel steam wand for microfoam latte art.',
    category: 'home_living',
    categoryName: 'Home, Kitchen & Living',
    price: 189.00,
    compareAtPrice: 249.00,
    currency: 'USD',
    condition: 'new',
    rating: 5.0,
    reviewsCount: 185,
    stock: 25,
    images: [
      'https://images.unsplash.com/photo-1517668808822-9ebb02f2a0e6?w=800&h=600&fit=crop'
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1517668808822-9ebb02f2a0e6?w=600&h=450&fit=crop',
    features: [
      'Authentic 20-Bar high-pressure pump extracting thick hazelnut crema',
      'ThermoBlock instant heating tech reaches brew temperature in 45s',
      'Commercial stainless steel steam wand texturing silky microfoam',
      '51mm heavy solid steel portafilter with single and double shot baskets'
    ],
    specifications: {
      'Pump Pressure': '20 Bar Italian Pump',
      'Water Tank': '1.5 Liter Removable BPA-Free Reservoir',
      'Power': '1350 Watts / 220V–240V 50/60Hz',
      'Material': 'Brushed Food-Grade SUS304 Stainless Steel',
      'Accessories': 'Portafilter, 2 Baskets, Coffee Tamper & Spoon'
    },
    brand: 'BellaCaffè Italia',
    sellerId: 'u-admin',
    sellerName: 'Shafi Afzal Shah',
    sellerAvatar: '/assets/aistudio/Screenshot_20240115_120152_DWG_FastView_e3b92bfb.jpg',
    sellerVerified: true,
    shippingInfo: {
      freeShipping: true,
      estimatedDelivery: '2–4 Business Days (Express)',
      shipsFrom: 'Riyadh, Saudi Arabia'
    },
    tags: ['Espresso', 'CoffeeMaker', 'Kitchen', 'HomeAppliances', 'Barista'],
    isFeatured: true,
    createdAt: '2026-03-26T17:00:00Z'
  },
  {
    id: 'prod-18',
    title: 'Smart True HEPA Air Purifier with PM2.5 Laser Sensor & Silent Sleep Mode',
    description: 'High-performance home and office air purifier equipped with an H13 True HEPA filter capturing 99.97% of dust, pollen, pet dander, smoke, and odors. Features an intelligent PM2.5 laser particle sensor, 4-color LED air quality ring, and 22dB whisper-quiet night mode.',
    category: 'home_living',
    categoryName: 'Home, Kitchen & Living',
    price: 129.00,
    compareAtPrice: 175.00,
    currency: 'USD',
    condition: 'new',
    rating: 4.8,
    reviewsCount: 119,
    stock: 45,
    images: [
      'https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=800&h=600&fit=crop'
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=600&h=450&fit=crop',
    features: [
      'Medical-grade H13 True HEPA 3-stage composite filtration',
      'Cleans up to 500 sq ft room in only 15 minutes (CADR 250 m³/h)',
      'Infrared laser sensor automatically adjusts fan speed based on air quality',
      'Ultra-quiet sleep mode operating at whisper 22dB with display dimming'
    ],
    specifications: {
      'Coverage Area': 'Up to 500 sq.ft (46 m²)',
      'CADR': '250 m³/h (147 CFM)',
      'Noise Level': '22 dB (Sleep) – 48 dB (Turbo)',
      'Filter Lifespan': '6 to 8 Months with automatic filter change alert',
      'Power Consumption': '32 Watts energy-efficient motor'
    },
    brand: 'PureAir Pro',
    sellerId: 'u-tech',
    sellerName: 'Tech Explorer Lab',
    sellerAvatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=200&h=200&fit=crop&crop=faces',
    sellerVerified: true,
    shippingInfo: {
      freeShipping: true,
      estimatedDelivery: '2–3 Business Days',
      shipsFrom: 'Riyadh, Saudi Arabia'
    },
    tags: ['AirPurifier', 'HEPA', 'HomeLiving', 'SmartHome', 'Wellness'],
    isFeatured: false,
    createdAt: '2026-03-26T18:00:00Z'
  },
  {
    id: 'prod-19',
    title: 'Vacuum Insulated Stainless Steel Sports Tumbler 1000ml (Keep Cold 24h)',
    description: 'Heavy-duty 1000ml (34oz) double-wall vacuum insulated hydration tumbler made of kitchen-grade 18/8 stainless steel. Keeps drinks ice cold for 24 hours or piping hot for 12 hours without condensation sweat, with dual sip and straw leak-proof lid.',
    category: 'home_living',
    categoryName: 'Home, Kitchen & Living',
    price: 24.00,
    compareAtPrice: 35.00,
    currency: 'USD',
    condition: 'new',
    rating: 4.9,
    reviewsCount: 340,
    stock: 120,
    images: [
      'https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=800&h=600&fit=crop'
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=600&h=450&fit=crop',
    features: [
      'Double-wall vacuum insulation with copper lining: 24h cold / 12h hot',
      'Food-grade 18/8 pro-grade stainless steel with zero metal aftertaste',
      '100% Leak-proof 2-in-1 flip straw and direct chug opening',
      'Powder-coated scratch-resistant anti-slip exterior finish'
    ],
    specifications: {
      'Capacity': '1000 ml / 34 fl oz',
      'Material': '18/8 SUS304 Pro-Grade Stainless Steel & BPA-Free Tritan',
      'Height / Base': '27 cm / 8.5 cm (Fits standard car cup holders)',
      'Weight': '420 grams empty',
      'Dishwasher': 'Top-Rack Dishwasher Safe'
    },
    brand: 'HydroSteel Core',
    sellerId: 'u-creative',
    sellerName: 'Creative World Studio',
    sellerAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&h=200&fit=crop&crop=faces',
    sellerVerified: true,
    shippingInfo: {
      freeShipping: true,
      estimatedDelivery: '2–4 Business Days',
      shipsFrom: 'Jeddah, Saudi Arabia'
    },
    tags: ['WaterBottle', 'Tumbler', 'Fitness', 'Kitchen', 'Hydration'],
    isFeatured: false,
    createdAt: '2026-03-26T19:00:00Z'
  },
  {
    id: 'prod-20',
    title: '20V Max Brushless Cordless Drill & Impact Driver Combo Kit (2x 2.0Ah Batteries)',
    description: 'Heavy-duty 20V brushless cordless drill and impact driver combo kit designed for high-torque drilling, wood fabrication, metal screwing, and site assembly. Delivers up to 650 in-lbs of torque with 2x 2.0Ah lithium-ion battery packs and 45-minute rapid charger.',
    category: 'tools_diy',
    categoryName: 'Tools, Hardware & DIY',
    price: 139.00,
    compareAtPrice: 185.00,
    currency: 'USD',
    condition: 'new',
    rating: 4.9,
    reviewsCount: 156,
    stock: 42,
    images: [
      'https://images.unsplash.com/photo-1504148455328-c376907d081c?w=800&h=600&fit=crop'
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1504148455328-c376907d081c?w=600&h=450&fit=crop',
    features: [
      'High-efficiency brushless motor delivers 50% more runtime & 2x motor life',
      '1/2" All-metal keyless ratcheting chuck for superior bit gripping strength',
      'Variable speed dual transmission (0–500 RPM & 0–2000 RPM)',
      'Bright shadowless LED work light with 20-second shutoff delay'
    ],
    specifications: {
      'Voltage': '20V Max Lithium-Ion',
      'Max Torque': '650 in-lbs (73.4 N·m)',
      'Chuck Size': '1/2 inch (13mm) Heavy All-Metal',
      'Batteries': '2x 20V 2.0Ah Rechargeable Li-Ion Packs',
      'Case': 'Heavy-Duty Ballistic Nylon Tool Bag'
    },
    brand: 'PowerKraft Tools',
    sellerId: 'u-facade',
    sellerName: 'Apex Façade Systems',
    sellerAvatar: 'https://images.unsplash.com/photo-1541888946425-d0fbb186156f?w=200&h=200&fit=crop&crop=faces',
    sellerVerified: true,
    shippingInfo: {
      freeShipping: true,
      estimatedDelivery: '2–4 Business Days',
      shipsFrom: 'Dammam, Saudi Arabia'
    },
    tags: ['CordlessDrill', 'PowerTools', 'DIY', 'Brushless', 'Construction'],
    isFeatured: true,
    createdAt: '2026-03-26T20:00:00Z'
  },
  {
    id: 'prod-21',
    title: '108-Piece Chrome Vanadium Mechanics Precision Tool & Socket Set',
    description: 'Comprehensive 108-piece mechanical workshop toolkit forged from heat-treated Chrome Vanadium steel (Cr-V). Includes 1/4" and 1/2" 72-tooth quick-release teardrop ratchets, deep metric sockets, Torx and hex bits in a heavy-duty blow-molded travel case.',
    category: 'tools_diy',
    categoryName: 'Tools, Hardware & DIY',
    price: 79.00,
    compareAtPrice: 110.00,
    currency: 'USD',
    condition: 'new',
    rating: 4.8,
    reviewsCount: 112,
    stock: 50,
    images: [
      'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=800&h=600&fit=crop'
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=600&h=450&fit=crop',
    features: [
      'Forged Chrome Vanadium (Cr-V) steel with mirror-chrome rustproof polish',
      '72-Tooth quick-release reversible ratchet with only 5° arc swing',
      'High-visibility stamped metric socket markings for fast identification',
      'Rugged impact-resistant blow molded locking carry case'
    ],
    specifications: {
      'Piece Count': '108 Pieces',
      'Material': 'Heat-Treated Chrome-Vanadium Alloy Steel (Cr-V)',
      'Drive Sizes': '1/4 inch and 1/2 inch Metric Drive',
      'Standards': 'Meets or exceeds ANSI & DIN industrial standards',
      'Weight': '6.8 kg in protective case'
    },
    brand: 'MasterTorque',
    sellerId: 'u-facade',
    sellerName: 'Apex Façade Systems',
    sellerAvatar: 'https://images.unsplash.com/photo-1541888946425-d0fbb186156f?w=200&h=200&fit=crop&crop=faces',
    sellerVerified: true,
    shippingInfo: {
      freeShipping: true,
      estimatedDelivery: '3–5 Business Days',
      shipsFrom: 'Sharjah, UAE'
    },
    tags: ['ToolSet', 'Mechanics', 'Sockets', 'DIY', 'Workshop'],
    isFeatured: false,
    createdAt: '2026-03-26T21:00:00Z'
  },
  {
    id: 'prod-22',
    title: 'Deep Tissue Percussion Muscle Massage Gun (QuietGlide 3200 RPM & 6 Heads)',
    description: 'Therapeutic deep tissue percussion massage gun providing up to 3200 RPM vibrational therapy to relieve muscle soreness, accelerate athletic recovery, and alleviate stiffness. Includes 6 interchangeable silicone massage heads and an LED speed touchscreen.',
    category: 'sports_fitness',
    categoryName: 'Sports, Fitness & Outdoor',
    price: 69.00,
    compareAtPrice: 99.00,
    currency: 'USD',
    condition: 'new',
    rating: 4.9,
    reviewsCount: 228,
    stock: 65,
    images: [
      'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=800&h=600&fit=crop'
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=600&h=450&fit=crop',
    features: [
      '30 Adjustable vibration speeds reaching up to 3200 percussions per minute',
      'QuietGlide brushless motor maintains whisper-quiet sound below 40dB',
      '6 Customized silicone and foam massage heads for targeted muscle groups',
      'Rechargeable 2600 mAh battery providing up to 6 hours continuous runtime'
    ],
    specifications: {
      'Speed Range': '1200 – 3200 RPM (30 Speed Levels)',
      'Amplitude': '12mm Deep Tissue Percussion',
      'Noise': '< 40 dB ultra-quiet brushless motor',
      'Battery': '2600 mAh LG Lithium-Ion (USB-C Fast Charging)',
      'Weight': '0.9 kg ergonomic silicone non-slip grip'
    },
    brand: 'Theramove Pro',
    sellerId: 'u-creative',
    sellerName: 'Creative World Studio',
    sellerAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&h=200&fit=crop&crop=faces',
    sellerVerified: true,
    shippingInfo: {
      freeShipping: true,
      estimatedDelivery: '2–3 Business Days',
      shipsFrom: 'Riyadh, Saudi Arabia'
    },
    tags: ['MassageGun', 'Recovery', 'Fitness', 'SportsGear', 'Therapy'],
    isFeatured: true,
    createdAt: '2026-03-26T22:00:00Z'
  },
  {
    id: 'prod-23',
    title: 'Full-Stack Next.js 15 & React SaaS Boilerplate + Multi-Vendor Marketplace',
    description: 'Production-ready full-stack software template featuring Next.js 15 App Router, TypeScript, Tailwind CSS, Claymorphism UI kit, Stripe/PayPal checkout, multi-vendor seller dashboards, SEO metadata generation, and instant digital download licensing.',
    category: 'digital_assets',
    categoryName: 'Digital Assets, Software & Templates',
    price: 59.00,
    compareAtPrice: 99.00,
    currency: 'USD',
    condition: 'digital',
    rating: 5.0,
    reviewsCount: 79,
    stock: 9999,
    images: [
      'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=600&fit=crop'
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=450&fit=crop',
    features: [
      'Next.js 15 + React 19 + TypeScript + Tailwind CSS full source code',
      'Stripe & PayPal ready multi-currency checkout & cart state engine',
      'Clean claymorphic design components with dark mode and responsive layout',
      'Includes commercial developer license for unlimited client applications'
    ],
    specifications: {
      'Framework': 'Next.js 15 (App Router) + React 19',
      'Language': 'TypeScript 5.x',
      'Styling': 'Tailwind CSS with Custom Claymorphism Plugins',
      'Licensing': 'Commercial Unlimited Projects License',
      'Delivery': 'Instant ZIP Download + GitHub Private Repo Access'
    },
    brand: 'DevStack Digital',
    sellerId: 'u-admin',
    sellerName: 'Shafi Afzal Shah',
    sellerAvatar: '/assets/aistudio/Screenshot_20240115_120152_DWG_FastView_e3b92bfb.jpg',
    sellerVerified: true,
    shippingInfo: {
      freeShipping: true,
      estimatedDelivery: 'Instant Digital Access (ZIP + GitHub)',
      shipsFrom: 'Cloud Delivery'
    },
    tags: ['SourceCode', 'Nextjs', 'Boilerplate', 'SaaS', 'DigitalTemplate'],
    isFeatured: true,
    isCreatorProduct: true,
    createdAt: '2026-03-26T23:00:00Z'
  }
];


import { MongoClient } from 'mongodb';
import {
  SEED_USERS,
  SEED_VIDEOS,
  SEED_JOBS,
  SEED_APPLICATIONS,
  SEED_NOTIFICATIONS,
  SEED_COMMENTS,
  SEED_CONVERSATIONS,
  SEED_MESSAGES,
  SEED_REPORTS,
  SEED_AUDIT_LOGS,
  SEED_PLANS,
  SEED_STORE_PRODUCTS
} from './seed-data.js';

// Cached MongoDB Client for Serverless / Node runtime
let cachedClient = null;
let cachedDb = null;
let isMongoConnected = false;

// Fallback in-memory resilient storage if MongoDB_URI is not set or during local preview
export class MemoryStore {
  constructor() {
    this.users = [...SEED_USERS];
    this.videos = [...SEED_VIDEOS];
    this.jobs = [...SEED_JOBS];
    this.applications = [...SEED_APPLICATIONS];
    this.notifications = [...SEED_NOTIFICATIONS];
    this.comments = [...SEED_COMMENTS];
    this.conversations = [...SEED_CONVERSATIONS];
    this.messages = [...SEED_MESSAGES];
    this.reports = [...SEED_REPORTS];
    this.auditLogs = [...SEED_AUDIT_LOGS];
    this.follows = [
      { followerId: 'u-candidate1', targetId: 'u-facade' },
      { followerId: 'u-candidate1', targetId: 'u-construction' },
      { followerId: 'u-candidate1', targetId: 'u-bim' }
    ];
    this.savedJobs = [
      { userId: 'u-candidate1', jobId: 'job-1' },
      { userId: 'u-candidate1', jobId: 'job-3' }
    ];
    this.likedVideos = [
      { userId: 'u-candidate1', videoId: 'v-1' },
      { userId: 'u-candidate1', videoId: 'v-short-1' }
    ];
    this.reposts = [
      {
        id: 'rep-1',
        videoId: 'v-1',
        userId: 'u-admin',
        user: {
          name: 'Shafi Afzal Shah',
          username: 'shafi_shah',
          avatar: '/assets/aistudio/Screenshot_20240115_120152_DWG_FastView_e3b92bfb.jpg',
          verified: true,
          role: 'admin'
        },
        quoteText: 'Essential video for all façade engineering consultants and curtain wall fabrication engineers in KSA and the Gulf.',
        createdAt: new Date(Date.now() - 3600000 * 24).toISOString()
      },
      {
        id: 'rep-2',
        videoId: 'v-1',
        userId: 'u-tech',
        user: {
          name: 'Tech Explorer Lab',
          username: 'techexplorer',
          avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=200&h=200&fit=crop&crop=faces',
          verified: true,
          role: 'creator'
        },
        quoteText: 'The structural pressure calculations and seismic anchor displacement analysis here are world class.',
        createdAt: new Date(Date.now() - 3600000 * 12).toISOString()
      },
      {
        id: 'rep-3',
        videoId: 'v-short-1',
        userId: 'u-admin',
        user: {
          name: 'Shafi Afzal Shah',
          username: 'shafi_shah',
          avatar: '/assets/aistudio/Screenshot_20240115_120152_DWG_FastView_e3b92bfb.jpg',
          verified: true,
          role: 'admin'
        },
        quoteText: 'Stainless steel point-fixing mechanics in action! Amazing deflection demonstration.',
        createdAt: new Date(Date.now() - 3600000 * 6).toISOString()
      }
    ];

    this.liveMatches = [
      {
        id: 'match-1',
        title: '🔥 50,000 COIN SUBSCRIBER BATTLE: Shafi Shah vs Façade Academy',
        category: 'Engineering & Tech',
        status: 'speed_challenge',
        startedAt: new Date(Date.now() - 1000 * 180).toISOString(),
        endsAt: new Date(Date.now() + 1000 * 240).toISOString(),
        durationSeconds: 420,
        viewersCount: 1420,
        subscribersCount: 840,
        winningsPool: 38500,
        activeDrop: {
          id: 'drop-1',
          title: '🎁 500 COIN SUBSCRIBER MYSTERY DROP!',
          prizeCoins: 500,
          remainingClaims: 12,
          totalClaims: 20,
          expiresAt: new Date(Date.now() + 1000 * 180).toISOString(),
          claimedByUserIds: []
        },
        host: {
          id: 'u-admin',
          name: 'Shafi Afzal Shah',
          username: 'shafi_shah',
          avatar: '/assets/aistudio/Screenshot_20240115_120152_DWG_FastView_e3b92bfb.jpg',
          role: 'admin',
          verified: true,
          team: 'red',
          teamName: 'Red Titans (Shafi)',
          score: 19800,
          videoUrl: '/api/media/stream/video1.mp4',
          subscribersGiftingCount: 42
        },
        opponent: {
          id: 'u-facade',
          name: 'Façade Engineering Academy',
          username: 'facade_academy',
          avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=faces',
          role: 'creator',
          verified: true,
          team: 'blue',
          teamName: 'Blue Force (Façade)',
          score: 18700,
          videoUrl: '/api/media/stream/short1.mp4',
          subscribersGiftingCount: 38
        },
        chatMessages: [
          {
            id: 'm-1',
            userId: 'u-tech',
            userName: 'Tech Explorer Lab',
            userAvatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=200&h=200&fit=crop&crop=faces',
            isSubscriber: true,
            subscriberTier: 'Pro Sub',
            text: 'Drop the Turbo Rockets on Team Red! Double points active! 🚀🔥',
            createdAt: new Date(Date.now() - 45000).toISOString()
          },
          {
            id: 'm-2',
            userId: 'u-construction',
            userName: 'Global Construction Leaders',
            userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=faces',
            isSubscriber: true,
            subscriberTier: 'VIP Sub',
            text: 'Blue Team catching up fast! Everyone tap and boost! 🏆⚡',
            createdAt: new Date(Date.now() - 25000).toISOString()
          },
          {
            id: 'm-3',
            userId: 'u-bim',
            userName: 'BIM Innovations Global',
            userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&crop=faces',
            isSubscriber: true,
            subscriberTier: 'Sub',
            text: 'I just won 250 coins from the mystery drop! Claim yours! 🎁🎉',
            createdAt: new Date(Date.now() - 10000).toISOString()
          }
        ],
        recentGifts: [
          {
            id: 'g-1',
            userId: 'u-tech',
            userName: 'Tech Explorer Lab',
            userAvatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=200&h=200&fit=crop&crop=faces',
            giftId: 'rocket',
            giftName: 'Turbo Rocket',
            giftIcon: '🚀',
            giftCost: 500,
            points: 1000,
            multiplier: 2,
            targetTeam: 'red',
            createdAt: new Date(Date.now() - 40000).toISOString()
          },
          {
            id: 'g-2',
            userId: 'u-construction',
            userName: 'Global Construction Leaders',
            userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=faces',
            giftId: 'trophy',
            giftName: 'Victory Cup',
            giftIcon: '🏆',
            giftCost: 1200,
            points: 2400,
            multiplier: 2,
            targetTeam: 'blue',
            createdAt: new Date(Date.now() - 20000).toISOString()
          }
        ],
        topDonors: [
          {
            userId: 'u-tech',
            userName: 'Tech Explorer Lab',
            userAvatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=200&h=200&fit=crop&crop=faces',
            targetTeam: 'red',
            totalPoints: 8500,
            isSubscriber: true
          },
          {
            userId: 'u-construction',
            userName: 'Global Construction Leaders',
            userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=faces',
            targetTeam: 'blue',
            totalPoints: 7200,
            isSubscriber: true
          },
          {
            userId: 'u-candidate1',
            userName: 'Ahmed Al-Shehri',
            userAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&h=200&fit=crop&crop=faces',
            targetTeam: 'red',
            totalPoints: 3400,
            isSubscriber: true
          }
        ]
      },
      {
        id: 'match-2',
        title: '⚡ ARCHITECTURE DERBY: BIM Global vs Modern Structures',
        category: 'Architecture',
        status: 'live',
        startedAt: new Date(Date.now() - 1000 * 60).toISOString(),
        endsAt: new Date(Date.now() + 1000 * 360).toISOString(),
        durationSeconds: 420,
        viewersCount: 890,
        subscribersCount: 410,
        winningsPool: 14800,
        activeDrop: {
          id: 'drop-2',
          title: '🎁 250 COIN SPEED CHALLENGE DROP!',
          prizeCoins: 250,
          remainingClaims: 8,
          totalClaims: 15,
          expiresAt: new Date(Date.now() + 1000 * 120).toISOString(),
          claimedByUserIds: []
        },
        host: {
          id: 'u-bim',
          name: 'BIM Innovations Global',
          username: 'bim_innovations',
          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&crop=faces',
          role: 'creator',
          verified: true,
          team: 'red',
          teamName: 'Revit Masters',
          score: 8400,
          videoUrl: '/api/media/stream/video1.mp4',
          subscribersGiftingCount: 22
        },
        opponent: {
          id: 'u-tech',
          name: 'Tech Explorer Lab',
          username: 'techexplorer',
          avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=200&h=200&fit=crop&crop=faces',
          role: 'creator',
          verified: true,
          team: 'blue',
          teamName: 'Parametric Squad',
          score: 9100,
          videoUrl: '/api/media/stream/short1.mp4',
          subscribersGiftingCount: 26
        },
        chatMessages: [],
        recentGifts: [],
        topDonors: []
      }
    ];

    this.storeProducts = [...SEED_STORE_PRODUCTS];
    this.storeOrders = [];
  }
}

export const memoryStore = new MemoryStore();

/**
 * Connects to MongoDB Atlas using process.env.MONGODB_URI.
 * Caches the connection across serverless invocations.
 */
export async function connectToDatabase() {
  const uri = process.env.MONGODB_URI;
  const dbName = process.env.MONGODB_DB_NAME || 'videohub_jobs';

  if (!uri || uri.includes('username:password')) {
    // No production URI provided or default placeholder; fallback to MemoryStore
    return { client: null, db: null, isConnected: false };
  }

  if (cachedClient && cachedDb) {
    return { client: cachedClient, db: cachedDb, isConnected: true };
  }

  try {
    const client = new MongoClient(uri, {
      connectTimeoutMS: 5000,
      serverSelectionTimeoutMS: 5000
    });

    await client.connect();
    const db = client.db(dbName);

    cachedClient = client;
    cachedDb = db;
    isMongoConnected = true;
    console.log(`[Database] Successfully connected to MongoDB Atlas database: ${dbName}`);

    // Seed database if empty
    await seedMongoIfEmpty(db);

    return { client, db, isConnected: true };
  } catch (error) {
    console.warn('[Database] MongoDB Atlas connection failed or timed out. Falling back to in-memory store for resilience.');
    return { client: null, db: null, isConnected: false };
  }
}

async function seedMongoIfEmpty(db) {
  try {
    const usersCount = await db.collection('users').countDocuments();
    if (usersCount === 0) {
      console.log('[Database] Seeding initial collections in MongoDB Atlas...');
      await db.collection('users').insertMany(SEED_USERS);
      await db.collection('videos').insertMany(SEED_VIDEOS);
      await db.collection('jobs').insertMany(SEED_JOBS);
      await db.collection('applications').insertMany(SEED_APPLICATIONS);
      await db.collection('notifications').insertMany(SEED_NOTIFICATIONS);
      await db.collection('plans').insertMany(SEED_PLANS);
      await db.collection('auditLogs').insertMany(SEED_AUDIT_LOGS);
      console.log('[Database] Seeding completed.');
    }
  } catch (e) {
    console.warn('[Database] Seeding check skipped:', e);
  }
}

export function isDbLive() {
  return isMongoConnected;
}

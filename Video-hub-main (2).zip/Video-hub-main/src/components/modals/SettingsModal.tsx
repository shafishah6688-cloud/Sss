import React from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { useI18n } from '../../context/I18nContext.tsx';
import { X, Play, Globe } from 'lucide-react';

export const SettingsModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const { isAutoplay, setIsAutoplay, setActiveView } = useApp();
  const { language, setLanguage, t } = useI18n();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="clay-card p-6 w-full max-w-md bg-white dark:bg-slate-900">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-lg font-black text-slate-900 dark:text-slate-100">Settings</h2>
          <button onClick={onClose} className="p-1 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-800">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-violet-100 text-violet-600 dark:bg-violet-900/40 dark:text-violet-300">
                <Play className="w-5 h-5" />
              </div>
              <div>
                <p className="font-bold text-sm text-slate-900 dark:text-slate-100">{t('autoplay')}</p>
                <p className="text-[11px] text-slate-500">{t('autoplay_desc')}</p>
              </div>
            </div>
            <button
              onClick={() => setIsAutoplay(!isAutoplay)}
              className={`w-12 h-6 rounded-full transition-colors ${isAutoplay ? 'bg-violet-600' : 'bg-slate-300 dark:bg-slate-700'}`}
            >
              <div className={`w-5 h-5 bg-white rounded-full transition-transform ${isAutoplay ? 'translate-x-6' : 'translate-x-1'}`} />
            </button>
          </div>

          <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-800">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-emerald-100 text-emerald-600 dark:bg-emerald-900/40 dark:text-emerald-300">
                <Globe className="w-5 h-5" />
              </div>
              <div>
                <p className="font-bold text-sm text-slate-900 dark:text-slate-100">{t('language')}</p>
                <p className="text-[11px] text-slate-500">{t('language_desc')}</p>
              </div>
            </div>
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value as any)}
              className="bg-white dark:bg-slate-700 p-2 rounded-lg text-xs font-bold text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600"
            >
              <option value="en">English</option>
              <option value="es">Español</option>
              <option value="fr">Français</option>
              <option value="ar">العربية</option>
            </select>
          </div>

          {/* Supplementary Platform Rules & Legal Compliance */}
          <div className="p-4 rounded-2xl bg-violet-50/70 dark:bg-violet-950/20 border border-violet-200 dark:border-violet-900/40 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-violet-600" />
              <p className="text-xs font-black text-slate-900 dark:text-slate-100 uppercase tracking-wider">
                World Video Hub Policies
              </p>
            </div>
            <p className="text-[11px] text-slate-600 dark:text-slate-400">
              Supplementary provisions governing video uploads (A), shorts & long videos (B & C), global jobs (D), sponsored promotions (E), reporting (F), account deletion (G), and endorsement disclaimers (H).
            </p>
            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={() => {
                  onClose();
                  setActiveView('policies');
                }}
                className="flex-1 px-3 py-2 text-xs font-bold rounded-xl bg-violet-600 hover:bg-violet-700 text-white transition shadow-sm text-center"
              >
                Supplementary Rules (A–H)
              </button>
              <button
                onClick={() => {
                  onClose();
                  setActiveView('policies');
                }}
                className="px-3 py-2 text-xs font-bold rounded-xl bg-white dark:bg-slate-800 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900/40 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition text-center"
              >
                Delete Account (Sec. G)
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

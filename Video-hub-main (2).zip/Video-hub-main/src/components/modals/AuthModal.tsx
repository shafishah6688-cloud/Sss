import React, { useState } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { X, Lock, Mail, User, Shield, Briefcase, Video, Globe } from 'lucide-react';

export const AuthModal: React.FC = () => {
  const { authModalOpen, setAuthModalOpen, setCurrentUser, showToast, refreshUserData } = useApp();
  const [isRegister, setIsRegister] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    username: '',
    email: '',
    password: '',
    role: 'user',
    country: 'Saudi Arabia'
  });
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!authModalOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg('');

    const endpoint = isRegister ? '/api/auth/register' : '/api/auth/login';
    const payload = isRegister ? formData : { emailOrUsername: formData.email || formData.username };

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Authentication failed');
      }

      setCurrentUser(data.user);
      showToast(isRegister ? 'Account created! Welcome to VideoHub + Global Jobs' : `Welcome back, ${data.user.name}!`);
      setAuthModalOpen(false);
      refreshUserData();
    } catch (err: any) {
      setErrorMsg(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleQuickDemo = async (userId: string) => {
    setLoading(true);
    setErrorMsg('');
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ emailOrUsername: userId })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Login failed');
      setCurrentUser(data.user);
      showToast(`Logged in as demo persona: ${data.user.name}`);
      setAuthModalOpen(false);
      refreshUserData();
    } catch (err: any) {
      setErrorMsg(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md clay-card p-6 bg-white dark:bg-[#181D2E] text-slate-800 dark:text-slate-100 shadow-2xl">
        <button
          onClick={() => setAuthModalOpen(false)}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-6">
          <div className="w-12 h-12 mx-auto rounded-2xl bg-gradient-to-tr from-violet-600 to-pink-500 flex items-center justify-center text-white shadow-lg shadow-purple-500/30 mb-2">
            <Lock className="w-6 h-6" />
          </div>
          <h2 className="text-xl font-extrabold tracking-tight">
            {isRegister ? 'Join VideoHub + Global Jobs' : 'Welcome Back'}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Access creator feeds, engineering video hubs, and global job openings.
          </p>
        </div>

        {/* 1-Click Fast Demo Logins */}
        <div className="mb-5 p-3 rounded-2xl bg-violet-50/80 dark:bg-violet-950/40 border border-violet-200/50 dark:border-violet-800/50">
          <div className="text-[11px] font-bold text-violet-800 dark:text-violet-300 mb-2 flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5" />
            Quick Demo Sign-In (1 Click)
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              type="button"
              onClick={() => handleQuickDemo('u-candidate1')}
              className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-left hover:border-violet-400 transition"
            >
              <div className="font-bold text-emerald-600 dark:text-emerald-400">Tariq (Candidate)</div>
              <div className="text-[10px] text-slate-400">Façade Engineer</div>
            </button>
            <button
              type="button"
              onClick={() => handleQuickDemo('u-admin')}
              className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-left hover:border-violet-400 transition"
            >
              <div className="font-bold text-rose-600 dark:text-rose-400">Shafi Afzal Shah (Admin)</div>
              <div className="text-[10px] text-slate-400">Chief Administrator</div>
            </button>
            <button
              type="button"
              onClick={() => handleQuickDemo('u-facade')}
              className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-left hover:border-violet-400 transition"
            >
              <div className="font-bold text-violet-600 dark:text-violet-400">Façade Academy</div>
              <div className="text-[10px] text-slate-400">Top Creator</div>
            </button>
            <button
              type="button"
              onClick={() => handleQuickDemo('u-recruiter1')}
              className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-left hover:border-violet-400 transition"
            >
              <div className="font-bold text-blue-600 dark:text-blue-400">Apex Recruiter</div>
              <div className="text-[10px] text-slate-400">Employer Portal</div>
            </button>
          </div>
        </div>

        {errorMsg && (
          <div className="mb-4 p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5">
          {isRegister && (
            <div>
              <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">Full Name</label>
              <div className="relative">
                <User className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  required
                  placeholder="e.g. Tariq Mansoor"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full pl-9 pr-3 py-2 text-xs clay-input"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
              {isRegister ? 'Email Address' : 'Email or Username'}
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
              <input
                type="text"
                required
                placeholder={isRegister ? 'name@example.com' : 'admin@videohub.internal'}
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value, username: e.target.value })}
                className="w-full pl-9 pr-3 py-2 text-xs clay-input"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
              <input
                type="password"
                required
                placeholder="••••••••"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="w-full pl-9 pr-3 py-2 text-xs clay-input"
              />
            </div>
          </div>

          {isRegister && (
            <div>
              <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">Account Purpose</label>
              <select
                value={formData.role}
                onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                className="w-full px-3 py-2 text-xs clay-input bg-white dark:bg-slate-800"
              >
                <option value="user">Job Seeker / Candidate</option>
                <option value="creator">Creator & Video Publisher</option>
                <option value="employer">Employer / Recruiter</option>
              </select>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 clay-btn clay-btn-primary text-xs font-bold shadow-md active:scale-95 transition disabled:opacity-50"
          >
            {loading ? 'Processing...' : isRegister ? 'Create Account' : 'Sign In'}
          </button>
        </form>

        <div className="mt-4 text-center">
          <button
            type="button"
            onClick={() => {
              setIsRegister(!isRegister);
              setErrorMsg('');
            }}
            className="text-xs font-bold text-violet-600 dark:text-violet-400 hover:underline"
          >
            {isRegister ? 'Already have an account? Sign in' : "Don't have an account? Register now"}
          </button>
        </div>
      </div>
    </div>
  );
};

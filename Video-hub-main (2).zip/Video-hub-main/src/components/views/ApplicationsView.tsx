import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { JobApplication, ApplicationStatus } from '../../types/index.ts';
import {
  FileCheck2,
  Clock,
  Building2,
  FileText,
  MessageSquare,
  CheckCircle,
  XCircle,
  User,
  ExternalLink,
  ChevronRight,
  Filter,
  Video as VideoIcon,
  Play,
  X,
  Sparkles
} from 'lucide-react';

const STATUS_CONFIG: Record<ApplicationStatus, { label: string; bg: string; text: string }> = {
  'Submitted': { label: 'Submitted', bg: 'bg-blue-100 dark:bg-blue-950/60', text: 'text-blue-700 dark:text-blue-300' },
  'Under Review': { label: 'Under Review', bg: 'bg-amber-100 dark:bg-amber-950/60', text: 'text-amber-700 dark:text-amber-300' },
  'Shortlisted': { label: 'Shortlisted', bg: 'bg-emerald-100 dark:bg-emerald-950/60', text: 'text-emerald-700 dark:text-emerald-300' },
  'Interview': { label: 'Interview Scheduled', bg: 'bg-purple-100 dark:bg-purple-950/60', text: 'text-purple-700 dark:text-purple-300' },
  'Hired': { label: 'Offer / Hired', bg: 'bg-teal-100 dark:bg-teal-950/60', text: 'text-teal-700 dark:text-teal-300' },
  'Rejected': { label: 'Not Selected', bg: 'bg-rose-100 dark:bg-rose-950/60', text: 'text-rose-700 dark:text-rose-300' }
};

export const ApplicationsView: React.FC = () => {
  const { currentUser, setActiveView, showToast, openInMiniPlayer } = useApp();
  const [applications, setApplications] = useState<JobApplication[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('All');
  const [onlyVideoPitch, setOnlyVideoPitch] = useState(false);
  const [activeVideoPitch, setActiveVideoPitch] = useState<{
    url: string;
    title: string;
    candidate: string;
    jobTitle: string;
  } | null>(null);

  const isRecruiterOrAdmin = currentUser?.role === 'employer' || currentUser?.role === 'admin';

  useEffect(() => {
    fetchApplications();
  }, [currentUser?.id, isRecruiterOrAdmin]);

  const fetchApplications = async () => {
    setLoading(true);
    try {
      const endpoint = isRecruiterOrAdmin ? '/api/applications/employer' : '/api/applications/my';
      const res = await fetch(endpoint);
      if (res.ok) {
        const data = await res.json();
        setApplications(data.applications || []);
      }
    } catch (e) {
      console.warn('Failed to load applications', e);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (appId: string, newStatus: ApplicationStatus) => {
    try {
      const res = await fetch(`/api/applications/${appId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });
      if (res.ok) {
        setApplications(prev =>
          prev.map(a => (a.id === appId ? { ...a, status: newStatus } : a))
        );
        showToast(`Candidate status updated to "${newStatus}"`);
      }
    } catch (e) {
      showToast('Error updating status', 'error');
    }
  };

  const filtered = applications.filter((a) => {
    const matchesStatus = statusFilter === 'All' || a.status === statusFilter;
    const matchesPitch = !onlyVideoPitch || Boolean(a.videoPitchUrl);
    return matchesStatus && matchesPitch;
  });

  const totalWithPitches = applications.filter((a) => a.videoPitchUrl).length;

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-16">
      {/* Header */}
      <div className="clay-card p-6 bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-blue-500/10 border border-emerald-300/40 dark:border-emerald-700/40">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-extrabold text-xs uppercase tracking-wider">
              <FileCheck2 className="w-4 h-4" />
              {isRecruiterOrAdmin ? 'Talent Acquisition & Candidate Review' : 'Career Management'}
            </div>
            <h1 className="text-2xl font-black text-slate-900 dark:text-slate-100 tracking-tight mt-1">
              {isRecruiterOrAdmin ? 'Applicant Tracking System (ATS)' : 'My Job Applications'}
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              {isRecruiterOrAdmin
                ? 'Review candidates, assess CV files, watch video pitches, and advance applicants.'
                : 'Track the status of your submitted applications and video pitches in real-time.'}
            </p>
          </div>

          <button
            onClick={() => setActiveView('jobs')}
            className="clay-btn clay-btn-mint px-4 py-2 text-xs font-bold self-start sm:self-auto"
          >
            Explore More Jobs
          </button>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 pt-4">
          {['All', 'Submitted', 'Under Review', 'Shortlisted', 'Interview', 'Hired', 'Rejected'].map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                statusFilter === st
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-white/80 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
              }`}
            >
              {st}
            </button>
          ))}

          <button
            onClick={() => setOnlyVideoPitch(!onlyVideoPitch)}
            className={`px-3 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 ${
              onlyVideoPitch
                ? 'bg-gradient-to-r from-violet-600 to-pink-600 text-white shadow-md'
                : 'bg-white/80 dark:bg-slate-800 text-violet-600 dark:text-violet-400 border border-violet-300 dark:border-violet-700'
            }`}
          >
            <VideoIcon className="w-3.5 h-3.5" />
            <span>With Video Pitch ({totalWithPitches})</span>
          </button>
        </div>
      </div>

      {/* Applications List */}
      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map(n => (
            <div key={n} className="clay-card p-4 animate-pulse space-y-2">
              <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded w-1/3" />
              <div className="h-3 bg-slate-200 dark:bg-slate-800 rounded w-1/4" />
            </div>
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="clay-card p-12 text-center max-w-md mx-auto">
          <div className="w-16 h-16 mx-auto rounded-3xl bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center mb-3">
            <FileText className="w-8 h-8" />
          </div>
          <h3 className="text-sm font-extrabold text-slate-800 dark:text-slate-200">
            No applications found
          </h3>
          <p className="text-xs text-slate-400 mt-1 mb-4">
            {isRecruiterOrAdmin
              ? 'No applicants have submitted applications matching this status.'
              : 'You have not submitted any applications matching this status yet.'}
          </p>
          <button
            onClick={() => setActiveView('jobs')}
            className="clay-btn clay-btn-primary px-4 py-2 text-xs font-bold"
          >
            Browse Available Positions
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map((app) => {
            const statusConfig = STATUS_CONFIG[app.status] || STATUS_CONFIG['Submitted'];

            return (
              <div key={app.id} className="clay-card p-5 bg-white dark:bg-[#181D2E] space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
                        {app.jobTitle}
                      </h3>
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${statusConfig.bg} ${statusConfig.text}`}>
                        {statusConfig.label}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5 mt-1">
                      <Building2 className="w-3.5 h-3.5" />
                      {app.company} • Submitted on {new Date(app.createdAt).toLocaleDateString()}
                    </p>
                  </div>

                  {/* Recruiter Status Action Selector */}
                  {isRecruiterOrAdmin && (
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-bold text-slate-400">Update Status:</span>
                      <select
                        value={app.status}
                        onChange={(e) => handleUpdateStatus(app.id, e.target.value as ApplicationStatus)}
                        className="px-2.5 py-1 text-xs clay-input bg-white dark:bg-slate-800 font-bold"
                      >
                        <option value="Submitted">Submitted</option>
                        <option value="Under Review">Under Review</option>
                        <option value="Shortlisted">Shortlisted</option>
                        <option value="Interview">Interview</option>
                        <option value="Hired">Hired</option>
                        <option value="Rejected">Rejected</option>
                      </select>
                    </div>
                  )}
                </div>

                {/* Candidate Information & CV Box */}
                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900/40 border border-slate-200/60 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase">Applicant</span>
                    <p className="font-bold text-slate-800 dark:text-slate-200 mt-0.5">{app.applicantName}</p>
                    <p className="text-[11px] text-slate-500">{app.applicantEmail}</p>
                    <p className="text-[11px] text-slate-400">{app.applicantPhone}</p>
                  </div>

                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase">Attached Resume</span>
                    <div className="flex items-center gap-2 mt-1">
                      <FileText className="w-4 h-4 text-violet-500" />
                      <span className="font-bold text-slate-700 dark:text-slate-300 truncate">
                        {app.resumeFileName}
                      </span>
                    </div>
                    {app.portfolioUrl && (
                      <a
                        href={app.portfolioUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[11px] font-semibold text-violet-600 hover:underline flex items-center gap-1 mt-1"
                      >
                        <ExternalLink className="w-3 h-3" />
                        View Portfolio
                      </a>
                    )}
                  </div>

                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase">Cover Note</span>
                    <p className="text-[11px] text-slate-600 dark:text-slate-400 line-clamp-2 mt-0.5 italic">
                      "{app.coverNote || 'No extra cover note provided.'}"
                    </p>
                  </div>
                </div>

                {/* Candidate Video Pitch Card (if attached) */}
                {app.videoPitchUrl && (
                  <div className="p-3.5 rounded-2xl bg-gradient-to-r from-violet-600/10 via-pink-600/10 to-amber-500/10 border border-violet-400/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-violet-600 to-pink-500 text-white flex items-center justify-center shadow-md flex-shrink-0">
                        <Play className="w-4 h-4 fill-white ml-0.5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-black text-slate-900 dark:text-white">
                            Candidate Video Pitch
                          </span>
                          <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-violet-600 text-white">
                            {app.videoPitchDuration || '0:45'}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-600 dark:text-slate-300 font-medium truncate mt-0.5">
                          {app.videoPitchTitle || 'Engineering Project & Portfolio Demonstration'}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() =>
                        setActiveVideoPitch({
                          url: app.videoPitchUrl!,
                          title: app.videoPitchTitle || 'Candidate Video Pitch',
                          candidate: app.applicantName,
                          jobTitle: app.jobTitle
                        })
                      }
                      className="clay-btn clay-btn-primary px-4 py-2 text-xs font-bold flex items-center gap-2 self-start sm:self-auto shadow-md"
                    >
                      <Play className="w-3.5 h-3.5 fill-white" />
                      Watch Video Pitch
                    </button>
                  </div>
                )}

                {/* Direct Message CTA */}
                <div className="flex items-center justify-between pt-1">
                  <span className="text-[11px] text-slate-400">
                    Last updated: {new Date(app.updatedAt || app.createdAt).toLocaleString()}
                  </span>
                  <button
                    onClick={() => setActiveView('messages')}
                    className="clay-btn clay-btn-secondary px-3 py-1.5 text-xs font-bold gap-1.5"
                  >
                    <MessageSquare className="w-3.5 h-3.5 text-violet-500" />
                    Open Chat Thread
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Video Pitch Playback Modal */}
      {activeVideoPitch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-2xl clay-card p-5 bg-white dark:bg-[#181D2E] text-slate-800 dark:text-slate-100 shadow-2xl">
            <button
              onClick={() => setActiveVideoPitch(null)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl z-10 bg-black/20 hover:bg-black/40 text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="mb-3 pr-10">
              <div className="flex items-center gap-2 text-xs font-bold text-violet-600 dark:text-violet-400 uppercase tracking-wider">
                <VideoIcon className="w-4 h-4" />
                Candidate Video Pitch • {activeVideoPitch.jobTitle}
              </div>
              <h3 className="text-lg font-black text-slate-900 dark:text-slate-100">
                {activeVideoPitch.title}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Presented by <strong>{activeVideoPitch.candidate}</strong>
              </p>
            </div>

            <div className="aspect-video w-full rounded-2xl overflow-hidden bg-black shadow-lg">
              <video
                src={activeVideoPitch.url}
                controls
                autoPlay
                playsInline
                className="w-full h-full object-cover"
              />
            </div>

            <div className="mt-4 flex items-center justify-between">
              <span className="text-xs text-slate-400">
                Evaluating candidate verbal communication and technical demonstration.
              </span>
              <button
                onClick={() => setActiveVideoPitch(null)}
                className="clay-btn clay-btn-secondary px-4 py-1.5 text-xs font-bold"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

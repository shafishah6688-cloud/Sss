import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { Playlist, Video } from '../../types/index.ts';
import {
  ListVideo,
  Play,
  Trash2,
  Edit2,
  Plus,
  ArrowUp,
  ArrowDown,
  Clock,
  Sparkles,
  Check,
  X,
  ExternalLink,
  Film
} from 'lucide-react';

export const PlaylistsView: React.FC = () => {
  const {
    playlists,
    createPlaylist,
    deletePlaylist,
    renamePlaylist,
    removeVideoFromPlaylist,
    reorderPlaylistVideos,
    playPlaylist,
    setActiveVideo,
    setActiveView,
    showToast
  } = useApp();

  const [selectedPlaylistId, setSelectedPlaylistId] = useState<string>(
    playlists[0]?.id || 'default'
  );
  const [playlistVideos, setPlaylistVideos] = useState<Record<string, Video>>({});
  const [loading, setLoading] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newPlaylistName, setNewPlaylistName] = useState('');
  const [editingName, setEditingName] = useState(false);
  const [renamedTitle, setRenamedTitle] = useState('');

  const activePlaylist =
    playlists.find((p) => p.id === selectedPlaylistId) || playlists[0];

  useEffect(() => {
    if (playlists.length > 0 && !playlists.some((p) => p.id === selectedPlaylistId)) {
      setSelectedPlaylistId(playlists[0].id);
    }
  }, [playlists, selectedPlaylistId]);

  // Fetch details for all videos in the active playlist
  useEffect(() => {
    if (!activePlaylist || !activePlaylist.videoIds?.length) return;

    const missingIds = activePlaylist.videoIds.filter((id) => !playlistVideos[id]);
    if (missingIds.length === 0) return;

    setLoading(true);
    Promise.all(
      missingIds.map((id) =>
        fetch(`/api/videos/${id}`)
          .then((r) => r.json())
          .then((d) => (d.video ? { [id]: d.video } : null))
          .catch(() => null)
      )
    )
      .then((results) => {
        const updates: Record<string, Video> = {};
        results.forEach((item) => {
          if (item) Object.assign(updates, item);
        });
        setPlaylistVideos((prev) => ({ ...prev, ...updates }));
      })
      .finally(() => setLoading(false));
  }, [activePlaylist?.id, activePlaylist?.videoIds]);

  const handleCreateNew = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPlaylistName.trim()) return;
    createPlaylist(newPlaylistName.trim());
    setNewPlaylistName('');
    setShowCreateModal(false);
  };

  const handleSaveRename = () => {
    if (activePlaylist && renamedTitle.trim()) {
      renamePlaylist(activePlaylist.id, renamedTitle.trim());
      setEditingName(false);
    }
  };

  const handleMoveVideo = (idx: number, direction: 'up' | 'down') => {
    if (!activePlaylist) return;
    const ids = [...activePlaylist.videoIds];
    const targetIdx = direction === 'up' ? idx - 1 : idx + 1;
    if (targetIdx < 0 || targetIdx >= ids.length) return;

    const temp = ids[idx];
    ids[idx] = ids[targetIdx];
    ids[targetIdx] = temp;

    reorderPlaylistVideos(activePlaylist.id, ids);
    showToast('Video order updated');
  };

  const handlePlaySingle = (video: Video) => {
    setActiveVideo(video);
    setActiveView('watch');
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-16">
      {/* Header Banner */}
      <div className="clay-card p-6 bg-gradient-to-r from-violet-600/10 via-indigo-500/10 to-pink-500/10 border border-violet-300/40 dark:border-violet-700/40">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-violet-600 dark:text-violet-400 font-extrabold text-xs uppercase tracking-wider">
              <ListVideo className="w-4 h-4" />
              Custom Collections & Learning Tracks
            </div>
            <h1 className="text-2xl font-black text-slate-900 dark:text-slate-100 tracking-tight mt-1">
              Playlists & Video Library
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Organize your architectural tutorials, engineering masterclasses, and saved job reels in curated playlists.
            </p>
          </div>

          <button
            onClick={() => setShowCreateModal(true)}
            className="clay-btn clay-btn-primary px-4 py-2.5 text-xs font-bold flex items-center gap-2 self-start sm:self-auto shadow-md"
          >
            <Plus className="w-4 h-4" />
            New Playlist
          </button>
        </div>
      </div>

      {/* Main Grid: Playlist Tabs on left, Videos list on right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Playlists Sidebar list */}
        <div className="lg:col-span-4 space-y-3">
          <div className="clay-card p-4 bg-white dark:bg-[#181D2E] space-y-2">
            <h3 className="text-xs font-extrabold text-slate-400 uppercase tracking-wider px-2">
              Your Playlists ({playlists.length})
            </h3>

            <div className="space-y-1.5">
              {playlists.map((pl) => {
                const isSelected = activePlaylist?.id === pl.id;
                return (
                  <button
                    key={pl.id}
                    onClick={() => {
                      setSelectedPlaylistId(pl.id);
                      setEditingName(false);
                    }}
                    className={`w-full text-left px-3.5 py-3 rounded-2xl transition flex items-center justify-between text-xs font-bold ${
                      isSelected
                        ? 'bg-violet-600 text-white shadow-md shadow-violet-500/20'
                        : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <ListVideo className={`w-4 h-4 flex-shrink-0 ${isSelected ? 'text-white' : 'text-violet-500'}`} />
                      <span className="truncate">{pl.name}</span>
                    </div>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-black ${
                        isSelected
                          ? 'bg-white/20 text-white'
                          : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      {pl.videoIds?.length || 0}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Selected Playlist Content */}
        <div className="lg:col-span-8">
          {activePlaylist ? (
            <div className="clay-card p-6 bg-white dark:bg-[#181D2E] space-y-5">
              {/* Playlist Action Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
                <div className="space-y-1 flex-1">
                  {editingName ? (
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={renamedTitle}
                        onChange={(e) => setRenamedTitle(e.target.value)}
                        className="clay-input px-3 py-1.5 text-sm font-extrabold flex-1"
                        autoFocus
                      />
                      <button
                        onClick={handleSaveRename}
                        className="p-2 rounded-xl bg-emerald-600 text-white hover:bg-emerald-700"
                        title="Save Name"
                      >
                        <Check className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setEditingName(false)}
                        className="p-2 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300"
                        title="Cancel"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2.5">
                      <h2 className="text-xl font-black text-slate-900 dark:text-slate-100">
                        {activePlaylist.name}
                      </h2>
                      {activePlaylist.id !== 'default' && (
                        <button
                          onClick={() => {
                            setRenamedTitle(activePlaylist.name);
                            setEditingName(true);
                          }}
                          className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                          title="Rename playlist"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  )}

                  <p className="text-xs text-slate-400 font-medium">
                    {activePlaylist.videoIds?.length || 0} videos in queue
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => playPlaylist(activePlaylist, 0)}
                    disabled={!activePlaylist.videoIds?.length}
                    className="clay-btn clay-btn-mint px-4 py-2 text-xs font-bold flex items-center gap-2 shadow disabled:opacity-40"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    Play All
                  </button>

                  {activePlaylist.id !== 'default' && (
                    <button
                      onClick={() => deletePlaylist(activePlaylist.id)}
                      className="p-2 rounded-xl text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60"
                      title="Delete this playlist"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Videos list */}
              {activePlaylist.videoIds?.length === 0 ? (
                <div className="py-12 text-center space-y-3">
                  <div className="w-14 h-14 mx-auto rounded-3xl bg-violet-100 dark:bg-violet-950/60 text-violet-600 dark:text-violet-400 flex items-center justify-center">
                    <Film className="w-7 h-7" />
                  </div>
                  <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">
                    This playlist is currently empty
                  </h3>
                  <p className="text-xs text-slate-400 max-w-sm mx-auto">
                    Save videos while exploring tutorials or engineering videos by clicking the "Bookmark / Save" button.
                  </p>
                  <button
                    onClick={() => setActiveView('home')}
                    className="clay-btn clay-btn-primary px-4 py-2 text-xs font-bold mt-2"
                  >
                    Explore Videos
                  </button>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {activePlaylist.videoIds.map((vidId, idx) => {
                    const video = playlistVideos[vidId];

                    return (
                      <div
                        key={`${vidId}-${idx}`}
                        className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-900/40 border border-slate-200/60 dark:border-slate-800/80 flex items-center gap-3.5 group hover:border-violet-400/50 transition"
                      >
                        {/* Index Number */}
                        <span className="text-xs font-black text-slate-400 w-5 text-center flex-shrink-0">
                          {idx + 1}
                        </span>

                        {/* Thumbnail */}
                        <div
                          onClick={() => video && handlePlaySingle(video)}
                          className="relative w-24 sm:w-28 aspect-video rounded-xl overflow-hidden bg-slate-800 flex-shrink-0 cursor-pointer shadow-sm group-hover:scale-105 transition-transform"
                        >
                          <img
                            src={
                              video?.thumbnailUrl ||
                              'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=300&h=170&fit=crop'
                            }
                            alt={video?.title || 'Video'}
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                            <Play className="w-5 h-5 text-white fill-white" />
                          </div>
                          {video?.duration && (
                            <span className="absolute bottom-1 right-1 text-[9px] font-bold px-1.5 py-0.5 rounded bg-black/80 text-white">
                              {video.duration}
                            </span>
                          )}
                        </div>

                        {/* Video Info */}
                        <div
                          onClick={() => video && handlePlaySingle(video)}
                          className="flex-1 min-w-0 cursor-pointer"
                        >
                          <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100 line-clamp-1 hover:text-violet-600 transition">
                            {video ? video.title : `Video #${vidId}`}
                          </h4>
                          <p className="text-[11px] text-slate-400 truncate mt-0.5">
                            {video ? video.creator.name : 'Creator'}
                          </p>
                        </div>

                        {/* Reorder and Delete Actions */}
                        <div className="flex items-center gap-1 flex-shrink-0">
                          <button
                            onClick={() => handleMoveVideo(idx, 'up')}
                            disabled={idx === 0}
                            className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-700 disabled:opacity-20 transition"
                            title="Move Up"
                          >
                            <ArrowUp className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleMoveVideo(idx, 'down')}
                            disabled={idx === activePlaylist.videoIds.length - 1}
                            className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-700 disabled:opacity-20 transition"
                            title="Move Down"
                          >
                            <ArrowDown className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => removeVideoFromPlaylist(activePlaylist.id, vidId)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition"
                            title="Remove from playlist"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          ) : null}
        </div>
      </div>

      {/* Create New Playlist Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-md clay-card p-6 bg-white dark:bg-[#181D2E] text-slate-800 dark:text-slate-100 shadow-2xl">
            <button
              onClick={() => setShowCreateModal(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-xl"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-2xl bg-violet-100 dark:bg-violet-950/60 text-violet-600 flex items-center justify-center">
                <ListVideo className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
                  Create New Playlist
                </h3>
                <p className="text-xs text-slate-400">
                  Name your custom video collection
                </p>
              </div>
            </div>

            <form onSubmit={handleCreateNew} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                  Playlist Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Façade Engineering Masterclass"
                  value={newPlaylistName}
                  onChange={(e) => setNewPlaylistName(e.target.value)}
                  className="w-full clay-input px-3.5 py-2.5 text-xs font-semibold"
                  autoFocus
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="clay-btn clay-btn-secondary px-4 py-2 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="clay-btn clay-btn-primary px-5 py-2 text-xs font-bold"
                >
                  Create Collection
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

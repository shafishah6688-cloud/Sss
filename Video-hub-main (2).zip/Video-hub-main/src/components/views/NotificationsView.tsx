import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { Notification, NotificationType } from '../../types/index.ts';
import {
  Bell,
  Heart,
  MessageCircle,
  UserPlus,
  Briefcase,
  Sparkles,
  ShieldAlert,
  CheckCheck,
  Video,
  ExternalLink,
  Trash2
} from 'lucide-react';

export const NotificationsView: React.FC = () => {
  const { setActiveView, setActiveVideo, setActiveJob, showToast, unreadCount, setUnreadCount } = useApp();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [filter, setFilter] = useState<'all' | 'jobs' | 'social' | 'admin'>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchNotifications();
  }, []);

  const fetchNotifications = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/notifications');
      if (res.ok) {
        const data = await res.json();
        setNotifications(data.notifications || []);
      }
    } catch (e) {
      console.warn('Error loading notifications', e);
    } finally {
      setLoading(false);
    }
  };

  const handleMarkAsRead = async (id: string) => {
    try {
      await fetch(`/api/notifications/${id}/read`, { method: 'PUT' });
      setNotifications(prev =>
        prev.map(n => (n.id === id ? { ...n, read: true } : n))
      );
      setUnreadCount(Math.max(0, unreadCount - 1));
    } catch (e) {
      // ignore
    }
  };

  const handleMarkAllRead = async () => {
    try {
      await fetch('/api/notifications/read-all', { method: 'PUT' });
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
      setUnreadCount(0);
      showToast('All notifications marked as read');
    } catch (e) {
      showToast('Error marking all as read', 'error');
    }
  };

  const handleClickNotification = (notif: Notification) => {
    handleMarkAsRead(notif.id);
    if (notif.link?.includes('/watch/')) {
      const videoId = notif.link.split('/').pop();
      fetch(`/api/videos/${videoId}`)
        .then(r => r.json())
        .then(d => {
          if (d.video) {
            setActiveVideo(d.video);
            setActiveView('watch');
          }
        })
        .catch(() => {});
    } else if (notif.link?.includes('/jobs')) {
      setActiveView('applications');
    } else {
      setActiveView('home');
    }
  };

  const getIcon = (type: NotificationType) => {
    switch (type) {
      case 'like':
        return <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />;
      case 'comment':
        return <MessageCircle className="w-4 h-4 text-violet-500 fill-violet-500" />;
      case 'follow':
        return <UserPlus className="w-4 h-4 text-emerald-500" />;
      case 'job_status':
      case 'job_alert':
        return <Briefcase className="w-4 h-4 text-teal-500" />;
      case 'video_ready':
        return <Video className="w-4 h-4 text-purple-500" />;
      case 'admin_announcement':
        return <ShieldAlert className="w-4 h-4 text-amber-500" />;
      default:
        return <Sparkles className="w-4 h-4 text-indigo-500" />;
    }
  };

  const filtered = notifications.filter(n => {
    if (filter === 'jobs') return n.type === 'job_status' || n.type === 'job_alert';
    if (filter === 'social') return n.type === 'like' || n.type === 'comment' || n.type === 'follow';
    if (filter === 'admin') return n.type === 'admin_announcement';
    return true;
  });

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-16">
      <div className="clay-card p-6 bg-gradient-to-r from-violet-500/10 via-purple-500/10 to-pink-500/10 border border-violet-300/40 dark:border-violet-700/40">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-violet-600 dark:text-violet-400 font-extrabold text-xs uppercase tracking-wider">
              <Bell className="w-4 h-4" />
              Activity Center
            </div>
            <h1 className="text-2xl font-black text-slate-900 dark:text-slate-100 tracking-tight mt-1">
              Notifications & Job Alerts
            </h1>
          </div>

          <button
            onClick={handleMarkAllRead}
            className="clay-btn clay-btn-secondary px-4 py-2 text-xs font-bold gap-1.5 self-start sm:self-auto"
          >
            <CheckCheck className="w-4 h-4 text-violet-600" />
            Mark All as Read
          </button>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2 pt-4">
          {[
            { id: 'all', label: 'All Activity' },
            { id: 'jobs', label: 'Job Applications & Alerts' },
            { id: 'social', label: 'Likes & Comments' },
            { id: 'admin', label: 'Platform Notices' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id as any)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                filter === tab.id
                  ? 'bg-violet-600 text-white shadow-sm'
                  : 'bg-white/80 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map(n => (
            <div key={n} className="clay-card p-4 animate-pulse space-y-2">
              <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded w-1/3" />
              <div className="h-3 bg-slate-200 dark:bg-slate-800 rounded w-1/2" />
            </div>
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="clay-card p-12 text-center max-w-sm mx-auto">
          <div className="w-16 h-16 mx-auto rounded-3xl bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center mb-3">
            <Bell className="w-8 h-8" />
          </div>
          <p className="text-xs font-bold text-slate-500">No notifications in this tab.</p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {filtered.map((notif) => (
            <div
              key={notif.id}
              onClick={() => handleClickNotification(notif)}
              className={`clay-card p-4 flex items-start justify-between gap-3 cursor-pointer transition ${
                !notif.read
                  ? 'border-l-4 border-violet-500 bg-violet-50/20 dark:bg-violet-950/20'
                  : 'bg-white dark:bg-[#181D2E] opacity-90'
              }`}
            >
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center flex-shrink-0 shadow-sm mt-0.5">
                  {getIcon(notif.type)}
                </div>

                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <h4 className="text-xs font-extrabold text-slate-900 dark:text-slate-100">
                      {notif.title}
                    </h4>
                    {!notif.read && (
                      <span className="w-2 h-2 rounded-full bg-violet-500 animate-ping" />
                    )}
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-snug">
                    {notif.message}
                  </p>
                  <p className="text-[10px] text-slate-400 pt-0.5">
                    {new Date(notif.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • {new Date(notif.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 flex-shrink-0">
                {!notif.read && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleMarkAsRead(notif.id);
                    }}
                    className="p-1.5 text-xs text-violet-600 hover:bg-violet-50 dark:hover:bg-violet-950 rounded-lg"
                    title="Mark as Read"
                  >
                    ✓
                  </button>
                )}
                <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { CreatorMonetizationData, Video } from '../../types/index.ts';
import {
  DollarSign,
  TrendingUp,
  Award,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Flame,
  Users,
  CreditCard,
  Building,
  Sparkles,
  ExternalLink,
  ChevronRight,
  HelpCircle,
  AlertCircle,
  Eye,
  Gift,
  HeartHandshake,
  Check,
  ArrowUpRight,
  RefreshCw,
  Landmark,
  FileText
} from 'lucide-react';

export const MonetizationView: React.FC = () => {
  const { currentUser, setActiveView, showToast, setAuthModalOpen } = useApp();

  const [data, setData] = useState<CreatorMonetizationData | null>(null);
  const [loading, setLoading] = useState(true);
  const [payoutModalOpen, setPayoutModalOpen] = useState(false);
  const [payoutAmount, setPayoutAmount] = useState('2450.00');
  const [payoutMethod, setPayoutMethod] = useState<'bank_transfer' | 'paypal' | 'stripe'>('bank_transfer');
  const [payoutDetails, setPayoutDetails] = useState({
    iban: 'SA44 2000 0001 2345 6789 0123',
    bankName: 'Al Rajhi Bank / Saudi National Bank',
    beneficiaryName: 'Shafi Afzal Shah',
    paypalEmail: 'shafi@dometech.sa',
    taxId: '300984712000003'
  });
  const [isSubmittingPayout, setIsSubmittingPayout] = useState(false);
  const [applyingForYPP, setApplyingForYPP] = useState(false);
  const [togglingVideoId, setTogglingVideoId] = useState<string | null>(null);

  // Fetch creator monetization data from backend
  const fetchMonetizationData = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/creator/monetization');
      if (res.ok) {
        const json = await res.json();
        setData(json);
        if (json.balance?.available) {
          setPayoutAmount(json.balance.available.toFixed(2));
        }
      }
    } catch (err) {
      console.error('Failed to load monetization metrics:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMonetizationData();
  }, []);

  const handleApply = async () => {
    try {
      setApplyingForYPP(true);
      const res = await fetch('/api/creator/monetization/apply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ acceptTerms: true })
      });
      const resData = await res.json();
      if (res.ok && resData.success) {
        showToast('Application submitted! Partner Program is now active.', 'success');
        fetchMonetizationData();
      } else {
        showToast(resData.message || 'Application requirement not met', 'error');
      }
    } catch (err) {
      showToast('Error submitting application', 'error');
    } finally {
      setApplyingForYPP(false);
    }
  };

  const handlePayoutSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const num = parseFloat(payoutAmount);
    if (isNaN(num) || num < 50) {
      showToast('Minimum payout threshold is $50.00 USD', 'error');
      return;
    }
    if (data?.balance && num > data.balance.available) {
      showToast('Amount exceeds available cleared balance', 'error');
      return;
    }

    try {
      setIsSubmittingPayout(true);
      const res = await fetch('/api/creator/monetization/payout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: num,
          payoutMethod,
          details: payoutDetails
        })
      });
      const resData = await res.json();
      if (res.ok && resData.success) {
        showToast(`Payout request of $${num.toFixed(2)} submitted successfully! Processed within 1-3 business days.`, 'success');
        setPayoutModalOpen(false);
        fetchMonetizationData();
      } else {
        showToast(resData.message || 'Payout request failed', 'error');
      }
    } catch (err) {
      showToast('Failed to process payout', 'error');
    } finally {
      setIsSubmittingPayout(false);
    }
  };

  const handleToggleVideoMonetization = async (videoId: string, currentStatus: boolean) => {
    try {
      setTogglingVideoId(videoId);
      const res = await fetch(`/api/videos/${videoId}/monetization`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isMonetized: !currentStatus })
      });
      if (res.ok) {
        showToast(!currentStatus ? 'Ad monetization enabled for video!' : 'Ad monetization paused for video');
        fetchMonetizationData();
      }
    } catch (err) {
      showToast('Failed to toggle monetization', 'error');
    } finally {
      setTogglingVideoId(null);
    }
  };

  if (!currentUser) {
    return (
      <div className="max-w-2xl mx-auto py-16 text-center space-y-6">
        <div className="w-20 h-20 mx-auto rounded-3xl bg-amber-500/10 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center">
          <DollarSign className="w-10 h-10" />
        </div>
        <h2 className="text-2xl font-black text-slate-900 dark:text-slate-100">
          World Video Hub Partner Program
        </h2>
        <p className="text-slate-600 dark:text-slate-400 text-sm max-w-md mx-auto">
          Sign in or create a creator channel to access revenue streams, ad sharing (55%/45%), Super Thanks tips, and live gift earnings.
        </p>
        <button
          onClick={() => setAuthModalOpen(true)}
          className="clay-btn clay-btn-primary px-6 py-3 text-sm font-bold"
        >
          Sign In to Access Monetization
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in pb-16">
      {/* Hero Header */}
      <div className="clay-card p-6 sm:p-8 bg-gradient-to-r from-amber-600 via-orange-600 to-rose-600 text-white shadow-2xl relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-96 bg-white/5 rounded-l-full pointer-events-none transform translate-x-32" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-black uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Partner Program & Creator Earnings</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
              Monetization Dashboard
            </h1>
            <p className="text-white/90 text-xs sm:text-sm max-w-2xl leading-relaxed">
              Earn from 6 YouTube-standard revenue streams: Watch Page Ads (55%), Shorts Feed Ads (45%), Paid Memberships (70%), Live Match Gift Winnings, and Super Thanks Tips.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <button
              onClick={() => setActiveView('policies')}
              className="px-4 py-2.5 rounded-2xl bg-white/15 hover:bg-white/25 text-white text-xs font-black tracking-wide flex items-center justify-center gap-2 backdrop-blur-md transition active:scale-95 border border-white/20"
            >
              <FileText className="w-4 h-4" />
              <span>Monetization Terms (Sec. 1–8)</span>
            </button>

            {data?.partnerStatus === 'active' && (
              <button
                onClick={() => setPayoutModalOpen(true)}
                className="px-5 py-2.5 rounded-2xl bg-white text-slate-900 hover:bg-amber-50 text-xs font-black tracking-wide shadow-xl flex items-center justify-center gap-2 transition active:scale-95"
              >
                <Landmark className="w-4 h-4 text-amber-600" />
                <span>Request Payout</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Partner Status Banner */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <div className="lg:col-span-3 clay-card p-5 bg-white dark:bg-[#131722] border border-slate-200/60 dark:border-slate-800">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center text-white shadow-lg shadow-amber-500/30 flex-shrink-0">
                <Award className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
                    Channel Partner Status
                  </h3>
                  {data?.partnerStatus === 'active' ? (
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 font-black text-[10px] tracking-wide flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      ACTIVE PARTNER
                    </span>
                  ) : (
                    <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 font-black text-[10px] tracking-wide">
                      ELIGIBLE TO APPLY
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Channel ID: <span className="font-mono text-slate-700 dark:text-slate-300">{currentUser.id}</span> • Registered Creator: <span className="font-bold text-slate-800 dark:text-slate-200">{currentUser.displayName || currentUser.username}</span>
                </p>
              </div>
            </div>

            {data?.partnerStatus !== 'active' ? (
              <button
                onClick={handleApply}
                disabled={applyingForYPP}
                className="clay-btn clay-btn-primary px-5 py-2.5 text-xs font-black whitespace-nowrap"
              >
                {applyingForYPP ? 'Activating...' : 'Accept Terms & Activate'}
              </button>
            ) : (
              <div className="flex items-center gap-2 text-xs font-bold text-emerald-600 dark:text-emerald-400">
                <ShieldCheck className="w-4 h-4" />
                <span>Good Standing • 0 Strikes</span>
              </div>
            )}
          </div>
        </div>

        {/* Currency & Tax Status */}
        <div className="clay-card p-5 bg-white dark:bg-[#131722] border border-slate-200/60 dark:border-slate-800 flex flex-col justify-between">
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">
              Tax Clearance & Currency
            </span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-lg font-black text-slate-900 dark:text-slate-100">USD ($)</span>
              <span className="text-xs text-slate-500 font-bold">/ SAR pegged</span>
            </div>
          </div>
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px]">
            <span className="text-slate-500">ZATCA / W-8:</span>
            <span className="font-bold text-emerald-600 dark:text-emerald-400">Verified ✓</span>
          </div>
        </div>
      </div>

      {/* Financial KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Estimated Revenue */}
        <div className="clay-card p-5 bg-white dark:bg-[#131722] border border-slate-200/60 dark:border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wide">
              Total Earnings
            </span>
            <div className="w-8 h-8 rounded-xl bg-amber-50 dark:bg-amber-950/40 text-amber-600 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900 dark:text-slate-100">
              ${data?.balance?.totalRevenue?.toLocaleString('en-US', { minimumFractionDigits: 2 }) || '4,890.50'}
            </div>
            <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1 mt-1">
              <TrendingUp className="w-3 h-3" />
              <span>+18.4% vs last 30 days</span>
            </p>
          </div>
        </div>

        {/* Available for Cashout */}
        <div className="clay-card p-5 bg-white dark:bg-[#131722] border border-slate-200/60 dark:border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wide">
              Available Balance
            </span>
            <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 flex items-center justify-center">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
              ${data?.balance?.available?.toLocaleString('en-US', { minimumFractionDigits: 2 }) || '2,450.00'}
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium mt-1">
              Cleared for immediate withdrawal
            </p>
          </div>
        </div>

        {/* Pending Clearance */}
        <div className="clay-card p-5 bg-white dark:bg-[#131722] border border-slate-200/60 dark:border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wide">
              Pending Clearance
            </span>
            <div className="w-8 h-8 rounded-xl bg-blue-50 dark:bg-blue-950/40 text-blue-600 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900 dark:text-slate-100">
              ${data?.balance?.pending?.toLocaleString('en-US', { minimumFractionDigits: 2 }) || '820.50'}
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium mt-1">
              Monthly ad cycle clears on the 21st
            </p>
          </div>
        </div>

        {/* RPM / CPM Metrics */}
        <div className="clay-card p-5 bg-white dark:bg-[#131722] border border-slate-200/60 dark:border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wide">
              Channel RPM / CPM
            </span>
            <div className="w-8 h-8 rounded-xl bg-purple-50 dark:bg-purple-950/40 text-purple-600 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-black text-violet-600 dark:text-violet-400">
                ${data?.balance?.rpm?.toFixed(2) || '3.45'}
              </span>
              <span className="text-xs font-bold text-slate-400">RPM</span>
              <span className="text-slate-300 dark:text-slate-700">|</span>
              <span className="text-xs font-bold text-slate-500">${data?.balance?.cpm?.toFixed(2) || '6.80'} CPM</span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium mt-1">
              Revenue per 1,000 video views
            </p>
          </div>
        </div>
      </div>

      {/* Partner Program Eligibility Checkers (Progress Gauges) */}
      <div className="clay-card p-6 bg-white dark:bg-[#131722] border border-slate-200/60 dark:border-slate-800 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div>
            <h3 className="text-base font-black text-slate-900 dark:text-slate-100">
              Partner Program Eligibility Milestones
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Thresholds required under Section 1 of the Creator Monetization Terms & Conditions
            </p>
          </div>
          <span className="text-xs font-black text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 px-3 py-1 rounded-full border border-emerald-200 dark:border-emerald-800">
            ✓ All Requirements Met
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Subscribers Requirement */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/40 border border-slate-200/70 dark:border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                <Users className="w-4 h-4 text-violet-500" />
                Subscribers
              </span>
              <span className="font-black text-emerald-600 dark:text-emerald-400">100%</span>
            </div>
            <div className="text-lg font-black text-slate-900 dark:text-slate-100">
              {(data?.eligibility?.currentSubscribers || 28400).toLocaleString()} <span className="text-xs font-normal text-slate-400">/ 1,000</span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
              <div className="bg-emerald-500 h-full rounded-full w-full" />
            </div>
            <p className="text-[10px] text-slate-400">Target reached (28.4K subs)</p>
          </div>

          {/* Watch Hours Requirement */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/40 border border-slate-200/70 dark:border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-blue-500" />
                Public Watch Hours
              </span>
              <span className="font-black text-emerald-600 dark:text-emerald-400">100%</span>
            </div>
            <div className="text-lg font-black text-slate-900 dark:text-slate-100">
              {(data?.eligibility?.currentWatchHours || 12450).toLocaleString()} <span className="text-xs font-normal text-slate-400">/ 4,000</span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
              <div className="bg-emerald-500 h-full rounded-full w-full" />
            </div>
            <p className="text-[10px] text-slate-400">Valid in last 365 days</p>
          </div>

          {/* 2-Step Verification */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/40 border border-slate-200/70 dark:border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                2-Step Verification
              </span>
              <Check className="w-4 h-4 text-emerald-500" />
            </div>
            <div className="text-lg font-black text-emerald-600 dark:text-emerald-400">
              Active
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
              <div className="bg-emerald-500 h-full rounded-full w-full" />
            </div>
            <p className="text-[10px] text-slate-400">Account security hardened</p>
          </div>

          {/* Guidelines Strikes */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/40 border border-slate-200/70 dark:border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                Active Strikes
              </span>
              <span className="font-black text-emerald-600 dark:text-emerald-400">0 Strikes</span>
            </div>
            <div className="text-lg font-black text-emerald-600 dark:text-emerald-400">
              Zero Violations
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
              <div className="bg-emerald-500 h-full rounded-full w-full" />
            </div>
            <p className="text-[10px] text-slate-400">Full policy compliance</p>
          </div>
        </div>
      </div>

      {/* Revenue Streams Breakdown (6 YouTube Channels) */}
      <div className="clay-card p-6 bg-white dark:bg-[#131722] border border-slate-200/60 dark:border-slate-800 space-y-6">
        <div>
          <h3 className="text-base font-black text-slate-900 dark:text-slate-100">
            Revenue Streams (Section 2 Splits)
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Earnings segregated by commercial delivery vehicle and platform split percentage
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* 1. Watch Page Ads */}
          <div className="p-4 rounded-2xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200/60 dark:border-amber-900/40 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center font-bold text-xs">
                  55%
                </div>
                <div>
                  <h4 className="text-xs font-black text-slate-900 dark:text-slate-100">
                    Watch Page Ads
                  </h4>
                  <p className="text-[10px] text-slate-500">Standard Videos (Pre-roll/Mid-roll)</p>
                </div>
              </div>
            </div>
            <div className="text-xl font-black text-slate-900 dark:text-slate-100">
              ${data?.breakdown?.watchPageAds?.toLocaleString('en-US', { minimumFractionDigits: 2 }) || '2,420.00'}
            </div>
            <p className="text-[10px] text-slate-500">55% net advertising revenue paid to creator</p>
          </div>

          {/* 2. Shorts Feed Ads */}
          <div className="p-4 rounded-2xl bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200/60 dark:border-rose-900/40 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-rose-500 text-white flex items-center justify-center font-bold text-xs">
                  45%
                </div>
                <div>
                  <h4 className="text-xs font-black text-slate-900 dark:text-slate-100">
                    Shorts Feed Ads
                  </h4>
                  <p className="text-[10px] text-slate-500">In-Feed Pooled Revenue</p>
                </div>
              </div>
            </div>
            <div className="text-xl font-black text-slate-900 dark:text-slate-100">
              ${data?.breakdown?.shortsFeedAds?.toLocaleString('en-US', { minimumFractionDigits: 2 }) || '890.50'}
            </div>
            <p className="text-[10px] text-slate-500">45% creator pool share allocated by view volume</p>
          </div>

          {/* 3. Channel Memberships */}
          <div className="p-4 rounded-2xl bg-purple-50/50 dark:bg-purple-950/20 border border-purple-200/60 dark:border-purple-900/40 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-purple-600 text-white flex items-center justify-center font-bold text-xs">
                  70%
                </div>
                <div>
                  <h4 className="text-xs font-black text-slate-900 dark:text-slate-100">
                    Channel Memberships
                  </h4>
                  <p className="text-[10px] text-slate-500">VIP Badges & Exclusive Badges</p>
                </div>
              </div>
            </div>
            <div className="text-xl font-black text-slate-900 dark:text-slate-100">
              ${data?.breakdown?.memberships?.toLocaleString('en-US', { minimumFractionDigits: 2 }) || '640.00'}
            </div>
            <p className="text-[10px] text-slate-500">70% net membership fee after payment gateway</p>
          </div>

          {/* 4. Live Match Room Gift Drops */}
          <div className="p-4 rounded-2xl bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200/60 dark:border-rose-900/40 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-rose-600 text-white flex items-center justify-center font-bold text-xs">
                  <Gift className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-black text-slate-900 dark:text-slate-100">
                    Live Match Gift Winnings
                  </h4>
                  <p className="text-[10px] text-slate-500">PK Battles & Diamond Gifts</p>
                </div>
              </div>
            </div>
            <div className="text-xl font-black text-slate-900 dark:text-slate-100">
              ${data?.breakdown?.liveGifts?.toLocaleString('en-US', { minimumFractionDigits: 2 }) || '410.00'}
            </div>
            <p className="text-[10px] text-slate-500">Virtual gifts converted into cash balance</p>
          </div>

          {/* 5. Super Thanks Tips */}
          <div className="p-4 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200/60 dark:border-emerald-900/40 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
                  70%
                </div>
                <div>
                  <h4 className="text-xs font-black text-slate-900 dark:text-slate-100">
                    Super Thanks Tips
                  </h4>
                  <p className="text-[10px] text-slate-500">Highlighted Fan Comments</p>
                </div>
              </div>
            </div>
            <div className="text-xl font-black text-slate-900 dark:text-slate-100">
              ${data?.breakdown?.superThanks?.toLocaleString('en-US', { minimumFractionDigits: 2 }) || '280.00'}
            </div>
            <p className="text-[10px] text-slate-500">70% direct creator tip retention</p>
          </div>

          {/* 6. Sponsored Deals */}
          <div className="p-4 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-200/60 dark:border-indigo-900/40 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-xs">
                  <Building className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-black text-slate-900 dark:text-slate-100">
                    Brand Deals & Promos
                  </h4>
                  <p className="text-[10px] text-slate-500">Façade Industry Sponsors</p>
                </div>
              </div>
            </div>
            <div className="text-xl font-black text-slate-900 dark:text-slate-100">
              ${data?.breakdown?.sponsoredDeals?.toLocaleString('en-US', { minimumFractionDigits: 2 }) || '250.00'}
            </div>
            <p className="text-[10px] text-slate-500">Compliant with Section 6 Sponsorship Disclosure</p>
          </div>
        </div>
      </div>

      {/* Video Monetization Management */}
      <div className="clay-card p-6 bg-white dark:bg-[#131722] border border-slate-200/60 dark:border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-black text-slate-900 dark:text-slate-100">
              Video Monetization Status
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Manage pre-roll, mid-roll, and shorts in-feed ads per uploaded video
            </p>
          </div>
          <button
            onClick={fetchMonetizationData}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition"
            title="Refresh video list"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-extrabold uppercase tracking-wider text-[10px]">
                <th className="pb-3 px-2">Video Title</th>
                <th className="pb-3 px-2">Format</th>
                <th className="pb-3 px-2">Views</th>
                <th className="pb-3 px-2">Est. Revenue</th>
                <th className="pb-3 px-2 text-right">Ad Monetization</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
              {data?.videos && data.videos.length > 0 ? (
                data.videos.map((vid: Video) => (
                  <tr key={vid.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition">
                    <td className="py-3 px-2 font-bold text-slate-800 dark:text-slate-200 flex items-center gap-3">
                      <img
                        src={vid.thumbnailUrl}
                        alt={vid.title}
                        className="w-12 h-8 rounded-lg object-cover bg-slate-800 flex-shrink-0"
                      />
                      <span className="truncate max-w-xs">{vid.title}</span>
                    </td>
                    <td className="py-3 px-2">
                      {vid.isShort ? (
                        <span className="px-2 py-0.5 rounded-full bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 font-bold text-[10px]">
                          ⚡ Short
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full bg-violet-100 text-violet-700 dark:bg-violet-950/60 dark:text-violet-300 font-bold text-[10px]">
                          🎬 Video
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-2 text-slate-600 dark:text-slate-400 font-mono">
                      {vid.views.toLocaleString()}
                    </td>
                    <td className="py-3 px-2 font-black text-emerald-600 dark:text-emerald-400 font-mono">
                      ${vid.earnings ? vid.earnings.toFixed(2) : ((vid.views / 1000) * 3.4).toFixed(2)}
                    </td>
                    <td className="py-3 px-2 text-right">
                      <button
                        onClick={() => handleToggleVideoMonetization(vid.id, Boolean(vid.isMonetized))}
                        disabled={togglingVideoId === vid.id}
                        className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold text-[11px] transition active:scale-95 ${
                          vid.isMonetized !== false
                            ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800'
                            : 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400'
                        }`}
                      >
                        <DollarSign className={`w-3.5 h-3.5 ${vid.isMonetized !== false ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'}`} />
                        <span>{vid.isMonetized !== false ? 'Monetized ($)' : 'Off'}</span>
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="py-6 text-center text-slate-400 text-xs">
                    No videos published yet. Upload your first video to start monetizing!
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Payout Modal */}
      {payoutModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="clay-card p-6 sm:p-8 bg-white dark:bg-[#131722] max-w-lg w-full space-y-5 animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center">
                  <Landmark className="w-4 h-4" />
                </div>
                <h3 className="text-base font-black text-slate-900 dark:text-slate-100">
                  Request Creator Payout
                </h3>
              </div>
              <button
                onClick={() => setPayoutModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handlePayoutSubmit} className="space-y-4">
              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/60 dark:border-slate-800 flex items-center justify-between text-xs">
                <div>
                  <span className="text-slate-400">Available Balance:</span>
                  <p className="text-base font-black text-emerald-600 dark:text-emerald-400">
                    ${data?.balance?.available?.toLocaleString('en-US', { minimumFractionDigits: 2 }) || '2,450.00'}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-slate-400">Minimum Threshold:</span>
                  <p className="font-bold text-slate-700 dark:text-slate-300">$50.00 USD</p>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Withdrawal Amount (USD) <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 text-xs font-bold text-slate-400">$</span>
                  <input
                    type="number"
                    step="0.01"
                    min="50"
                    max={data?.balance?.available || 2450}
                    required
                    value={payoutAmount}
                    onChange={(e) => setPayoutAmount(e.target.value)}
                    className="w-full pl-8 pr-3.5 py-2 text-xs clay-input font-mono font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Payout Method
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setPayoutMethod('bank_transfer')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition ${
                      payoutMethod === 'bank_transfer'
                        ? 'bg-amber-50 border-amber-500 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300'
                        : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    IBAN / Wire
                  </button>
                  <button
                    type="button"
                    onClick={() => setPayoutMethod('paypal')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition ${
                      payoutMethod === 'paypal'
                        ? 'bg-amber-50 border-amber-500 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300'
                        : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    PayPal
                  </button>
                  <button
                    type="button"
                    onClick={() => setPayoutMethod('stripe')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition ${
                      payoutMethod === 'stripe'
                        ? 'bg-amber-50 border-amber-500 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300'
                        : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    Stripe Direct
                  </button>
                </div>
              </div>

              {payoutMethod === 'bank_transfer' ? (
                <div className="space-y-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-500 mb-0.5">IBAN Account Number</label>
                    <input
                      type="text"
                      required
                      value={payoutDetails.iban}
                      onChange={(e) => setPayoutDetails({ ...payoutDetails, iban: e.target.value })}
                      className="w-full px-3 py-1.5 text-xs clay-input font-mono"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-500 mb-0.5">Bank Name</label>
                      <input
                        type="text"
                        required
                        value={payoutDetails.bankName}
                        onChange={(e) => setPayoutDetails({ ...payoutDetails, bankName: e.target.value })}
                        className="w-full px-3 py-1.5 text-xs clay-input"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-slate-500 mb-0.5">Beneficiary</label>
                      <input
                        type="text"
                        required
                        value={payoutDetails.beneficiaryName}
                        onChange={(e) => setPayoutDetails({ ...payoutDetails, beneficiaryName: e.target.value })}
                        className="w-full px-3 py-1.5 text-xs clay-input"
                      />
                    </div>
                  </div>
                </div>
              ) : (
                <div>
                  <label className="block text-[11px] font-bold text-slate-500 mb-0.5">Account Email</label>
                  <input
                    type="email"
                    required
                    value={payoutDetails.paypalEmail}
                    onChange={(e) => setPayoutDetails({ ...payoutDetails, paypalEmail: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs clay-input"
                  />
                </div>
              )}

              <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/50 text-[11px] text-amber-800 dark:text-amber-300 leading-relaxed">
                ⚖️ In accordance with <strong>Section 3 & 4 (Creator Monetization Terms)</strong>, payouts are disbursed within 1–3 business days. VAT and withholding declarations comply with ZATCA and applicable tax regulations.
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setPayoutModalOpen(false)}
                  className="clay-btn clay-btn-secondary px-4 py-2 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingPayout}
                  className="clay-btn clay-btn-primary px-5 py-2 text-xs font-bold"
                >
                  {isSubmittingPayout ? 'Processing...' : 'Confirm Withdrawal'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { createContext, useContext, useState } from 'react';

type Language = 'en' | 'es' | 'fr' | 'ar';

interface I18nContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations: Record<Language, Record<string, string>> = {
  en: {
    'settings': 'Settings',
    'autoplay': 'Autoplay',
    'autoplay_desc': 'Automatically play next video',
    'language': 'Language',
    'language_desc': 'Select your preferred language',
  },
  es: {
    'settings': 'Configuración',
    'autoplay': 'Reproducción automática',
    'autoplay_desc': 'Reproducir automáticamente el siguiente video',
    'language': 'Idioma',
    'language_desc': 'Seleccione su idioma preferido',
  },
  fr: {
    'settings': 'Paramètres',
    'autoplay': 'Lecture automatique',
    'autoplay_desc': 'Lire automatiquement la vidéo suivante',
    'language': 'Langue',
    'language_desc': 'Sélectionnez votre langue préférée',
  },
  ar: {
    'settings': 'الإعدادات',
    'autoplay': 'التشغيل التلقائي',
    'autoplay_desc': 'تشغيل الفيديو التالي تلقائياً',
    'language': 'اللغة',
    'language_desc': 'اختر لغتك المفضلة',
  },
};

const I18nContext = createContext<I18nContextType | undefined>(undefined);

export const I18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string) => translations[language][key] || key;

  return (
    <I18nContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </I18nContext.Provider>
  );
};

export const useI18n = () => {
  const context = useContext(I18nContext);
  if (!context) throw new Error('useI18n must be used within an I18nProvider');
  return context;
};

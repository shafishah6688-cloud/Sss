# VideoHub + Global Jobs 🎥🌍

A colorful, modern, claymorphism-based full-stack web platform combining **short-video feeds (TikTok/Shorts style)**, **long-form video streaming (YouTube style)**, **creator channel subscriptions**, **real-time style notification center**, and a specialized **global job-search portal** focused on Aluminium, Curtain Wall & Façade Engineering, Architectural BIM, AutoCAD, and construction megaprojects.

Target Deployment: **Vercel / Node.js 24.x**  
Database: **MongoDB Atlas** (with resilient in-memory fallback for immediate zero-config previews)  
Styling: **Tailwind CSS v4 & Claymorphism soft 3D design system**  

---

## 🌟 Key Features

1. **Shorts Video Experience**:
   - Vertical fullscreen-style player with quick swipe/button controls.
   - Like animations with particle confetti, interactive comment drawer, follow creator, share link, mute/unmute, and content reporting.

2. **Long-Form Video Player**:
   - Custom controls: play/pause, seek scrubber, volume slider, playback speed options (0.5x, 1x, 1.25x, 1.5x, 2x), fullscreen.
   - Channel cards with subscriber counts and follow toggles.
   - Interactive comment posting, likes count, description box, and related engineering recommendations rail.

3. **Global Job-Search Portal**:
   - Specialized categories:
     - Aluminium & Façade Engineering
     - Curtain Wall & Glazing
     - Revit & BIM
     - Architectural Engineering
     - Civil Engineering
     - AutoCAD Drafting
     - Construction Management
     - Software & IT
   - Search by keyword, title, country, city, employment type (Full-time, Remote, Hybrid), and salary range.
   - **Easy Apply Modal**: Attach candidate CV/resume (PDF/DOCX validation), portfolio link, and cover note.
   - **Candidate Tracker**: Live application statuses (*Submitted, Under Review, Shortlisted, Interview, Hired, Rejected*).
   - **Employer Vacancy Publisher**: Post vacancies with salary ranges and qualifications.

4. **Creator Memberships & Subscriptions**:
   - Configurable tiers:
     - **Free Explorer** ($0)
     - **Creator Plus** ($4.99/mo)
     - **Pro Creator** ($9.99/mo)
     - **Business Recruiter** ($19.99/mo)
   - Interactive 1-click upgrade simulation with confetti and notification confirmation.

5. **Notification Center**:
   - Bell icon with live badge counter.
   - Categorized alerts for video likes, comments, job application status updates, mentions, and administrative broadcasts.

6. **Direct Messaging**:
   - Recruiter-to-candidate and creator communication chat threads with live timestamps.

7. **Server-Side Administrative Engine (`server/admin.js`)**:
   - Protected API routes authorized on server.
   - Platform KPIs (Total users, active vacancies, applications, subscriptions, reports).
   - User account management (suspend, restore, promote roles, toggle verified checkmark).
   - Video content moderation (approve, flag, remove).
   - Job vacancy moderation (feature boost, close, reactivate).
   - Community reports resolution queue.
   - Platform announcement broadcast tool.
   - Immutable audit logs.

---

## 🚀 Instant Demo Profiles (1-Click Switcher)

In the top navigation bar, use the **Role** dropdown or the sign-in modal to immediately test drive different user roles:
- **Tariq Mansoor** (Candidate & Façade Engineer) — Test job search, CV Easy Apply, and video comments.
- **Façade Engineering Academy** (Top Creator) — Test channel dashboard, subscriber growth, and video publishing.
- **Apex Façade Systems** (Employer & Recruiter) — Test posting vacancies, reviewing candidate CVs, updating status, and applicant messaging.
- **Alex Sterling** (Platform Administrator) — Test full governance in the Admin Dashboard via `server/admin.js`.

---

## 🗄️ Connecting Your MongoDB Atlas Database

1. Create a free cluster on [MongoDB Atlas](https://www.mongodb.com/cloud/atlas).
2. Under **Database Access**, create a database user and password.
3. Under **Network Access**, allow access from anywhere (`0.0.0.0/0`).
4. Copy your connection string:
   ```env
   MONGODB_URI="mongodb+srv://<username>:<password>@cluster0.mongodb.net/?retryWrites=true&w=majority"
   MONGODB_DB_NAME="videohub_jobs"
   ```
5. Paste `MONGODB_URI` into your Vercel project environment variables or local `.env` file.
6. The app automatically detects the connection string and seeds all collections on first run! If `MONGODB_URI` is omitted, the app smoothly runs using the built-in resilient in-memory database with pre-populated seed data.

---

## ☁️ Deploying to Vercel

1. Push your repository to GitHub / GitLab.
2. In the Vercel Dashboard, click **New Project** and select the repository.
3. In **Build and Output Settings**:
   - Framework Preset: **Other** or **Vite**
   - Build Command: `npm run build`
   - Output Directory: `dist`
4. In **Environment Variables**, add:
   - `MONGODB_URI`
   - `AUTH_SECRET`
   - `NODE_VERSION`: `24.x`
5. Click **Deploy**.

---

## 🧪 Automated Testing & Verification

Run the test suite:
```bash
npm test
```
Run type-checking:
```bash
npm run lint
```
Compile production build:
```bash
npm run build
```
Start development full-stack server:
```bash
npm run dev
```
